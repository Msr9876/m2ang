package com.wallet.dao;

import java.sql.SQLException;
import java.util.HashMap;

import com.wallet.bean.Account;
import com.wallet.bean.Transaction;

public interface IWalletDao {

	public int createAccount(Account account, Transaction transaction) throws SQLException;
	public int showBalance(int accountId) throws SQLException;
	public int deposit(int accountId, int deposit,Transaction transaction) throws SQLException;
	public int  withDraw(int accountId2, int withDraw,Transaction transaction) throws SQLException;
	public int transfer(int accountI3, int accountI4, int transfer, Transaction transaction) throws SQLException;
	public HashMap<Integer, Transaction> printTransactions();
	public void printTransactions(int accountNumber) throws SQLException;

}
