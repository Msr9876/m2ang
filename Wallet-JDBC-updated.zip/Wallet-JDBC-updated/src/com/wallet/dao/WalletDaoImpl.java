package com.wallet.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;


import com.wallet.bean.Account;
import com.wallet.bean.Transaction;

public class WalletDaoImpl implements IWalletDao {
	
	Connection connection=null;
	PreparedStatement preparedStatement=null;
	Statement statement=null;
	
	public void establishConnection() {
		try {
			
			String url="jdbc:oracle:thin:Trg211/training211@10.219.34.3:1521/orcl";			
			String userName="Trg211";
			String password="training211";
			connection=DriverManager.getConnection(url, userName, password);
			System.out.println("Connected");
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
	private void exitConnection()
	 {
	 try {
	  if(connection!=null)
		  connection.close();
	 }
	 catch(SQLException e)
	 {
	  e.printStackTrace();
	 }
	 }

	@Override
	public int createAccount(Account account, Transaction transaction) throws SQLException {
		if(account!=null)
		{
		 establishConnection();
		 String query="insert into accounts (ACCID,NAME ,MOBNUM,EMAILID,PANNUM,AADHARNUM,ADDRESS,BRANCH,BALANCE) values( ?,?,?,?,?,?,?,?,? )";
		 String transactionQuery="insert into transactions (TRANSACTIONID,ACCID,ACCBAL,TYPEOFTRANSACTION,TRANSACTIONAMOUNT) values(?,?,?,?,?)";
		 try {
			 preparedStatement = connection.prepareStatement(query);			 
			 preparedStatement.setInt(1,account.getAccId());
			 preparedStatement.setString(2, account.getName());
			 preparedStatement.setString(3, account.getMobNum());
			 preparedStatement.setString(4, account.getEmailId());
			 preparedStatement.setString(5, account.getpanNum());
			 preparedStatement.setString(6, account.getAadharNum());
			 preparedStatement.setString(7, account.getAddress());
			 preparedStatement.setString(8, account.getBranch());
			 preparedStatement.setInt(9, account.getBalance());			
			 
			 
			 int insert = preparedStatement.executeUpdate();
				System.out.println(insert);
				preparedStatement=connection.prepareStatement(transactionQuery);
				
				preparedStatement.setInt(1,transaction.getTransactionId());
				preparedStatement.setInt(2, transaction.getAccId());
				preparedStatement.setInt(3, transaction.getAccBal());
				preparedStatement.setString(4, transaction.getTypeofTransaction());
				preparedStatement.setInt(5, transaction.getTransactionAmount());
				preparedStatement.executeUpdate();
				System.out.println("Transaction Id is: " +transaction.getTransactionId());
				exitConnection();
			
			return account.getAccId();
		
		} 
		 catch (SQLException e) {
			
			e.printStackTrace();
			return 0;
		}
		}
		else
		{
			return 0;
			}	
	
	}
	

	@Override
	public int showBalance(int accountId) throws SQLException {
		establishConnection();
		String query="select balance from accounts where ACCID=" + accountId;
		try{
			statement= connection.createStatement();
			ResultSet result=statement.executeQuery(query);
			result.next();
			int balance=result.getInt("balance");
			return balance;
		}catch (SQLException e){
			e.printStackTrace();
				return 0;
		}
		
	}

	@Override
	public int deposit(int accountId, int deposit,Transaction transaction) throws SQLException {
		establishConnection();
		String query ="update accounts set BALANCE =BALANCE+"+ deposit + "where ACCID=" + accountId;
		String query1="select BALANCE from accounts where ACCID="+ accountId;
		String checkQuery1="select ACCID from accounts where ACCID="+accountId;
		String transactionQuery="insert into transactions (TRANSACTIONID,ACCID,ACCBAL,TYPEOFTRANSACTION,TRANSACTIONAMOUNT) values(?,?,?,?,?)";
	
		 int insert;		  
			try {
				statement=connection.createStatement();
				ResultSet result1 = statement.executeQuery(checkQuery1);
				
				if(result1.next())
				{
					int AccNo = result1.getInt("ACCID");
					if(AccNo==accountId)
					{
						preparedStatement = connection.prepareStatement(query);
						insert = preparedStatement.executeUpdate();
						statement = connection.createStatement();
						ResultSet result = statement.executeQuery(query1);

						result.next();
						int balance = result.getInt("balance");
						System.out.println("final balance after deposit = "+balance);
						
						preparedStatement=connection.prepareStatement(transactionQuery);
						
						preparedStatement.setInt(1,transaction.getTransactionId());
						preparedStatement.setInt(2, transaction.getAccId());
						preparedStatement.setInt(3, balance);
						preparedStatement.setString(4, transaction.getTypeofTransaction());
						preparedStatement.setInt(5, transaction.getTransactionAmount());
						preparedStatement.executeUpdate();						
						
						System.out.println("Transaction Id is: " +transaction.getTransactionId());
						exitConnection();
						
						
						return balance;
					}
					else
					{
						System.out.println("from account number not existed");
						return 0;
					}
				}
				else
				{  System.out.println("from account number not existed");
					return 0;
				}
				
				} 
				catch (SQLException e) {

				e.printStackTrace();
				return 0;
			}
		}

		
			
			
	

	@Override
	public int  withDraw(int accountId2, int withDraw,Transaction transaction) throws SQLException {
		establishConnection();
		String query ="update accounts set BALANCE =BALANCE-"+ withDraw + "where ACCID=" + accountId2;
		String query1="select BALANCE from accounts where ACCID="+ accountId2;
		String checkQuery1="select ACCID from accounts where ACCID="+accountId2;
		String transactionQuery="insert into transactions (TRANSACTIONID,ACCID,ACCBAL,TYPEOFTRANSACTION,TRANSACTIONAMOUNT) values(?,?,?,?,?)";
	
		 int insert;		  
			try {
				statement=connection.createStatement();
				ResultSet result1 = statement.executeQuery(checkQuery1);
				
				if(result1.next())
				{
					int AccNo = result1.getInt("ACCID");
					if(AccNo==accountId2)
					{
						preparedStatement = connection.prepareStatement(query);
						insert = preparedStatement.executeUpdate();
						statement = connection.createStatement();
						ResultSet result = statement.executeQuery(query1);

						result.next();
						int balance = result.getInt("balance");
						System.out.println("final balance after deposit = "+balance);
						
						preparedStatement=connection.prepareStatement(transactionQuery);
						
						preparedStatement.setInt(1,transaction.getTransactionId());
						preparedStatement.setInt(2, transaction.getAccId());
						preparedStatement.setInt(3, balance);
						preparedStatement.setString(4, transaction.getTypeofTransaction());
						preparedStatement.setInt(5, transaction.getTransactionAmount());
						preparedStatement.executeUpdate();
						
					
						System.out.println("Transaction Id is: " +transaction.getTransactionId());
						exitConnection();
						return balance;
					}
					else
					{
						System.out.println("from account number not existed");
						return 0;
					}
				}
				else
				{  System.out.println("from account number not existed");
					return 0;
				}
				
				} 
				catch (SQLException e) {

				e.printStackTrace();
				return 0;
			}
		}
	@Override
	public int transfer(int accountId3, int accountId4, int transfer, Transaction transaction) throws SQLException {
	
		establishConnection();		
		String checkQuery1="select ACCID from accounts where ACCID="+accountId3;
		String checkQuery2="select ACCID from accounts where ACCID="+accountId4;
		String query1 = "update accounts set BALANCE=BALANCE-" + transfer
				+ "where ACCID=" + accountId3;	
		String query2 = "update accounts set balance=balance+" + transfer
				+ "where ACCID=" + accountId4;
		String query3 = "select BALANCE from accounts where ACCID="
				+ accountId3;
		String transactionQuery="insert into transactions (TRANSACTIONID,ACCID,ACCBAL,TYPEOFTRANSACTION,TRANSACTIONAMOUNT) values(?,?,?,?,?)";
		
		try {
			int FromAcNo = 0;
			int ToAcNo = 0;
			statement=connection.createStatement();
			ResultSet result1 = statement.executeQuery(checkQuery1);
			
			if(result1.next())
			{
				 FromAcNo = result1.getInt("ACCID");
			}
			else
			{
				System.out.println("from account number not existed");
				return 0;
			}
			
		
			ResultSet result2 = statement.executeQuery(checkQuery2);
			if(result2.next())
			{
				 ToAcNo = result2.getInt("ACCID");
				 
			}
			else
			{
				System.out.println("to accountnumber not existed");
				return 0;
			}
			
			
			
			if(FromAcNo==accountId3 && ToAcNo==accountId4)
			{
			preparedStatement = connection.prepareStatement(query1);
			preparedStatement.executeUpdate();
			preparedStatement = connection.prepareStatement(query2);
			
			
			int insert = preparedStatement.executeUpdate();
			statement = connection.createStatement();
			ResultSet result = statement.executeQuery(query3);

			result.next();
			int balance = result.getInt("BALANCE");
			System.out.println("remaining balance after transfering"+balance);
			
			preparedStatement=connection.prepareStatement(transactionQuery);
			
			preparedStatement.setInt(1,transaction.getTransactionId());
			preparedStatement.setInt(2, transaction.getAccId());
			preparedStatement.setInt(3, balance);
			preparedStatement.setString(4, transaction.getTypeofTransaction());
			preparedStatement.setInt(5, transaction.getTransactionAmount());
			preparedStatement.executeUpdate();
			System.out.println("Transaction Id is: " +transaction.getTransactionId());
			exitConnection();
		
			
			return balance;
			}
			else
			{
				System.out.println("enter proper account numbers");
				return 0;
			}

		} catch (SQLException e) {

			e.printStackTrace();
			return 0;
		}
		
	}

	@Override
	public HashMap<Integer, Transaction> printTransactions() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public void printTransactions(int accountNumber) throws SQLException{
		establishConnection();	
		String query="select * from transactions where ACCID="+accountNumber;
		String checkQuery1="select ACCID from accounts where ACCID="+accountNumber;
		try {
			statement=connection.createStatement();
			ResultSet result1 = statement.executeQuery(checkQuery1);
			
			if(result1.next())
			{
				int AccNo = result1.getInt("ACCID");
				if(AccNo==accountNumber)
				{
					System.out.println("Acount is available");
					statement = connection.createStatement();
					ResultSet result = statement.executeQuery(query);

					if(result.next()){ 
						do{
						System.out.println("TRANSACTION ID = " +result.getInt("TRANSACTIONID")+","+"ACCOUNT ID = "+result.getInt("ACCID")+","+"TRANSACTION TYPE = "+result.getString("TYPEOFTRANSACTION")+","+"TRANSACTION AMOUNT = "+result.getInt("TRANSACTIONAMOUNT")+","+"CURRENT BALANCE = "+result.getInt("ACCBAL"));
						}while(result.next());
					}
					else{
						System.out.println("Record Not Found...");
					}
					
				}
				else
				{
					System.out.println("Record Not Found...");
				}
				}
			else
			{
				System.out.println("Record Not Found...");
			}
			exitConnection();
		}
		catch (SQLException e) {

			e.printStackTrace();
			
		}

		
	}
		
		
	}

