package com.wallet.bean;

public class Transaction {
	
	int transactionId;
	int accId;
	int accBal;
	String typeofTransaction;
	int transactionAmount;
	
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public int getAccId() {
		return accId;
	}
	public void setAccId(int accId) {
		this.accId = accId;
	}
	public int getAccBal() {
		return accBal;
	}
	public void setAccBal(int accBal) {
		this.accBal = accBal;
	}
	public String getTypeofTransaction() {
		return typeofTransaction;
	}
	public void setTypeofTransaction(String typeofTransaction) {
		this.typeofTransaction = typeofTransaction;
	}
	public int getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(int transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public Transaction(int transactionId, int accId, int accBal, String typeofTransaction, int transactionAmount) {
		super();
		this.transactionId = transactionId;
		this.accId = accId;
		this.accBal = accBal;
		this.typeofTransaction = typeofTransaction;
		this.transactionAmount = transactionAmount;
	}
	public Transaction() {
		super();
		}
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", accId=" + accId + ", accBal=" + accBal
				+ ", typeofTransaction=" + typeofTransaction + ", transactionAmount=" + transactionAmount + "]";
	}
	
	
	
	
	
	
	


}
