package com.wallet.bean;

public class Account {

	 	int accId;
	 	int cusId;
	 	
	    String name;
	    String mobNum;
	    String emailId;
	    String panNum;
	    String aadharNum;
	    String address;
	    String branch;
	    int balance;
	    String ifsc;
		public int getAccId() {
			return accId;
		}
		public void setAccId(int accId) {
			this.accId = accId;
		}
		public int getCusId() {
			return cusId;
		}
		public void setCusId(int cusId) {
			this.cusId = cusId;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getMobNum() {
			return mobNum;
		}
		public void setMobNum(String mobNum) {
			this.mobNum = mobNum;
		}
		public String getEmailId() {
			return emailId;
		}
		public void setEmailId(String emailId) {
			this.emailId = emailId;
		}
		public String getpanNum() {
			return panNum;
		}
		public void setpanNum(String panNum) {
			this.panNum = panNum;
		}
		public String getAadharNum() {
			return aadharNum;
		}
		public void setAadharNum(String aadharNum) {
			this.aadharNum = aadharNum;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getBranch() {
			return branch;
		}
		public void setBranch(String branch) {
			this.branch = branch;
		}
		public int getBalance() {
			return balance;
		}
		public void setBalance(int balance) {
			this.balance = balance;
		}
		public String getIfsc() {
			return ifsc;
		}
		public void setIfsc(String ifsc) {
			this.ifsc = ifsc;
		}
		
		
		
		public Account(String name, String mobNum, String emailId,
				String panNum, String aadharNum, String address, String branch,
				int balance, String ifsc) {
			super();
			this.name = name;
			this.mobNum = mobNum;
			this.emailId = emailId;
			this.panNum = panNum;
			this.aadharNum = aadharNum;
			this.address = address;
			this.branch = branch;
			this.balance = balance;
			this.ifsc = ifsc;
		}
		public Account() {
			super();
			
		}
		@Override
		public String toString() {
			return "Account [accId=" + accId + ", name=" + name + ", balance=" + balance + "]";
		}
		
		
	    
	
}
