package com.payment.client;

import com.payment.entities.Account;
import com.payment.entities.Transaction;
import com.payment.service.IPaymentService;
import com.payment.service.PaymentServiceImpl;

public class Payment {
	
	public static void main(String[] args) {
		
		IPaymentService iserv=new PaymentServiceImpl();
		Account account=new Account();
		Transaction transaction=new Transaction();
         System.out.println("Transaction Added");
		
		//print Transaction
		transaction=iserv.printTransaction(2);
		System.out.println("Transaction ID: "+transaction.getTransId());
		System.out.println("Account ID: "+transaction.getAccId());
		System.out.println("Balance: "+transaction.getBalance());
		System.out.println("Transaction type: "+transaction.getTypeTrans());
}
}
