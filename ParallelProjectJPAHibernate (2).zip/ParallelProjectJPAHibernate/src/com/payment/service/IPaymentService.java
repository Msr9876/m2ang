package com.payment.service;

import com.payment.entities.Account;
import com.payment.entities.Transaction;

public interface IPaymentService {
	
	public abstract void createAccount(Account account);
	public abstract Account showBalance(int accId);
	public abstract void Deposit(Account account);
	public abstract void Withdraw(Account account);
	
	public abstract void addTransaction(Transaction transaction);
	public abstract Transaction printTransaction(int transId);
	
	public abstract void commitTransaction();
	public abstract void beginTransaction();

}
