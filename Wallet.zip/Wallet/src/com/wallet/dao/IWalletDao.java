package com.wallet.dao;

import java.util.HashMap;

import com.wallet.bean.Account;
import com.wallet.bean.Transaction;

public interface IWalletDao {

	public int createAccount(Account account, Transaction transaction);
	public Account showBalance(int accountId);
	public Account deposit(int accountId, int deposit,Transaction transaction);
	public Account withDraw(int accountId2, int withDraw,Transaction transaction);
	public Account transfer(int accountI3, int accountI4, int transfer,Transaction transaction);
	public HashMap<Integer, Transaction> printTransactions();

}
