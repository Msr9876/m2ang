package com.wallet.dao;


import java.util.HashMap;
import java.util.Map;

import com.wallet.bean.Account;
import com.wallet.bean.Transaction;

public class WalletDaoImpl implements IWalletDao {

	static Map<Integer, Account> accountMap = new HashMap<Integer,Account>();
	static Map<Integer, Transaction> transactionMap=new HashMap<Integer, Transaction>();
	
	@Override
	public int createAccount(Account account, Transaction transaction) {
		accountMap.put(account.getAccId(),account);
		transactionMap.put(transaction.getTransactionId(), transaction);
		return account.getAccId();	
	}
	

	@Override
	public Account showBalance(int accountId) {
//		Account a1 = accountMap.get(acid);	
		return accountMap.get(accountId);		
	}



	@Override
	public Account deposit(int accountId, int deposit,Transaction transaction) {
		Account account=accountMap.get(accountId);
		int balance1=account.getBalance();
		int balance2=balance1+deposit;
		account.setBalance(balance2);
		transactionMap.put(transaction.getTransactionId(), transaction);
		return account;
	}


	@Override
	public Account withDraw(int accountId2, int witdr,Transaction transaction) {
		Account account=accountMap.get(accountId2);
		int balance1=account.getBalance();
		int balance2=balance1-witdr;
		account.setBalance(balance2);
		transactionMap.put(transaction.getTransactionId(), transaction);
		return account;
	}


	@Override
	public Account transfer(int balance3, int balance4, int transer,Transaction transaction) {
		Account account1=accountMap.get(balance3);
		Account account2=accountMap.get(balance4);
		int bal1=account1.getBalance();
		int bal2=account2.getBalance();
		if(!(bal1>=transer)){
			System.out.println("Insufficient funds to transfer");	
			return account1;
		}
		else{
			account1.setBalance(bal1-transer);
			account2.setBalance(bal2+transer);
		}	
		transactionMap.put(transaction.getTransactionId(), transaction);
		
		return account1;
	}


	@Override
	public HashMap<Integer, Transaction> printTransactions() {
		HashMap<Integer, Transaction> transaction = (HashMap<Integer, Transaction>) transactionMap;		 
		 return transaction;
		
	}

}
