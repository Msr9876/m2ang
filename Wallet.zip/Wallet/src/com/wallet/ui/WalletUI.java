package com.wallet.ui;

import java.util.Collection;
import java.util.HashMap;
import java.util.Scanner;



import com.wallet.bean.Account;
import com.wallet.bean.Transaction;
import com.wallet.exception.WalletException;
import com.wallet.service.IWalletService;
import com.wallet.service.WalletServiceImpl;

public class WalletUI {
   static	Scanner scan=new Scanner(System.in);  
   
   static String  choose;
   static IWalletService iserv=null;
   
   static String name;
   static String mobNum;
   static String emailId;
   static String panNum;
   static String aadharNum;
   static String address;
   static String branch;
   static int balance;
   static String ifsc;
   static boolean res;

   
   static int opBal;

	public static void main(String[] args) {
		
	
		do{
			System.out.println("Select any of the bewlow available services:");
			System.out.println(" 1.Create Account\n 2.Show balance \n 3.Deposit ");
			System.out.println(" 4.Withdraw\n 5.Fund transfer \n 6.print transaction");
		
	
		switch(scan.nextInt()){
		case 1:
			int finalAccId=createAccount();
			System.out.println("Account is created");
			System.out.println("Your Account id is:"+finalAccId);
			break;
			
		case 2:	
			Account account1=showBalance();					
			System.out.println("Your acount balance is:"+account1.getBalance());
				break;
		case 3:
			System.out.println("Enter the account id to deposit");
			int accountId1=scan.nextInt();
			System.out.println("Enter the amount to deposit");
			int deposit=scan.nextInt();
			int finalBalance=deposit(accountId1,deposit);
			//Account account2=deposit(accountId1,deposit);
			System.out.println("Balance after depositing is:"+finalBalance);
			break;
			
		case 4:
			System.out.println("Enter the account id to Withdraw");
			int accountId2=scan.nextInt();
			System.out.println("Enter the amount to withdraw");
			int withDraw=scan.nextInt();
			//Account a3=withdraw(accountId2,withDraw);
			int finalBalance1=withdraw(accountId2,withDraw);
			System.out.println("Balance after depositing is:"+finalBalance1);
			break;
			
		case 5:
			System.out.println("Enter the account id from which you want to transfer");
			int accountId3=scan.nextInt();
			System.out.println("Enter the account id to which you want to transfer");
			int accountId4=scan.nextInt();
			System.out.println("Enter the amount you want to transfer");
			int transfer=scan.nextInt();
			int remainingBalance=transfer(accountId3,accountId4,transfer);
			//Account a4=transfer(accountId3,accountId4,transfer);
			System.out.println("Your current balance  is:"+remainingBalance);
			break;
			
		case 6:
			printTransactions();
			break;		
			
		}System.out.println("Do you want to Continue...Yes/No?");
		choose=scan.next();
		}while(choose.equalsIgnoreCase("Yes"));		 	
	}

	


	private static void printTransactions() {
	
		iserv=new WalletServiceImpl();  
		HashMap<Integer, Transaction> transaction = iserv.printTransactions();
		int accountNumber;
		System.out.println("Enter account number to view transaction details");
		accountNumber=scan.nextInt();
		
		Collection<Transaction> transactions = transaction.values();
		for(Transaction trans:transactions){
			if(trans.getAccId()==accountNumber){
				System.out.println(trans);
			}
		}
		
	}




	private static int createAccount() {
		iserv=new WalletServiceImpl();  
		

	do{
		 
		try {
		iserv=new WalletServiceImpl();
		System.out.println("Enter the account person name");
		  name=scan.next();
		  res=iserv.validateName(name);
		}
		catch(WalletException we){
			System.out.println(we.getMessage());
			
		}		  
		}while(!res);
		 
		 res=false;
		 do{
			 try {
			 iserv= new WalletServiceImpl();
		 System.out.println("Enter the Mobile number");
		 mobNum=scan.next();
		 res=iserv.validatemobnum(mobNum);
			 }
			 catch(WalletException we) {
				 System.out.println(we.getMessage());
			 }
		 
		 }while(!res);
		 
		 res=false;
		 do{
			 try {
			 iserv= new WalletServiceImpl();
		 System.out.println("Enter the Email Address");
		 emailId=scan.next();
		 res=iserv.validateemail(emailId);
			 }
			 catch(WalletException we) {
				 System.out.println(we.getMessage());
			 }
		 
		 }while(!res);
		 res=false;
		 
		 do{
			 try {
			 iserv=new WalletServiceImpl();
		 System.out.println("Enter the Pan Number");
		 panNum=scan.next();
		 res=iserv.validatepan(panNum);
			 }
			 catch(WalletException we) {
				 System.out.println(we.getMessage());
			 }	 
		 
		 }while(!res);
		
		 res=false;		 
		 do{
			 try {
			 iserv=new WalletServiceImpl();
		 System.out.println("Enter the Aadhar Number");
		 aadharNum=scan.next();
		 res=iserv.validateaadhar(aadharNum);
			 }
			 
			 catch(WalletException we) {
				 System.out.println(we.getMessage());
			 }	
		 }while(!res);
		 
		 res=false;
		 do{
			 iserv=new WalletServiceImpl();
		 System.out.println("Enter the Address");
		 address=scan.next();
		 }while(iserv.validateadd(address)==false);
		 
		 
		System.out.println("Select the option of the branch");
		System.out.println("1.Sipcot\n 2.Navulur\n 3.Velacherry");
		
		int i=0;
		do{
			
			 i=scan.nextInt();
		switch(i){
		case 1: System.out.println("Your account will be created in Sipcot branch"); 
				branch="Sipcot";
				ifsc="SIP1234";
				break;
		case 2:System.out.println("Your account will be created in Navulur branch");
				branch="Navulur";
				ifsc="NAV5678";
				break;
		case 3:System.out.println("Your account will be created in Velacherry branch");
				branch="Velacherry";
				ifsc="VEL9876";
				break;
		default: System.out.println("Selct options between 1-3");
				break;
		}
		}while(i>3);
		
		
		do{
			iserv=new WalletServiceImpl();
		System.out.println("Enter the account opening balance");
		 balance=scan.nextInt();
		}while(iserv.validatebal(balance)==false);
		 
		System.out.println("Account linked with branch:"+branch);
		System.out.println("Branck IFSC code is:"+ifsc);
		 
		
		 Account account= new Account(name, mobNum, emailId, panNum, aadharNum, address, branch, balance, ifsc);
		 Transaction transaction=new Transaction();
		 transaction.setTransactionAmount(balance);
		 transaction.setAccBal(balance);
		 transaction.setTypeofTransaction("Opening an account");			 
		 
		 int accountId=iserv.createAccount(account,transaction);		     
         return accountId;
		 
		
	}

	private static int transfer(int accountId3, int accountId4, int transfer) {
		iserv=new WalletServiceImpl();
		Transaction transaction= new Transaction();
		Account account4= iserv.transfer(accountId3,accountId4,transfer,transaction);
		
		transaction.setTransactionAmount(transfer);
		transaction.setAccBal(account4.getBalance());
		transaction.setTypeofTransaction("Fund transfer");
		return account4.getBalance();
	}



	private static int withdraw(int accountId2, int withDraw) {

		iserv=new WalletServiceImpl();
		Transaction transaction= new Transaction();
		Account account2=iserv.withDraw(accountId2,withDraw,transaction);
		transaction.setTransactionAmount(withDraw);
		transaction.setAccBal(account2.getBalance());
		transaction.setTypeofTransaction("Withdraw");		
		return account2.getBalance();
	}



	private static int  deposit(int accountId, int deposit) {
		iserv=new WalletServiceImpl();
		Transaction transaction= new Transaction();
		Account account2=iserv.deposit(accountId,deposit,transaction);
		transaction.setTransactionAmount(deposit);
		transaction.setAccBal(account2.getBalance());
		transaction.setTypeofTransaction("Deposit");
		return account2.getBalance();
	}

	private static Account  showBalance() {
		System.out.println("Enter the Account  id to view the balance");
		int accountid=scan.nextInt();
		iserv=new WalletServiceImpl();
		return iserv.showBalance(accountid);
	
	}

}
