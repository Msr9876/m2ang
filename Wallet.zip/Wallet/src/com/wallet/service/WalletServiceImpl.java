package com.wallet.service;

import java.util.HashMap;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.wallet.bean.Account;
import com.wallet.bean.Transaction;
import com.wallet.dao.IWalletDao;
import com.wallet.dao.WalletDaoImpl;
import com.wallet.exception.WalletException;

public class WalletServiceImpl implements IWalletService{

	IWalletDao idao=null;
	Matcher m;;
	
	private int generateAccoundId(){
		int result= (int) (Math.random()*100000);
		return result;
	}
	
	private int generateTransactionId(){
		int result= (int) (Math.random()*1000);
		return result;
	}
	
	@Override
	public int createAccount(Account account, Transaction transaction) {
	account.setAccId(generateAccoundId());
	transaction.setTransactionId(generateTransactionId());
//	transaction.setAccId(generateAccoundId());
	transaction.setAccId(account.getAccId());
	idao=new WalletDaoImpl();
		return idao.createAccount(account, transaction);
	}

	@Override
	public boolean validateName(String name) throws WalletException {
		Pattern p=Pattern.compile("^[A-Z]([a-z]){3,}");
		m=p.matcher(name);		
		if(!m.find())
			throw new WalletException("Name pattern mismatch");		 
			return true;
		
	}

	@Override
	public boolean validatemobnum(String mobNum) throws WalletException {
		Pattern p=Pattern.compile("^[6-9]\\d{9}$");
		m=p.matcher(mobNum);
		if(!m.find())
			throw new WalletException("Mobile number pattern Mismatch");	
		 
			return true;		
	
	}

	@Override
	public boolean validateemail(String emailId) throws WalletException {
		Pattern p=Pattern.compile("[A-Za-z0-9]+@(.+)com$");
		m=p.matcher(emailId);
		if(!m.find())
			throw new WalletException("Email pattern mismatch");
		 
			return true;
		
		
	}

	@Override
	public boolean validatepan(String panNum) throws WalletException {
		Pattern p=Pattern.compile("^[A-Z0-9]{10}");
		m=p.matcher(panNum);		
			
		if(!m.find())
			throw new WalletException("Pan number pattern mismatch");		 
			return true;			
	}
	

	@Override
	public boolean validateaadhar(String aadharNum) throws WalletException {
		Pattern p=Pattern.compile("^[0-9]{12}");
		 m=p.matcher(aadharNum);
		 if(!m.find())
			 throw new WalletException("Aadhar number pattern mismatch");		  
				return true;
				
		
	}

	@Override
	public boolean validateadd(String address) {
		Pattern p=Pattern.compile("^[A-Z 0-9 a-z]{1,}");
		 m=p.matcher(address);
		 if(m.find()){
				return true;
				}
				else{
					System.out.println("Pattern mismatch, enter complete address");
					return false;
				}
	}

	@Override
	public boolean validatebal(int balance) {
		if(balance>2000)
			return true;
		else{
			System.out.println("Opening balance should be greater than 2000");
			return false;
		
		}
		
	}

	@Override
	public Account showBalance(int accountId) {
	idao= new WalletDaoImpl();
	return idao.showBalance(accountId);
		
	}

	@Override
	public Account deposit(int accountId, int deposit, Transaction transaction) {
		idao= new WalletDaoImpl();
		//
		transaction.setTransactionId(generateTransactionId());
		transaction.setAccId(accountId);
		return idao.deposit(accountId,deposit,transaction);
		
	}

	@Override
	public Account withDraw(int accountId2, int withdraw,Transaction transaction) {
		idao= new WalletDaoImpl();
		transaction.setTransactionId(generateTransactionId());
		transaction.setAccId(accountId2);
		return idao.withDraw(accountId2,withdraw,transaction);
		
	}

	@Override
	public Account transfer(int accountId3, int accountId4, int transfer,Transaction transaction) {
		idao= new WalletDaoImpl();
		transaction.setTransactionId(generateTransactionId());
		transaction.setAccId(accountId3);
		return idao.transfer(accountId3,accountId4,transfer,transaction);
	}

	@Override
	public HashMap<Integer, Transaction> printTransactions() {
		idao= new WalletDaoImpl();
		return idao.printTransactions();
	}



}
