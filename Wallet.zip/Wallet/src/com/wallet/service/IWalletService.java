package com.wallet.service;

import java.util.HashMap;

import com.wallet.bean.Account;
import com.wallet.bean.Transaction;
import com.wallet.exception.WalletException;

public interface IWalletService {



	public int createAccount(Account account, Transaction transaction);
	public Account showBalance(int accountId);
	public Account deposit(int accountid, int deposit,Transaction transaction );
	public Account withDraw(int accountId2, int withDraw,Transaction transaction);
	public Account transfer(int accountId3, int accountId4, int transfer,Transaction transaction);
	
	
	
	public boolean validateName(String name) throws WalletException;
	public boolean validatemobnum(String mobNum) throws WalletException;
	public boolean validateemail(String emailId) throws WalletException;
	public boolean validatepan(String panNum) throws WalletException;
	public boolean validateaadhar(String aadharNum) throws WalletException;
	public boolean validateadd(String address);
	public boolean validatebal(int balance);
	public HashMap<Integer, Transaction> printTransactions();

	



	

}
