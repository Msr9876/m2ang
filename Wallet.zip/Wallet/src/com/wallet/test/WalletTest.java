package com.wallet.test;

import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

import com.wallet.bean.Account;
import com.wallet.dao.IWalletDao;
import com.wallet.dao.WalletDaoImpl;

public class WalletTest {


	 IWalletDao dao=null;
	 @BeforeEach
	public void setup()

	{
	 dao=new	WalletDaoImpl();
	}

	 @AfterEach

	 public void teardown()

	 {


	 }

	 @Test
	 public void accountdetails()
	 {

	 Account account=new Account("Sairam","8547854785","sai@gmail.com","ABCDE12352","985475125412","Guntur","Hyd",50000,"VEL9876");

	 }

	}



