package com.capstore.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

//entity class
@Entity
@Table(name ="uploadimage")
public class Upload 
{
	@Id
	@Column(name = "image_id")
	//to automatically generate id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int imageId;
	
	//tableName
	@Column(name = "imagepath")
	private String imagePath;

	//default constructor
	public Upload() {
		super();
		 
	}

	//parameterized constructor
	public Upload(int imageId, String imagePath) {
		super();
		this.imageId = imageId;
		this.imagePath = imagePath;
	}

	
   //getter setter method
	public int getImageId() {
		return imageId;
	}

	public void setImageId(int imageId) {
		this.imageId = imageId;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	
	//to string method
	@Override
	public String toString() {
		return "Upload [imageId=" + imageId + ", imagePath=" + imagePath + "]";
	}
	
	
}
