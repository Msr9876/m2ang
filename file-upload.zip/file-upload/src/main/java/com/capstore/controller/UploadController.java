package com.capstore.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.bean.Upload;
import com.capstore.service.UploadService;
 
 
//to connect to the database
@CrossOrigin(origins = "*", allowedHeaders = "*") 
@RestController
@RequestMapping("/image")
public class UploadController {

	@Autowired
	UploadService uploadService;
	
	//to add image path
	@RequestMapping(value ="/uploadimage", method = RequestMethod.POST, 
			consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Upload addImage(@RequestBody Upload imagePath) 
	{
		return this.uploadService.uploadfile(imagePath);
	}
	
	
	   //to get imagePath by id
		@RequestMapping(value = "/get/{id}", method = RequestMethod.GET)
		public Optional<Upload>  getImage(@PathVariable int id) 
		{
			
			return this.uploadService.getImageById(id);
		}
		
		//to display all Image list
		@RequestMapping(value = "/all", method = RequestMethod.GET)
		public List< Upload> getAllEmployees() 
		{
			return this.uploadService.getAllImages();
		}
		
		//to delete employee details by id
		@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
		public void deleteUser(@PathVariable int id) 
		{
			this.uploadService. deleteImageById(id);
		}
}
