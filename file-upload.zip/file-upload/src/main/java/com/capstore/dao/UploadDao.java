package com.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capstore.bean.Upload;
 
//repository class
@Repository
public interface UploadDao  extends JpaRepository<Upload, Integer>{

}
