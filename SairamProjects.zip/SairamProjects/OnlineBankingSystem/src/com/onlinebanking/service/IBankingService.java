package com.onlinebanking.service;

import com.onlinebanking.bean.Account;
//Interface of the Service layer methods
public interface IBankingService {
	public int createAccount(Account acc);
	public void	updateAccount();
	public void deleteAccount();
	public void withDraw();
	public void checkAllTransactions();
	// Validation methods
	public boolean validateName(String name);
	public boolean validateMobilenumber(String mob);
	public boolean validatePan(String pan);
	public boolean validateemail(String email);
	public boolean validatebalance(int balance);
	public boolean validateacctype(String acctype);
	public boolean validatebranch(String branch);
}
