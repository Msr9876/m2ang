package com.onlinebanking.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.onlinebanking.bean.Account;
import com.onlinebanking.dao.BankingDaoImpl;
import com.onlinebanking.dao.IBankingdao;

public class BankingServiceImpl  implements IBankingService{
	IBankingdao idao=null;
	Matcher m=null;
	//boolean flag;
	private int generateAccountId(){
		int result= (int)(Math.random()*10000);
		return result;
	}
	@Override
	
	public int createAccount(Account acc) {
		acc.setAccountId(generateAccountId());//modicf
		//pass to dao
		idao=new BankingDaoImpl();
		return idao.createAccount(acc);
	}

	@Override
	public void updateAccount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAccount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withDraw() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void checkAllTransactions() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean validateName(String name) {
		// TODO Auto-generated method stub
		Pattern p=Pattern.compile("^[A-Z]([a-z]){3,}");
		m=p.matcher(name);
		if(m.find()){
			return true;
		}
		return false;
	}
	@Override
	public boolean validateMobilenumber(String mob) {
		// TODO Auto-generated method stub
		Pattern p1=Pattern.compile("^[6-9]\\d{9}$");
		m=p1.matcher(mob);
		if(m.find()){
		return true;
		}
		return false;
		
	}
	@Override
	public boolean validatePan(String pan) {
		// TODO Auto-generated method stub
		Pattern p2=Pattern.compile("^[A-Z0-9]{10}");
		m=p2.matcher(pan);
		if(m.find())
			{
				return true;
			}
				return false;
	}
	@Override
	public boolean validateemail(String email) {
		// TODO Auto-generated method stub
		Pattern p3=Pattern.compile("^[A-Za-z0-9]+@(.+)$");//^\\w{}@[a-z]{}.com$
		
		m=p3.matcher(email);
		if(m.find()){
		return true;
		}
		return false;
	}
	@Override
	public boolean validatebalance(int balance) {
		// TODO Auto-generated method stub
		
		if(balance>5000){
			return true;
		}
		return false;
	}
	@Override
	public boolean validateacctype(String acctype) {
		// TODO Auto-generated method stub
		
		Pattern p4=Pattern.compile("Saving|Current");
		m=p4.matcher(acctype);
		if(m.find()){
		return true;
		}
		return false;
	
	}
	@Override
	public boolean validatebranch(String branch) {
		// TODO Auto-generated method stub
		Pattern p5=Pattern.compile("Sipcot|MIPL|Guindy");
		m=p5.matcher(branch);
		if(m.find()){
			return true;
		}
		return false;
	}
	
	
	}
	
	

	

