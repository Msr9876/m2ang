package com.onlinebanking.dao;

import java.util.ArrayList;
import com.onlinebanking.bean.Account;

public class BankingDaoImpl  implements IBankingdao{
	
	static ArrayList<Account> accountlist=new ArrayList<Account>();
	@Override
	public int createAccount(Account acc) {
		accountlist.add(acc);
		return acc.getAccountId();
	}

	@Override
	public void updateAccount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAccount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withDraw() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void checkAllTransactions() {
		// TODO Auto-generated method stub
		
	}

	
}
