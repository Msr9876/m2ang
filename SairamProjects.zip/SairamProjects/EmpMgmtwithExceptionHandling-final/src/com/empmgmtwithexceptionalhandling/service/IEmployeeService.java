package com.empmgmtwithexceptionalhandling.service;

import java.util.Collection;

import com.EmpMgmtwithExceptionHandling.bean.Employee;



public interface IEmployeeService {

	public int addEmployee(Employee emp);
	public void	deleteById(int id);
	public void viewAllEmployees();
	public void  viewById(int vid);
	public Object updateEmployees(int empid2, String pwds);
	
	public boolean validateName(String name);
	public boolean validateSalary(int salary) ;
	public boolean validateDateofJoin(String doj);
	public boolean validatePassword(String pwd);
	
	
	
	
}
