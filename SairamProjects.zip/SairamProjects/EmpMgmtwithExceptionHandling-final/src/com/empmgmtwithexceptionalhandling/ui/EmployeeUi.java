package com.empmgmtwithexceptionalhandling.ui;


import java.util.Scanner;

import com.EmpMgmtwithExceptionHandling.bean.Employee;

import com.empmgmtwithexceptionalhandling.service.IEmployeeService;
import com.empmgmtwithexceptionalhandling.service.Trainee;



public class EmployeeUi {

	static Scanner scan = new Scanner(System.in);
	static IEmployeeService iserv=null;
	static int i;
	public static void main(String[] args) throws Exception {
	
		
		while (i!=6){	
	{
		
		System.out.println("Select any of the below mentioned option number:");
		System.out.println(" 1.Add employee\n 2.Delete employee\n 3.View all employee");
		System.out.println("4.View by id\n 5.Update employee details");
		
		
			
		switch(scan.nextInt()){
		
		case 1: 			
				int finalEmpId=addEmployee();
				System.out.println("Employee info is stored");
				System.out.println("ur account id is "+finalEmpId);
			
				break;

		case 2:
			System.out.println("Enter the id to delete");
			int id=scan.nextInt();
			deleteById(id);
			break;

		case 3: 
			viewAllEmployees();
	
			break;

		case 4:System.out.println("Enter the id to delete");
		int vid=scan.nextInt();
			viewById(vid);	
			break;

		case 5:
		System.out.println("Enter the employee id to change the password");
		int empid2=scan.nextInt();
		System.out.println("Enter the new password");
		String pwds=scan.next();
		updateEmployees(empid2,pwds);
		System.out.println("Password is updated");
			break;
			
		default:
				System.out.println("Choose options between 1-5");
				break;
		}
				
		
		}
	
	}
		}
		



	private static void updateEmployees(int empid2, String pwds) {
	iserv=new Trainee();
	iserv.updateEmployees(empid2,pwds);
	}




	private static void  viewById(int vid) {
		System.out.println("Enter The Employee Id");
		iserv=new Trainee();
		iserv.viewById(vid);
		
	}

	private static  void viewAllEmployees() {
		iserv=new Trainee();
		iserv.viewAllEmployees();
				
	}

	private static void deleteById(int id) {
		iserv=new Trainee();
		iserv.deleteById(id);
		
	}

	static String empname;
	static int salary;
	static String doj;
	static String pwd;
	

	private static  int  addEmployee() throws Exception  {	
		
		
		
		iserv=new Trainee();
		int eid=0;
		boolean res=false;
		
		do {
			
			try {
				System.out.println("enter the account name");
				 empname = scan.next();
				res = iserv.validateName(empname);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		} while (!res);			

		
		do
		{
			System.out.println(" Enter Salary greater than 5000");
			salary=scan.nextInt();
		}while(iserv.validateSalary(salary)==false);
		
		do
		{
			try {
			System.out.println(" Enter date of joining in DD/MM/YYYY format");
			doj=scan.next();
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}while(iserv.validateDateofJoin(doj)==false);
		
		do
		{
			
			System.out.println(" Enter the password greater than 8 digits");
			pwd=scan.next();
						
		}while(iserv.validatePassword(pwd)==false);
		
		Employee emp=new Employee(empname, salary, doj, pwd);
		eid=iserv.addEmployee(emp);		     
        return eid;
    
        
        
    	
		
		
	}
}
	
	

