package com.employeemanagement.ui;

/*header Comment
 * Author :CHAITRA.M
 * Created on:11th April 2019
 * Modified on :
 * modified by :
 * description: Employee management using core java and layered architecture
 * Version : 1.0
 * */
import java.time.LocalDate;
import java.util.*;

import com.employeemanagement.bean.Employee;
import com.employeemanagement.dao.EmployeeDaoImpl;
import com.employeemanagement.exception.EmployeeException;
import com.employeemanagement.service.IEmployeeService;
import com.employeemanagement.service.Trainee;
import com.employeemanagement.service.Trainer;

public class Work {

	static Scanner scan = new Scanner(System.in);
	static IEmployeeService iser = null;
	static EmployeeDaoImpl dimpl = new EmployeeDaoImpl();
	static Map<Integer, Employee> hashmap = new HashMap<Integer, Employee>();
	
	//Main method
	public static void main(String[] args) {
		String res="no";
		do{
			try{	
		System.out.println("enter any option b/1 to 5");
		System.out.println("1. Add Employee \n2. Delete Employee By Id\n3.View All Employee");
		System.out.println("4. View Employee By Id \n5. Update ");
		switch (scan.nextInt()) {
		case 1:addEmployee();
				System.out.println("Employee is added");
				System.out.println(dimpl.hashmap);
			break;
		case 2:System.out.println("Enter the employee ID to delete");
		       int id = scan.nextInt();
		       deleteEmpById(id);
		       System.out.println("Employee with id: "+id+" is deleted");
		       System.out.println(dimpl.hashmap);
			break;
		case 3:Collection<Employee> c = viewAllEmployee();
		for(Employee obj:c){
			System.out.println("Employee details of emp id: "+obj.getEmpId());
			System.out.println("Employee name: "+obj.getEmpName());
			System.out.println("Employee joining date is: "+obj.getDoj());
			System.out.println("Employee Salary is: "+obj.getSalary());
			System.out.println("Employee Password is: "+obj.getPwd());
			System.out.println("------------------------------------------------");
		}
			break;
		case 4:Employee obj=viewEmployeeById();
		System.out.println("Employee details of emp id: "+obj.getEmpId());
		System.out.println("Employee name: "+obj.getEmpName());
		System.out.println("Employee joining date is: "+obj.getDoj());
		System.out.println("Employee Salary is: "+obj.getSalary());
		System.out.println("Employee Password is: "+obj.getPwd());
			break;
		case 5:updateEmployee();
		System.out.println("Employee Details are updated");
			break;
			default:
				System.out.println("Enter the correct option");
				break;
		}
		
		System.out.println("Do you want to exit say yes/no");
		res=scan.next();
			}catch(Exception e){
				res="yes";
				System.out.println("Wrong input option");
		}
		}while(res.equalsIgnoreCase("no"));
		

	}
	
	//updating employee name or pwd
	public static void updateEmployee() {
		System.out.println("Enter the employee id in which you want to update");
		int id = scan.nextInt();
		String name="null";
		String pwd="null";
		//Employee obj = dimpl.hashmap.get(id);
		//iser = new Trainee();
		iser=checkType(iser);
		System.out.println("Enter 1. change Name or 2. change password");
		boolean res=false;
		switch(scan.nextInt()){
		case 1:do{
			try{
				System.out.println("Enter the name which you want to change");
				name=scan.next();
				res=iser.validateName(name);
			}catch(EmployeeException e){
				System.out.println(e.getMessage());
			}
		       }while(!res);
		       iser.update(name,pwd,id);
			break;
		case 2:do{
			try{
				System.out.println("Enter the password which you want to change");
				pwd=scan.next();
				res=iser.validatePwd(pwd);
			}catch(EmployeeException e){
				System.out.println(e.getMessage());
			}}while(!res);
	       iser.update(name,pwd,id);
			break;
		default:System.out.println("Wrong Option");
		break;
		}
		
	}

	//Displaying employee by id
	public static Employee viewEmployeeById() {
		System.out.println("Enter the employee id");
		int id = scan.nextInt();
		iser=checkType(iser);
		Employee obj=iser.viewById(id);
		/*Employee obj = dimpl.hashmap.get(id);
		System.out.println("Employee details of emp id: "+obj.getEmpId());
		System.out.println("Employee name: "+obj.getEmpName());
		System.out.println("Employee joining date is: "+obj.getDoj());
		System.out.println("Employee Salary is: "+obj.getSalary());
		System.out.println("Employee Password is: "+obj.getPwd());*/
		return obj;
	}

	//Diplaying all Employee
	public static Collection<Employee> viewAllEmployee() {
		iser=checkType(iser);
		Collection<Employee> c =iser.viewAllEmp();
		/*Collection<Employee> c = dimpl.hashmap.values();
		for(Employee obj:c){
			System.out.println("Employee details of emp id: "+obj.getEmpId());
			System.out.println("Employee name: "+obj.getEmpName());
			System.out.println("Employee joining date is: "+obj.getDoj());
			System.out.println("Employee Salary is: "+obj.getSalary());
			System.out.println("Employee Password is: "+obj.getPwd());
			System.out.println("------------------------------------------------");
		}*/
		return c;
		
	}

	//deleting employee by id
	public static void deleteEmpById(int id) {
		//calling service class
		//iser=new Trainee();
		iser=checkType(iser);
		iser.deleteById(id);
	}

	//adding employee
	public static void addEmployee() {
		iser=new Trainee();
		String name = null,pwd=null, date=null;
		int salary = 0;
		LocalDate date1=null;
		boolean res=false;
		//getting input from client and validating name
		do{
			try{
				System.out.println("Enter the Employee name");
				name = scan.next();
				res=iser.validateName(name);
			}
			catch(EmployeeException e)
			{
				System.out.println(e.getMessage());
			}
		}while(!res);
		
		//getting input from client and validating date
		do{
			try{
				System.out.println("Enter the date of joining in format yyyy-mm-dd");
				date = scan.next();
				date1= iser.validateDate(date);
				}
				catch(EmployeeException e)
				{
					System.out.println(e.getMessage());
				}
		}while(date1==null);
		
		//getting input from client and validating salary
		do{
			try{
			System.out.println("Enter the salary");
				salary = iser.validateSalary(scan.nextInt());
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			catch(InputMismatchException e){
				System.out.println("wrong salary");}
		}while(salary<1);
		
		//getting input from client and validating password
		res=false;
		do{
			try{
				System.out.println("Enter the password");
				pwd = scan.next();
				res=iser.validatePwd(pwd);
			}catch(EmployeeException e){
				System.out.println(e.getMessage());
			}
		}while(!res);
		
		//calling bean
		Employee employee = null;
		employee= new Trainee(name,date1,salary,pwd);
		
		iser = checkType(iser);
		//calling service class
		iser.addEmployee(employee);
		
	}

	//Checking the Employee Type
	public static IEmployeeService checkType(IEmployeeService iser) {
		// TODO Auto-generated method stub
		System.out.println("enter 1. trainee and 2. trainer");
		switch(scan.nextInt()){
		case 1:iser=new Trainee();
			break;
		case 2:iser=new Trainer();
			break;
		default:System.out.println("wrong selection");
		break;
		}
		return iser;
	}

}
