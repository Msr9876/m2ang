package com.employeemanagement.dao;

import java.util.Collection;
import java.util.Map;

import com.employeemanagement.bean.Employee;

public interface IEmployeeDao {
	public  void addEmployee(Employee employee);
	public void deleteById(int id);
	public Collection<Employee> viewAllEmp(Collection<Employee> c);
	public void viewById(int id);
	public void update(String name, String pwd, Employee obj);
	void addEmployeeTrainer(Employee employee);
	void deleteByIdTrainer(int id);
}
