package com.employeemanagement.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.employeemanagement.bean.Employee;

public class EmployeeDaoImpl implements IEmployeeDao {
	public static Map<Integer, Employee> hashmap = new HashMap<Integer, Employee>();
	public static Map<Integer, Employee> hashmap1 = new HashMap<Integer, Employee>();

	//view all employee
	@Override
	public Collection<Employee> viewAllEmp(Collection<Employee> c) {
		/*for(Employee obj:c){
			System.out.println("Employee details of emp id: "+obj.getEmpId());
			System.out.println("Employee name: "+obj.getEmpName());
			System.out.println("Employee joining date is: "+obj.getDoj());
			System.out.println("Employee Salary is: "+obj.getSalary());
			System.out.println("Employee Password is: "+obj.getPwd());
			System.out.println("------------------------------------------------");
		}*/
		return c;
		
	}

	//add all employee
	@Override
	public void addEmployee(Employee employee) {
		hashmap.put(employee.getEmpId(), employee);
		//System.out.println(hashmap);
	}
	
	//add employee of type trainer
	@Override
	public void addEmployeeTrainer(Employee employee) {
		hashmap1.put(employee.getEmpId(), employee);
		//System.out.println(hashmap);
	}

	//delete employee by id
	@Override
	public void deleteById(int id) {
		hashmap.remove(id);	
	}
	
	//delete employee of type trainer by id
	@Override
	public void deleteByIdTrainer(int id) {
		hashmap1.remove(id);	
	}

	//update the details of employee
	@Override
	public void update(String name, String pwd, Employee obj) {
		// TODO Auto-generated method stub
		
	}

	//view employee by id
	@Override
	public void viewById(int id) {
		// TODO Auto-generated method stub
		
	}

}
