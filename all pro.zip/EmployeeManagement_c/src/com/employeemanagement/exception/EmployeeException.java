package com.employeemanagement.exception;

public class EmployeeException extends Exception{
	
	public EmployeeException() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public EmployeeException(String msg){
		super(msg);
	}
}
