package com.employeemanagement.service;

import java.time.LocalDate;
import java.util.Collection;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.employeemanagement.bean.Employee;
import com.employeemanagement.dao.EmployeeDaoImpl;
import com.employeemanagement.dao.IEmployeeDao;
import com.employeemanagement.exception.EmployeeException;

public class Trainer extends Employee implements IEmployeeService{

	IEmployeeDao iedao = null;
	Matcher m = null;
	
	public Trainer(String name, LocalDate date1, int salary, String pwd) {
		super(name,date1,salary,pwd);
	}

	public Trainer() {
		super();
		// TODO Auto-generated constructor stub
	}

	//view all employee
	@Override
	public Collection<Employee> viewAllEmp() {
		EmployeeDaoImpl dimpl = new EmployeeDaoImpl();
		Collection<Employee> c = dimpl.hashmap1.values();
		return (dimpl.viewAllEmp(c));
	}

	//generate employee id
	private int generateId() {
		// TODO Auto-generated method stub
		return  ++count;//(int)Math.random()*10000;
	}

	//add employee method
	@Override
	public void addEmployee(Employee employee) {
		employee.setEmpId(generateId());
		 iedao= new EmployeeDaoImpl();
		 
		  iedao.addEmployeeTrainer(employee);
	}

	//delete employee by id
	@Override
	public void deleteById(int id) {
		 iedao= new EmployeeDaoImpl();
		iedao.deleteByIdTrainer(id);
	}

	//update the details of employee
	public void update(String name, String pwd, int id) {
		EmployeeDaoImpl dimpl = new EmployeeDaoImpl();
		Employee obj = dimpl.hashmap1.get(id);
		if(!name.equals("null")){
			obj.setEmpName(name);
		}
		else{
			obj.setPwd(pwd);
		}
		
	}

	//view employee by id
	@Override
	public Employee viewById(int id) {
		EmployeeDaoImpl dimpl = new EmployeeDaoImpl();
		Employee obj = dimpl.hashmap1.get(id);
		/*System.out.println("Employee details of emp id: "+obj.getEmpId());
		System.out.println("Employee name: "+obj.getEmpName());
		System.out.println("Employee joining date is: "+obj.getDoj());
		System.out.println("Employee Salary is: "+obj.getSalary());
		System.out.println("Employee Password is: "+obj.getPwd());*/
		return obj;
		
	}

	//validating the name
	public boolean validateName(String name) throws EmployeeException
	{
		m=Pattern.compile("^[A-Z]([a-z]){3,}$").matcher(name);
		if(!m.find())
			throw new EmployeeException("Name is not matching");
		return true;
	}

	//validating the password
	public boolean validatePwd(String pwd) throws EmployeeException
	{
		m=Pattern.compile("^([A-Za-z0-9@]){6,9}$").matcher(pwd);
		if(!m.find())
			throw new EmployeeException("password is not matching");
		return true;
	}
	
	//validating date
	@Override
	public LocalDate validateDate(String date) throws EmployeeException {
		m=Pattern.compile("^([0-9]){4}-([0-9]){2}-([0-9]){2}$").matcher(date);
		
		if(!m.find())
			throw new EmployeeException("Wrong pattern of date");
		return LocalDate.parse(date);
	}
	
	//validating salary
	@Override
	public int validateSalary(int salary) throws EmployeeException {
			if(salary<1)
				throw new EmployeeException("Give currect value for salary");
			else if(salary>0){
				return salary;
			}
			else 
				throw new InputMismatchException("Give currect value for salary");
	}

}
