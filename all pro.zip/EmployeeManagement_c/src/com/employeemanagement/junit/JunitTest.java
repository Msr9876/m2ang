package com.employeemanagement.junit;


import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class JunitTest {

	@BeforeEach
	public void before(){
		System.out.println("Before");
	}
	
	@AfterEach
	public void after(){
		System.out.println("After");
	}
	
	@BeforeAll
	public static void beforeclass(){
		System.out.println("Beforeclass");
	}
	
	@AfterAll
	public static void afterclass(){
		System.out.println("AfterClass");
	}
	
	@Test//(expected=ArithmeticException.class)
	public void check(){
		int a =10;
		int b = a/0;
	}
	
	@Test
	public void check1(){
		int a=90;
		Assertions.assertEquals(90, a);
	}
	
	@Test
	public void test() {
		//fail("Not yet implemented");
		System.out.println("Hello");
	}

}
