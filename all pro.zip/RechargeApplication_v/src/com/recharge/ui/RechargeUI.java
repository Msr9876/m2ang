package com.recharge.ui;

import java.util.Collection;
import java.util.Scanner;

import com.recharge.service.Iservice;
import com.recharge.service.ServiceImpl;
import com.recharge.bean.RBean;

public class RechargeUI {

	static Scanner scan = new Scanner(System.in);
	static Scanner scan2 = new Scanner(System.in);
	static int opt1,opt2;
	static Iservice iserv = null;
	static String rechargeType,plan = null;


	public static void main(String[] args) {
		iserv =new ServiceImpl();
		iserv.addPlans();
		do{
		System.out.println("Enter appropriate option");
		System.out.println("Enter 1--> Recharge \n 2-->view all transactions  \n 3--> View by Transaction ID \n "
				+ "4--> Update Description \n 5--> clear particular History \n 6-->Exit");
		
		switch(opt1=scan.nextInt()){
		case 1:
			System.out.println("Enter 1 for PREPAID recharge");
			System.out.println("Enter 2 for POSTPAID bill payment");
			opt2=scan.nextInt();
			do{
			if(opt2==1){
				System.out.println("Enter the plan");
				plan=scan.next();
				while(!(plan.equalsIgnoreCase("rc99")||plan.equalsIgnoreCase("rc199")||plan.equalsIgnoreCase("rc399"))){
				System.out.println("No such plan exists!!!!! CHOOSE FROM AVAILABLE");
					plan=scan.next();
				}
				int rID=recharge(plan);
				System.out.println("Recharge successfull your rechargeid is "+rID);
				
				rechargeType = "Prepaid";
			}
			
			else if(opt2==2)
			{
				rechargeType = "Postpaid";
			}
			
			else{
				System.out.println("Please choose from the avilable options");
			}
		}while(!(opt2==1 || opt2==2));
			
			break;
			
		case 2:
			Collection<RBean > col = viewAllTransaction();
			for(RBean r:col){
				System.out.println("NAME of the customer : "+r.getName());
				System.out.println("Mobile number of the customer : "+r.getMobNum());
				System.out.println("TRANSACTION ID/ RECHARGE ID : "+r.getRechargeID());
				System.out.println("PLAN : "+r.getPlan());
				System.out.println("Date at which transaction occured "+r.getDate());
				System.out.println("DESC provided "+r.getDesc());
				
			}
			
			break;
			
		case 3:
			System.out.println("Enter the id");
			int id = scan.nextInt();
			RBean r = viewByTransactionId(id);
			System.out.println("NAME of the customer : "+r.getName());
			System.out.println("Mobile number of the customer : "+r.getMobNum());
			System.out.println("TRANSACTION ID/ RECHARGE ID : "+r.getRechargeID());
			System.out.println("PLAN : "+r.getPlan());
			System.out.println("DESC provided "+r.getDesc());
			break;
			
		case 4:
			System.out.println("Enter R-ID of the transaction whose desc you have to update");
			int rid1= scan.nextInt();
			System.out.println("Enter the DESC to be updated");
			String uDesc = scan2.nextLine();
			updateDesc(rid1 , uDesc);
			break;
			
		case 5:
			System.out.println("Enter the Recharge ID whose history you have to delete");
			int rid=scan.nextInt();
			clearHistory(rid);
			System.out.println("History cleared!!!");
			break;
		
		}
		
		}while(opt1!=6);

	}
	
	
	private static void updateDesc(int rid1 , String uDesc) {
		iserv = new ServiceImpl();
		iserv.updateDesc(rid1 , uDesc);
		
	}


	private static void clearHistory(int rid) {
		iserv = new ServiceImpl();
		iserv.clearHistory(rid);
	}


	private static RBean viewByTransactionId(int id) {
		iserv = new ServiceImpl();
		return iserv.viewByTransactionId(id);
		
	}


	private static Collection<RBean> viewAllTransaction() {
		iserv = new ServiceImpl();
		return iserv.viewAllTransaction();
		
		
	}


	public static int recharge(String plan) {
		String name = null;
		String mobNum = null;
		String plann = plan;
		String desc = null;
		boolean flag=false;

		flag=false;
		do{
		try {
			System.out.println("Enter your Name");
			name=scan.next();
			flag=iserv.validateName(name);
			if(flag)
				System.out.println("name added");
			//break;
		} catch (com.recharge.exception.NameNotCorrectException e1) {
			System.out.println(e1.getMessage());
		}
		}while(!flag);

		System.out.println("Enter description");
		desc = scan2.nextLine();
		System.out.println("Enter the mobile number");
		mobNum = scan.next();
		
		RBean bean = new RBean(name, mobNum, plann, rechargeType, desc);
		iserv = new ServiceImpl();
		bean.setBal(3000);
		return iserv.recharge(bean);
	}

}
