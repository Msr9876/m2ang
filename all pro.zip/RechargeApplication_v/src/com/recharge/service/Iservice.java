package com.recharge.service;

import java.util.Collection;

import com.recharge.bean.RBean;
import com.recharge.exception.NameNotCorrectException;

public interface Iservice {

	public void addPlans();
	public int recharge(RBean r);
	public RBean viewByTransactionId(int id);
	public void clearHistory(int rid);
	public void updateDesc(int rid1, String uDesc);
	public Collection<RBean> viewAllTransaction();
	
	public boolean validateName(String name) throws NameNotCorrectException;
}
