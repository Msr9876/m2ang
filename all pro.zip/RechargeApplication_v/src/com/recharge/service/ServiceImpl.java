package com.recharge.service;

import java.time.LocalDate;
import java.util.Collection;

import com.recharge.bean.RBean;
import com.recharge.dao.DaoImpl;
import com.recharge.dao.Idao;
import com.recharge.exception.NameNotCorrectException;

public class ServiceImpl implements Iservice {


	static Idao idao = null;
	public void addPlans() {
		idao = new DaoImpl();
		idao.addPlans();
		
	}

	
	public void updateDesc(int rid1, String uDesc){
		idao = new DaoImpl();
		idao.updateDesc(rid1, uDesc);
	}
	
	public void clearHistory(int rid){
		idao = new DaoImpl();
		idao.clearHistory(rid);
	}
	
	int generateRechargeId(){
		return (int)(Math.random()*1000);
	}
	
	public int recharge(RBean r){
		idao = new DaoImpl();
		r.setRechargeID(generateRechargeId());
		r.setDate(LocalDate.now());
		int curBal=r.getBal();
		if(r.getPlan().equalsIgnoreCase("RC99"))
			r.setBal(curBal-99);
			else if(r.getPlan().equalsIgnoreCase("RC199"))
				r.setBal(curBal-199);
			else if(r.getPlan().equalsIgnoreCase("RC399"))
				r.setBal(curBal-399);
		idao.recharge(r);
		return r.getRechargeID();
		
	}


	public Collection<RBean> viewAllTransaction() {
		idao = new DaoImpl();
		return idao.viewAllTransaction();
	}

	@Override
	public RBean viewByTransactionId(int id) {
		idao = new DaoImpl();
		return idao.viewByTransactionId(id);
	
	}


	@Override
	public boolean validateName(String name) throws NameNotCorrectException {
		if(!(name.length()>=3 && (name.charAt(0)>=65 && name.charAt(0)<=90)))
			throw new NameNotCorrectException("Give first letter Caps with minimum as 4 letters");
		return true;	
	}




}
