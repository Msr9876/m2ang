package com.employeemanagement.bean;

import java.time.LocalDate;

public abstract class Employee {
	int empId;
	String empName;
	LocalDate doj;
	String pwd;
	int salary;
	protected static int count=0;
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public LocalDate getDoj() {
		return doj;
	}
	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	public Employee(String empName, LocalDate doj, int salary, String pwd) {
		super();
		this.empName = empName;
		this.doj = doj;
		this.pwd = pwd;
		this.salary = salary;
	}
	
	public Employee() {
		
	}
	
	public String toString(){
		return empId+":"+empName+":"+doj+":"+pwd+":"+salary;
	}

}
