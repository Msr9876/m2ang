package com.employeemanagement.service;

import java.time.LocalDate;
import java.util.Collection;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.employeemanagement.bean.Employee;
import com.employeemanagement.dao.EmployeeDaoImpl;
import com.employeemanagement.dao.IEmployeeDao;
import com.employeemanagement.exception.EmployeeException;;

public class Trainee extends Employee implements IEmployeeService{
	IEmployeeDao iedao = null;
	Matcher m = null;
	
	public Trainee(String name, LocalDate date1, int salary, String pwd) {
		super(name,date1,salary,pwd);
	}

	public Trainee() {
		super();
		// TODO Auto-generated constructor stub
	}

	//diplaying all employee details
	@Override
	public Collection<Employee> viewAllEmp() throws EmployeeException {
		EmployeeDaoImpl dimpl = new EmployeeDaoImpl();
		return (dimpl.viewAllEmp());
		
	}

	//generating employee id
	private int generateId() {
		// TODO Auto-generated method stub
		/*Random rand = new Random();
		int id = rand.nextInt();
		System.out.println(id);
		return id;*/
		return  ++count;//(int)Math.random()*10000;
	}

	//adding employee
	@Override
	public int addEmployee(Employee employee) {
		employee.setEmpId(generateId());
		 iedao= new EmployeeDaoImpl();
		 
		  int empid=iedao.addEmployee(employee);
		  return empid;
	}

	//deleting employee by id
	@Override
	public void deleteById(int id) throws EmployeeException {
		 iedao= new EmployeeDaoImpl();
		iedao.deleteById(id);
	}

	//updating employee
	@Override
	public void update(String name, String pwd, int id) {
		EmployeeDaoImpl dimpl = new EmployeeDaoImpl();
		Employee obj = dimpl.update(id);
		if(!name.equals("null")){
			obj.setEmpName(name);
		}
		else{
			obj.setPwd(pwd);
		}
	}

	//view employee by id
	@Override
	public Employee viewById(int id) throws EmployeeException {
		EmployeeDaoImpl dimpl = new EmployeeDaoImpl();
		return dimpl.viewById(id);	
	}
	
	//validating name
	public boolean validateName(String name) throws EmployeeException
	{
		m=Pattern.compile("^[A-Z]([a-z]){3,}$").matcher(name);
		if(!m.find())
			throw new EmployeeException("Name is not matching");
		return true;
	}
	
	//validationg pwd
	public boolean validatePwd(String pwd) throws EmployeeException
	{
		m=Pattern.compile("^([A-Za-z0-9@]){6,9}$").matcher(pwd);
		if(!m.find())
			throw new EmployeeException("password is not matching");
		return true;
	}

	//validating date
	@Override
	public LocalDate validateDate(String date) throws EmployeeException {
		m=Pattern.compile("^([0-9]){4}-([0-9]){2}-([0-9]){2}$").matcher(date);
		
		if(!m.find())
			throw new EmployeeException("Wrong pattern of date");
		return LocalDate.parse(date);
	}

	//validating salary
	@Override
	public int validateSalary(int salary) throws EmployeeException,InputMismatchException {
			if(salary<500)
				throw new EmployeeException("Give currect value for salary");
			else if(salary>500)
				return salary;
			else 
				throw new InputMismatchException("Give currect value for salary");
	}

}
