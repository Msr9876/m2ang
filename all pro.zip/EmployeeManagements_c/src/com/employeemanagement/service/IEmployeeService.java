package com.employeemanagement.service;

import java.time.LocalDate;
import java.util.Collection;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;

import com.employeemanagement.bean.Employee;
import com.employeemanagement.exception.EmployeeException;

public interface IEmployeeService {

	public  int addEmployee(Employee employee);
	public void deleteById(int id) throws EmployeeException;
	public Collection<Employee> viewAllEmp() throws EmployeeException;
	public Employee viewById(int id) throws EmployeeException;
	public void update(String name, String pwd, int id);
	public boolean validateName(String name) throws EmployeeException;
	public boolean validatePwd(String pwd) throws EmployeeException;
	public LocalDate validateDate(String date) throws EmployeeException;
	public int validateSalary(int nextInt) throws EmployeeException,InputMismatchException;
}
