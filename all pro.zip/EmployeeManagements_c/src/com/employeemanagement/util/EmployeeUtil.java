package com.employeemanagement.util;

import java.util.HashMap;
import java.util.Map;

import com.employeemanagement.bean.Employee;

public class EmployeeUtil {

	static Map<Integer,Employee> empMap = new HashMap<Integer, Employee>();
	
	public static Map<Integer,Employee> getEmployeeList(){
		return empMap;
	}
}

