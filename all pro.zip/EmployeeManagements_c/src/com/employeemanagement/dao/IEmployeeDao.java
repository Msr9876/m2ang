package com.employeemanagement.dao;

import java.util.Collection;
import java.util.Map;

import com.employeemanagement.bean.Employee;
import com.employeemanagement.exception.EmployeeException;

public interface IEmployeeDao {
	public  int addEmployee(Employee employee);
	public void deleteById(int id) throws EmployeeException;
	public Collection<Employee> viewAllEmp() throws EmployeeException;
	public Employee viewById(int id) throws EmployeeException;
	public Employee update(int id);
}
