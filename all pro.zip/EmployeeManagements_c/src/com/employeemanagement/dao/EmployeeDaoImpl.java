package com.employeemanagement.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.employeemanagement.bean.Employee;
import com.employeemanagement.exception.EmployeeException;
import com.employeemanagement.util.EmployeeUtil;

public class EmployeeDaoImpl implements IEmployeeDao {
	//public static Map<Integer, Employee> hashmap = new HashMap<Integer, Employee>();

	//view all employee
	@Override
	public Collection<Employee> viewAllEmp() throws EmployeeException {
		Collection<Employee> c = EmployeeUtil.getEmployeeList().values();//hashmap.values();
		if(c.isEmpty()){
			throw new EmployeeException("List is Empty");
		}
		return c;
		
	}

	//add all employee
	@Override
	public int addEmployee(Employee employee) {
		EmployeeUtil.getEmployeeList().put(employee.getEmpId(), employee);//hashmap.put(employee.getEmpId(), employee);
		return employee.getEmpId();
	}

	//delete employee by id
	@Override
	public void deleteById(int id) throws EmployeeException {
		EmployeeUtil.getEmployeeList().remove(id);	
		if(EmployeeUtil.getEmployeeList().containsKey(id)){
			throw new EmployeeException("Employee is not their to delete");
		}
	}

	//view employee by id
	@Override
	public Employee viewById(int id) throws EmployeeException {
		Employee obj = EmployeeUtil.getEmployeeList().get(id);
		if(EmployeeUtil.getEmployeeList().containsKey(id)){
			return obj;	
		}
		throw new EmployeeException("Employee which you are searching is not available");
	}

	//updating employee details
	public Employee update(int id) {
		// TODO Auto-generated method stub
		Employee obj = EmployeeUtil.getEmployeeList().get(id);
		return obj;
	}

	

}
