package com.employeemanagement.junit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class JunitTest {

	@Before
	public void before(){
		System.out.println("Before");
	}
	
	@After
	public void after(){
		System.out.println("After");
	}
	
	@BeforeClass
	public static void beforeclass(){
		System.out.println("Beforeclass");
	}
	
	@AfterClass
	public static void afterclass(){
		System.out.println("AfterClass");
	}
	
	@Test(expected=ArithmeticException.class)
	public void check(){
		int a =10;
		int b = a/0;
	}
	
	@Test
	public void check1(){
		int a=90;
		Assert.assertEquals(90, a);
	}
	
	@Test
	public void test() {
		//fail("Not yet implemented");
		System.out.println("Hello");
	}

}
