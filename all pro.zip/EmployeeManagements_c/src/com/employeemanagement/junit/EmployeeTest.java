package com.employeemanagement.junit;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.employeemanagement.bean.Employee;
import com.employeemanagement.dao.EmployeeDaoImpl;
import com.employeemanagement.dao.IEmployeeDao;
import com.employeemanagement.exception.EmployeeException;
import com.employeemanagement.service.Trainee;

public class EmployeeTest {

	private static IEmployeeDao idao = null;
	
	@Before
	public void init(){
		idao=new EmployeeDaoImpl();
	}
	
	@After
	public void destroy(){
		idao=null;
	}
	
	@Test
	public void addEmployee(){
		Employee employee = new Trainee("Chaitra", LocalDate.parse("2019-02-20"), 17000, "chaiM@22");
		employee.setEmpId(1001);
		int empid=idao.addEmployee(employee);
		Assert.assertEquals(1001, empid);
	}
	
	@Test
	public void viewAllEmployee() throws EmployeeException{
		Employee employee = new Trainee("Chaitra", LocalDate.parse("2019-02-20"), 17000, "chaiM@22");
		employee.setEmpId(1001);
		idao.addEmployee(employee);
		Assert.assertNotNull(idao.viewAllEmp());
	}
	
	@Test
	public void viewEmployeeById() throws EmployeeException{
		Employee employee = new Trainee("Chaitra", LocalDate.parse("2019-02-20"), 17000, "chaiM@22");
		employee.setEmpId(1001);
		idao.addEmployee(employee);
		Assert.assertNotNull(idao.viewById(1001));
	}
	
	@Test
	public void deleteEmployeeId() {
		Employee employee = new Trainee("Chaitra", LocalDate.parse("2019-02-20"), 17000, "chaiM@22");
		employee.setEmpId(1001);
		idao.addEmployee(employee);
		try {
			idao.deleteById(1001);
			Assert.assertEquals(employee, idao.viewAllEmp());
		} catch (EmployeeException e) {
			System.out.println(e.getMessage());
		}	
	}
	
	@Test
	public void update(){
		Employee employee = new Trainee("Chaitra", LocalDate.parse("2019-02-20"), 17000, "chaiM@22");
		employee.setEmpId(1001);
		idao.addEmployee(employee);
		employee.setEmpName("chaithanya");
		
		Assert.assertEquals(employee, idao.update(1001));
	}
}
