package com.onlineticketbooking.service;

import com.onlineticketbooking.bean.Booking;

public interface ITicketBookingService {
	public int bookTicket(Booking book);
	public void	cancelTicket();
	public void seatConfirmation();
	public boolean validateName(String name);
	
}
