package com.onlineticketbooking.service;

import java.time.LocalDate;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.onlineticketbooking.bean.Booking;
import com.onlineticketbooking.dao.TicketBookingDaoImpl;
import com.onlineticketbooking.dao.ITicketBookingDao;

public class TicketBookingServiceImpl  implements ITicketBookingService{
	ITicketBookingDao idao=null;
	static Matcher m =null;
	
	private int generateTicketNum(){
		return (int)Math.random()*10000;
	}
	
	private LocalDate generateDate(){
		return LocalDate.now();
	}
	@Override
	public int bookTicket(Booking book) {
		book.setTicketNum(generateTicketNum());//modification
		book.setDate(generateDate());
		//pass to dao
		idao=new TicketBookingDaoImpl();
		return idao.bookTicket(book);
	}
	@Override
	public void cancelTicket() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void seatConfirmation() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean validateName(String name) {
		m=Pattern.compile("^[A-Z]([a-z]){3,}$").matcher(name);
		if(m.find())
			return true;
		return false;
	}

	
	
}
