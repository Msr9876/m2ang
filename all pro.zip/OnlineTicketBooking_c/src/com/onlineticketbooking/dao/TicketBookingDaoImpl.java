package com.onlineticketbooking.dao;

import java.util.ArrayList;

import com.onlineticketbooking.bean.Booking;

public class TicketBookingDaoImpl  implements ITicketBookingDao{
	
	static ArrayList<Booking> bookingList=new ArrayList<Booking>();
	@Override
	public int bookTicket(Booking book) {
		bookingList.add(book);
		return book.getTicketNum();
	}
	@Override
	public void cancelTicket() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void seatConfirmation() {
		// TODO Auto-generated method stub
		
	}

	

	
}
