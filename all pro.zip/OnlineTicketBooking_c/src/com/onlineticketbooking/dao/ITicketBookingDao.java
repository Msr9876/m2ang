package com.onlineticketbooking.dao;

import com.onlineticketbooking.bean.Booking;

public interface ITicketBookingDao {
	public int bookTicket(Booking book);
	public void	cancelTicket();
	public void seatConfirmation();
}
