package com.onlineticketbooking.bean;

import java.time.LocalDate;

public class Booking {
	int ticketNum;
	String name;
	String source; 
	String dest;
	int amount;
	int seats;
	LocalDate date;
	
	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public Booking() {
		// TODO Auto-generated constructor stub
	}

	public int getTicketNum() {
		return ticketNum;
	}

	public void setTicketNum(int ticketNum) {
		this.ticketNum = ticketNum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDest() {
		return dest;
	}

	public void setDest(String dest) {
		this.dest = dest;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getSeats() {
		return seats;
	}

	public void setSeats(int seats) {
		this.seats = seats;
	}

	public Booking(String name, String source, String dest,
			int amount, int seats) {
		this.name = name;
		this.source = source;
		this.dest = dest;
		this.amount = amount;
		this.seats = seats;
	}

	

}
