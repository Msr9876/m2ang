package com.onlineticketbooking.ui;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.onlineticketbooking.bean.Booking;
import com.onlineticketbooking.service.TicketBookingServiceImpl;
import com.onlineticketbooking.service.ITicketBookingService;

public class BookingClientUI {

	static Scanner scan = new Scanner(System.in);
	static ITicketBookingService iserv=null;
	
	public static void main(String[] args) {

		System.out.println("enter any option b/1 to 3");
		System.out.println(" 1. Book Ticket \n 2. Cancel Ticket\n 3. Seat Confirmation");
		switch (scan.nextInt()) {

		case 1:
			int ticketNo=bookTicket();
			System.out.println("Ticket is Booked");
			System.out.println("ticket number is "+ticketNo);
			break;
		case 2:
			break;

		case 3:

			break;
		default:
			break;

		}
	}

	private static int bookTicket() {
		iserv=new TicketBookingServiceImpl();
		String name,source,dest;
		int amount,seats;
		do{
		System.out.println("enter the name");
		name=scan.next();}while(iserv.validateName(name)==false);
		System.out.println("enter the Source");
		source=scan.next();
		System.out.println("enter the Destinatin");
		dest=scan.next();
		do{
		System.out.println("enter the Amount");
		amount=scan.nextInt();}while(amount<=0);
		do{
		System.out.println("enter the No_of_Seats");
		seats=scan.nextInt();}while(seats<1);
		
		//store it in bean
		Booking book=new Booking(name,source,dest,amount,seats);
		
		//validated
		
		
		
		//validation is successful
		int tid=iserv.bookTicket(book);
		
		return tid;
		
		
	}


	

}
