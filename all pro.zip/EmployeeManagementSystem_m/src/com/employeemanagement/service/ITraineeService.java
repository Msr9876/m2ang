package com.employeemanagement.service;

import java.time.LocalDate;
import java.util.Collection;

import com.employeemanagement.bean.Trainee;
import com.employeemanagement.exception.TraineeException;

public interface ITraineeService {
	
	public abstract String createEmployee(Trainee emp);
	public abstract boolean delByID(String string);
	public abstract Collection<Trainee> viewAll();
	public abstract Trainee viewByID(String string);
	public abstract boolean updateName(String id, String empName);
	public abstract boolean updatePassword(String id, String empPass);
	
	public abstract boolean validateName(String name) throws TraineeException;
	public abstract boolean validateSalary(int salary) throws TraineeException;
	public abstract boolean validateDate(LocalDate date) throws TraineeException;
	public abstract boolean validatePassword(String password) throws TraineeException;
	public abstract boolean validateID(String id) throws TraineeException;
	
}
