package com.employeemanagement.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.employeemanagement.bean.Trainee;
import com.employeemanagement.dao.TraineeDao;
import com.employeemanagement.dao.ITraineeDao;
import com.employeemanagement.exception.TraineeException;

public class TraineeService implements ITraineeService {
	
	ITraineeDao idao = null;
	
	private String generateID() {
		return "TE" +(int)(Math.random()*1000) ;
	}

	@Override
	public String createEmployee(Trainee emp) {
		emp.setEmpID(generateID());
		idao = new TraineeDao();
		return idao.createEmployee(emp);
	}

	@Override
	public boolean delByID(String string) {
		return idao.delByID(string);
	}

	@Override
	public Collection<Trainee> viewAll() {
		return idao.viewAll();
	}

	@Override
	public Trainee viewByID(String string) {
		idao = new TraineeDao();
		return idao.viewByID(string);
	}

	@Override
	public boolean updateName(String id, String empName) {
		idao = new TraineeDao();
		return idao.updateName(id, empName);
	}

	@Override
	public boolean updatePassword(String id, String empPass) {
		idao = new TraineeDao();
		return idao.updatePassword(id, empPass);
	}

	@Override
	public boolean validateName(String name) throws TraineeException {
		Pattern p = Pattern.compile("^[A-Z][a-zA-Z]{3,}$");
		Matcher m = p.matcher(name);
		if(!m.find()) {
			throw new TraineeException("Invalid account name. It should contain minimum 4 letters with first letter being Capital and it should not include any numbers");
		}
		return true;
	}

	@Override
	public boolean validateSalary(int salary) throws TraineeException {
		if(salary<15000)
			throw new TraineeException("Minimum salary should be 15000");
		return true;
	}

	@Override
	public boolean validateDate(LocalDate date) throws TraineeException {
		if(date.isAfter(LocalDate.parse("01-01-2018", DateTimeFormatter.ofPattern("dd-MM-yyyy"))) && date.isBefore(LocalDate.now()))
			return true;
		throw new TraineeException("Date of joining must be after 01-01-2018 and before *current date* and must be in the format specified");
	}

	@Override
	public boolean validatePassword(String password) throws TraineeException {
		Pattern p = Pattern.compile("((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{8,40})");
		Matcher m = p.matcher(password);
		if(!m.find()) {
			throw new TraineeException("Invalid password. It should contain atleast one upper case letter, one lower case, one symbol and one number and the minimum length should be 8");
		}
		return true;
	}

	@Override
	public boolean validateID(String id) throws TraineeException {
		Pattern p = Pattern.compile("^(TE)[0-9]{2,3}$");
		Matcher m = p.matcher(id);
		if(!m.matches()) {
			throw new TraineeException("Invalid Employee ID");
		}
		return true;
	}

}
