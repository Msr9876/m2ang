package com.employeemanagement.junit;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.*;

import com.employeemanagement.bean.Trainee;
import com.employeemanagement.dao.ITraineeDao;
import com.employeemanagement.dao.TraineeDao;

public class TraineeTest {
	
	ITraineeDao idaoTest = null;
	
	@Before
	public void setup() {
		idaoTest = new TraineeDao();
	}
	
	@After
	public void tearDown() {
		idaoTest = null;
	}
	
	@Test
	public void testCreateEmployee() {
		Trainee dummyTrainee = new Trainee("Mowrish", 15000, LocalDate.parse("12-12-2018", DateTimeFormatter.ofPattern("dd-MM-yyyy")), "Mowrish1!");
		dummyTrainee.setEmpID("TE180");
		Assert.assertEquals("TE180", idaoTest.createEmployee(dummyTrainee));
//		Assert.assertEquals("TE181", idaoTest.createEmployee(dummyTrainee)); // Failed Test Case
	}
	
	@Test
	public void testDelByID() {
//		Trainee dummyTrainee = new Trainee("Mowrish", 15000, LocalDate.parse("12-12-2018", DateTimeFormatter.ofPattern("dd-MM-yyyy")), "Mowrish1!");
//		dummyTrainee.setEmpID("TE180");
		Assert.assertTrue(idaoTest.delByID("TE180"));
//		Assert.assertTrue(idaoTest.delByID("TE181")); // Failed Test Case
	}
	
	@Test
	public void testViewAll() {
//		Trainee dummyTrainee = new Trainee("Mowrish", 15000, LocalDate.parse("12-12-2018", DateTimeFormatter.ofPattern("dd-MM-yyyy")), "Mowrish1!");
//		Trainee dummyTrainee1 = new Trainee("Nikkin", 25000, LocalDate.parse("12-09-2018", DateTimeFormatter.ofPattern("dd-MM-yyyy")), "Nikkin1!");
//		dummyTrainee.setEmpID("TE180");
//		dummyTrainee1.setEmpID("TE181");
		Assert.assertNotNull(idaoTest.viewAll());
	}
	
	
	
}
