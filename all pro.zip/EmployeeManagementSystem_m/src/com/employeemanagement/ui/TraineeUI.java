/**  
* Trainee Management System (Layered Architecture and HashMap)
* @author  Mowrish Dev
* @version 1.0 
* @see Trainee Details
* @created 12-Apr-2019
*/ 

package com.employeemanagement.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Scanner;

import com.employeemanagement.bean.Trainee;
import com.employeemanagement.exception.TraineeException;
import com.employeemanagement.service.TraineeService;
import com.employeemanagement.service.ITraineeService;

public class TraineeUI {
	
	static Scanner input = new Scanner(System.in);
	static ITraineeService iserv  = null;

	public static void main(String[] args) {
		
		boolean res = false;
		String count = "";
		
		do {
			System.out.println("--------------------------\nTrainee Management System\n--------------------------");
			System.out.print("1. Add Employee\n2. Delete Employee by ID\n3. View All Employees\n4. View Employee by ID\n5. Update Employee Details\nSelect the operation(1-5) : ");
			switch(input.nextInt()) {
			case 1 :
				String employeeID = createEmployee();
				System.out.println("Employee created");
				System.out.println("His Employee ID : " + employeeID);
				break;
			case 2 :
				if(delEmployee())
					System.out.println("Employee Detail has been deleted successfully");
				else
					System.out.println("Invalid Employee ID");
				break;
			case 3 :
				viewEmployee().stream().forEach(e->{
					System.out.println("-----------------------------------------");
					System.out.println("Employee ID : " + e.getEmpID());
					System.out.println("Employee Name : " + e.getEmpName());
					System.out.println("Employee Salary : " + e.getSalary());
					System.out.println("Employee Date Of Joining : " + e.getDoj());
				});
				break;
			case 4 :
				Trainee e = viewByID();
				System.out.println("Employee Details for the id " + e.getEmpID() + " is given below");
				System.out.println("Employee Name : " + e.getEmpName());
				System.out.println("Employee Salary : " + e.getSalary());
				System.out.println("Employee Date Of Joining : " + e.getDoj());
				break;
			
			case 5 :
				System.out.print("1. Update Name\n2. Update Password\nSelect which detail should be updated (1 or 2) : ");
				switch(input.nextInt()) {
				case 1:
					if(updName()) {
						System.out.println("Employee Name has been updated successfully");
					}
					else
						System.out.println("Employee ID cannot be found");
					break;
				case 2:
					if(updPassword()) {
						System.out.println("Employee Password has been updated successfully");
					}
					else
						System.out.println("Employee ID cannot be found");
					break;
				default:
					System.out.println("Invalid option selected");
					continue;
				}
				break;
			default:
				System.out.println("Invalid option selected");
				continue;
			}
			
			do {
				System.out.print("Do you want to perform another operation? (y/n) : ");
				count = input.next();
				if(count.equalsIgnoreCase("y")||count.equalsIgnoreCase("n"))
					res=false;
				else {
					System.out.println("Please select valid option");
					res=true;
				}
			}while(res);
			
			if(count.equalsIgnoreCase("n")) {
				System.out.println("Thank you visit again");
				break;
			}
		}while(!res);
	}

	private static String createEmployee() {
		String name = "",password="";
		LocalDate doj=null;
		int salary = 0;
		boolean flag = false;
		iserv = new TraineeService();
		do {
			try {
				System.out.print("Enter employee name : ");
				name=input.next();
				flag=iserv.validateName(name);
				break;
			} catch(TraineeException e) {
				System.out.println(e);
				flag=false;
			}
		} while(!flag);
		
		do {
			try {
				System.out.print("Enter employee salary : ");
				salary=Integer.parseInt(input.next().trim());
				flag=iserv.validateSalary(salary);
				break;
			} catch(TraineeException e) {
				System.out.println(e);
				flag=false;
			} catch(Exception e) {
				System.out.println("Please enter a number");
				flag=false;
			}
		} while(!flag);
		
		do {
			try {
				System.out.print("Enter employee joining date(dd-mm-yyy) : ");
				doj = LocalDate.parse(input.next(), DateTimeFormatter.ofPattern("dd-MM-yyyy"));
				flag=iserv.validateDate(doj);
			} catch(TraineeException e) {
				System.out.println(e);
				flag=false;
			} catch(Exception e) {
				System.out.println(e.getMessage());
				flag=false;
			}
		} while(!flag);
		
		do {
			try {
				System.out.print("Enter employee account password : ");
				password=input.next();
				flag=iserv.validatePassword(password);
				break;
			} catch(TraineeException e) {
				System.out.println(e);
				flag=false;
			}
		} while(!flag);
		
		Trainee emp = new Trainee(name,salary,doj,password);
		return iserv.createEmployee(emp);
	}
	
	private static boolean delEmployee() {
		System.out.print("Enter ID of the employee you want to delete (TEXXX) : ");
		return iserv.delByID(input.next());
	}
	
	private static Collection<Trainee> viewEmployee() {
		return iserv.viewAll();
	}
	
	private static Trainee viewByID() {
		System.out.print("Enter ID of the employee you want to view (TEXXX) : ");
		return iserv.viewByID(input.next());
	}
	
	private static boolean updName() {
		boolean flag=false;
		String id ="",empName="";
		do {
			try {
				System.out.print("Enter ID of the employee whose name is to updated (TEXXX) : ");
				id = input.next();
				flag=iserv.validateID(id);
				break;
			} catch(TraineeException e) {
				System.out.println(e);
				flag=false;
			}
		} while(!flag);
		do {
			try {
				System.out.print("Enter the new name : ");
				empName = input.next();
				flag=iserv.validateName(empName);
				break;
			} catch(TraineeException e) {
				System.out.println(e);
				flag=false;
			}
		} while(!flag);
		return iserv.updateName(id, empName);
	}
	
	private static boolean updPassword() {
		boolean flag=false;
		String id ="",empPass="";
		do {
			try {
				System.out.print("Enter ID of the employee whose name is to updated (TEXXX) : ");
				id = input.next();
				flag=iserv.validateID(id);
				break;
			} catch(TraineeException e) {
				System.out.println(e);
				flag=false;
			}
		} while(!flag);
		do {
			try {
				System.out.print("Enter the new password : ");
				empPass = input.next();
				flag=iserv.validatePassword(empPass);
				break;
			} catch(TraineeException e) {
				System.out.println(e);
				flag=false;
			}
		} while(!flag);
		return iserv.updatePassword(id, empPass);
	}

}
