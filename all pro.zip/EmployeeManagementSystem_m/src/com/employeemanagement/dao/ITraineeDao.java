package com.employeemanagement.dao;

import java.util.Collection;

import com.employeemanagement.bean.Trainee;

public interface ITraineeDao {

	public abstract String createEmployee(Trainee emp);
	public abstract boolean delByID(String string);
	public abstract Collection<Trainee> viewAll();
	public abstract Trainee viewByID(String string);
	public abstract boolean updateName(String id, String empName);
	public abstract boolean updatePassword(String id, String empPass);
	
}
