package com.employeemanagement.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.employeemanagement.bean.Trainee;

public class TraineeDao implements ITraineeDao {
	
	static Map<String, Trainee> empMap = new HashMap<>();

	@Override
	public String createEmployee(Trainee emp) {
		empMap.put(emp.getEmpID(), emp);
		return emp.getEmpID();
	}

	@Override
	public boolean delByID(String string) {
		if(empMap.remove(string)!=null)
			return true;
		return false;
	}

	@Override
	public Collection<Trainee> viewAll() {
		Collection<Trainee> c = empMap.values();
		return c;
	}

	@Override
	public Trainee viewByID(String string) {
		return empMap.get(string);
	}

	@Override
	public boolean updateName(String id, String empName) {
		Trainee e = empMap.get(id);
		if(e!=null) {
			e.setEmpName(empName);
			return true;
		}
		return false;
	}

	@Override
	public boolean updatePassword(String id, String empPass) {
		Trainee e = empMap.get(id);
		if(e!=null) {
			e.setPassword(empPass);
			return true;
		}
		return false;
	}

}
