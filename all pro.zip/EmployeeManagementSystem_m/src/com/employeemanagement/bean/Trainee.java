package com.employeemanagement.bean;

import java.time.LocalDate;

public class Trainee {
	
	private String empID;
	private String empName;
	private int salary;
	private LocalDate doj;
	private String password;
	
	public Trainee(String empName, int salary, LocalDate doj, String password) {
		this.empName = empName;
		this.salary = salary;
		this.doj = doj;
		this.password = password;
	}

	public String getEmpID() {
		return empID;
	}

	public void setEmpID(String empID) {
		this.empID = empID;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public LocalDate getDoj() {
		return doj;
	}

	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
