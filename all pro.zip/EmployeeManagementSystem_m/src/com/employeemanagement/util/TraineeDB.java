package com.employeemanagement.util;

public class TraineeDB {
	
}
