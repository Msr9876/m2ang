package com.employeemanagement.exception;

@SuppressWarnings("serial")
public class TraineeException extends Exception {
	String s;
	public TraineeException(String s) {
		this.s = s;
	}
	
	@Override
	public String toString() {
		return this.s;
	}
}
