package com.onlinebanking.service;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.onlinebanking.bean.Account;
import com.onlinebanking.dao.BankingDaoImpl;
import com.onlinebanking.dao.IBankingdao;

public class BankingServiceImpl  implements IBankingService{
	IBankingdao idao=null;
	static Matcher m =null;
	
	private int generateAccountId(){
		return (int)Math.random()*10000;
	}
	@Override
	public int createAccount(Account acc) {
		acc.setAccountId(generateAccountId());//modicf
		//pass to dao
		idao=new BankingDaoImpl();
		return idao.createAccount(acc);
	}

	@Override
	public void updateAccount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAccount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withDraw() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void checkAllTransactions() {
		// TODO Auto-generated method stub
		
	}
	
	//validation of name
	public boolean validateName(String name)
	{
		m=Pattern.compile("^[A-Z]([a-z]){3,}$").matcher(name);
		if(m.find())
			return true;
		return false;
	}
	
	//validation of mobile
	public boolean validateMob(String mob){
		m=Pattern.compile("^[6789]{1}([0-9]){9}$").matcher(mob);
		if(m.find())
			return true;
		return false;
	}
	
	//validation of email
	public boolean validateEmail(String email){
		m=Pattern.compile("^([A-Za-z0-9.]){1,}@gmail.com$").matcher(email);
		if(m.find())
			return true;
		return false;
	}
	
	//validation of pan
	public boolean validatePan(String pan){
		m=Pattern.compile("^([A-Z0-9]){10}$").matcher(pan);
		if(m.find())
			return true;
		return false;
	}
	
	//validation of accountType
	public boolean validateAccType(String accType){
		if(accType.equalsIgnoreCase("saving") || accType.equalsIgnoreCase("current"))
			return true;
		return false;
	}
	
	//validation of Balance
	public boolean validateBalance(int balance){
		if(balance>500)
			return true;
		return false;
	}
	
}
