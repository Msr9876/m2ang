package com.onlinebanking.service;

import com.onlinebanking.bean.Account;

public interface IBankingService {
	public int createAccount(Account acc);
	public void	updateAccount();
	public void deleteAccount();
	public void withDraw();
	public void checkAllTransactions();
	public boolean validateName(String name);
	public boolean validateMob(String mob);
	public boolean validateEmail(String email);
	public boolean validatePan(String pan);
	public boolean validateAccType(String accType);
	public boolean validateBalance(int balance);
}
