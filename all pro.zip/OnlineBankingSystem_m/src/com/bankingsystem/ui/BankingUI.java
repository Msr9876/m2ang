package com.bankingsystem.ui;

import java.util.Scanner;

public class BankingUI {
	static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("--------------------\nOnlineBankingSystem\nWelcome to MD Bank\n--------------------");
		System.out.println("1. Create Account\n2. Deposit\n3. NetBanking Login\nSelect the operation (1-3) : ");
		switch (input.nextInt()) {
		case 1:
			createAccount();
			break;
		case 2:
			deposit();
			break;
		case 3:
			netBankingLogin();
			System.out.println("Login Successful");
			System.out.println("1. Show Balance\n2. Deposit\n3. Withdraw\n4. Fund Transfer\n5. Print Transactions");
			switch (input.nextInt()) {
			case 1:
				showBalance();
				break;
			case 2:
				deposit();
				break;
			case 3:
				withdraw();
				break;
			case 4:
				fundTransfer();
				break;
			case 5:
				printTransactions();
				break;

			default:
				System.out.println("Wrong operation selected");
				break;
			}
			break;

		default:
			System.out.println("Wrong operation selected");
			break;
		}
	}

	private static void createAccount() {
		
	}

	private static void deposit() {
		// TODO Auto-generated method stub
		
	}

	private static void netBankingLogin() {
		// TODO Auto-generated method stub
		
	}

	private static void showBalance() {
		// TODO Auto-generated method stub
		
	}

	private static void withdraw() {
		// TODO Auto-generated method stub
		
	}

	private static void fundTransfer() {
		// TODO Auto-generated method stub
		
	}
	
	private static void printTransactions() {
		// TODO Auto-generated method stub
		
	}

}
