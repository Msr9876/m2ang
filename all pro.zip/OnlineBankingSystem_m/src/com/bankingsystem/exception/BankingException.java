package com.bankingsystem.exception;

public class BankingException {

}
