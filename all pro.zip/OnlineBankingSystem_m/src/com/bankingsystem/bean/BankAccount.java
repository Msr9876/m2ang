package com.bankingsystem.bean;

public class BankAccount {
	private String userName;
	private String password;
	private String accountName;
	private int age;
	
	private String accountNo;
//	private LocalDate
	
	public BankAccount(String userName, String password, String accountName, int age) {
		this.userName = userName;
		this.password = password;
		this.accountName = accountName;
		this.age = age;
	}
	
}
