package com.bankingsystem.bean;

public class TransferDetails {

}
