package com.bankingsystem.service;

public class BankingService implements IBankingService  {

	@Override
	public void createAccount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void showBalance() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deposit() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withdraw() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fundTransfer() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printTransactions() {
		// TODO Auto-generated method stub
		
	}

}
