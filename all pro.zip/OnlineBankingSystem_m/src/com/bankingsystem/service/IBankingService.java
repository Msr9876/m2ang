package com.bankingsystem.service;

public interface IBankingService {
	void createAccount();
	void showBalance();
	void deposit();
	void withdraw();
	void fundTransfer();
	void printTransactions();
}
