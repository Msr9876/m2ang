package com.bankingsystem.dao;

public interface IBankingDao {
	void createAccount();
	void showBalance();
	void deposit();
	void withdraw();
	void fundTransfer();
	void printTransactions();
}
