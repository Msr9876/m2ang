package com.bankingsystem.dao;

public class BankingDao implements IBankingDao {

	@Override
	public void createAccount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void showBalance() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deposit() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withdraw() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fundTransfer() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printTransactions() {
		// TODO Auto-generated method stub
		
	}

}
