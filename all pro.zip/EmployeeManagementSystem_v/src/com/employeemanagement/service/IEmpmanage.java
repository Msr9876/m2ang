package com.employeemanagement.service;

import java.time.LocalDate;
import java.util.Date;
import java.util.Set;

import com.employeemanagement.exception.NameNotCorrectException;
import com.employeemanagement.exception.SalaryLessException;
import com.emplyoeemanagement.bean.Employee;

public interface IEmpmanage {

	public void addEmployee(Employee e);
	public void deleteEmpByID(int id);
	public void viewAllEmp();
	public Employee viewById(int idi);
	public boolean validateName(String name) throws NameNotCorrectException;
	public boolean validateMobNum(String name);
	public boolean validateSalary(Double sal) throws SalaryLessException;
	public boolean updateName(int id, String name);
	public boolean validateDate(LocalDate Date);
	public boolean validatepwd(String pwd);
	public boolean updatepwd(int id, String pwd);
	
}
