package com.employeemanagement.service;

import java.time.LocalDate;
import java.util.Date;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.emplyoeemanagement.bean.Employee;
import com.employeemanagement.dao.*;
import com.employeemanagement.exception.NameNotCorrectException;
import com.employeemanagement.exception.SalaryLessException;
public class EmpManageImpl implements IEmpmanage {


	IEmpManageDao iemp = null;
	Matcher m =null;
	private int generateEmpId(){
		return (int)((Math.random())*10000);
	}
	@Override
	public void addEmployee(Employee e) {
		e.setEmpId(generateEmpId());
		iemp=new EmpManageDaoImpl();
		iemp.addEmployee(e);
		

	}

	@Override
	public void deleteEmpByID(int id) {
		iemp = new EmpManageDaoImpl();
		iemp.deleteEmpByID(id);

	}

	@Override
	public void viewAllEmp() {
		// TODO Auto-generated method stub
		System.out.println("Service class");

		iemp = new EmpManageDaoImpl();
		iemp.viewAllEmp();
	}

	
	@Override
	public boolean validateSalary(Double sal) throws SalaryLessException {
		if(sal<20000)
			throw new SalaryLessException("Please provide minimum wages");
		else
			return true;
	}
	
	public boolean validateName(String name) throws NameNotCorrectException{
		if(!(name.length()>=3 && (name.charAt(0)>=65 && name.charAt(0)<=90)))
			throw new NameNotCorrectException("Give first letter Caps with minimum as 4 letters");
		return true;	
	}
	
	
	public boolean validateMobNum(String num) {
		if( (num.length()==10) && (!num.contains(".")) && ( (num.startsWith("9"))||(num.startsWith("8"))||(num.startsWith("7"))||(num.startsWith("6"))) )
				{
			try{
			Double.parseDouble(num);
			return true;
			}
			catch(NumberFormatException e){
				return false;
			}
		}
		else
			return false;
	}
	@Override
	public boolean updateName(int id, String name) {
		return iemp.updateName(id, name);
	}
	
	
	
	
	
	public boolean updatepwd(int id, String pwd) {
		return iemp.updatepwd(id, pwd);
		
	}
	
	
	@Override
	public Employee viewById(int idi) {
		 return iemp.viewById(idi);
		
	}
	
	@Override
	public boolean validateDate(LocalDate d) {
		if(d.isBefore(LocalDate.now())){
			return true;	
		}
		return false;
	}
	@Override
	public boolean validatepwd(String pwd) {
	 
			m=Pattern.compile("^[A-Z][a-z0-9]{1,}$").matcher(pwd);
			if(m.find())
				return true;
			else

		return false;
	}
	
	
	

}
