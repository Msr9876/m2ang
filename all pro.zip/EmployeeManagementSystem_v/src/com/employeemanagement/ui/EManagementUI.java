package com.employeemanagement.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.emplyoeemanagement.bean.Employee;
import com.emplyoeemanagement.bean.Trainee;
import com.emplyoeemanagement.bean.Trainer;
import com.employeemanagement.dao.*;
import com.employeemanagement.exception.NameNotCorrectException;
import com.employeemanagement.exception.SalaryLessException;
import com.employeemanagement.service.EmpManageImpl;
import com.employeemanagement.service.IEmpmanage;

public class EManagementUI {

	static Scanner scan = new Scanner(System.in);
	static int opt2,opt1,opt3;
	static Employee e;
	static IEmpmanage empSer = new EmpManageImpl();
	//DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
	public static void main(String[] args) {
		while(opt1!=6){
		System.out.println("Choose an appropriate option");
		System.out.println("Enter 1 --> add Employee \n 2 --> delete Employee by id \n 3--> view all Employee \n "
				+ "4 --> view Employee by id \n 5 --> update 6 --> exit ");
		opt1=scan.nextInt();
		
		switch(opt1){
		
		case 1:
			System.out.println("Press 1 for add Trainer employee");
			System.out.println("Press 2 for add Trainee employee");
			opt2=scan.nextInt();
			addEmployee();
			System.out.println("Employee added");
			/*EmpManageDaoImpl emdi = new EmpManageDaoImpl();
			emdi.addEmployee(e);
			System.out.println(e);*/                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
			
			
			break;
			
		case 2: System.out.println("Enter ID of Employye to be deleted");
		int id=scan.nextInt();
		deleteEmpByID(id);
			break;
			
		case 3: viewAllEmployee();	
			break;
			
			
		case 4: System.out.println("Enter the ID of the employee whose details you want");
		int idi=scan.nextInt();
		Employee e = viewById(idi);
		if(e!=null){
			System.out.println(e.getEmpName());
			System.out.println(e.getEmpId());}
		else{
			System.out.println("Enter a proper ID");
		}
		
		break;
			
			
		case 5:System.out.println("Enter opt 1 to update name");
		System.out.println("Enter opt 2 to update password");
		do{
		opt3=scan.nextInt();
		if(opt3 == 1){
			if(updName())
				System.out.println("Employee name has been changed successfully");
			else
				System.out.println("Invalid ID"); 
			break;
			
		}
		else if(opt3 == 2){
			if(updPwd())
				System.out.println("Employee password has been changed successfully");
			else
				System.out.println("Invalid ID"); 
			break;
		}
		
		else
			System.out.println("Enter a proper option");
		}while(opt3>2);
		
		}
		}
		
	}
	
	
	private static Employee viewById(int idi) {
		return empSer.viewById(idi);
		
	}


	private static boolean updPwd() { 
		System.out.println("Enter id of emp whose Password to be changed : ");
		int id = scan.nextInt();
		System.out.println("Enter the new paassword");
		String pass = scan.next();
		return empSer.updatepwd(id, pass);
		
	}


	private static boolean updName() {
		System.out.println("Enter id of emp whose Name to be changed : ");
		int id = scan.nextInt();
		System.out.println("Name to be changed : ");
		String name = scan.next();
		return empSer.updateName(id, name);
	}


	private static void deleteEmpByID(int id) {
		empSer = new EmpManageImpl();
		empSer.deleteEmpByID(id);
		
	}

	public static void viewAllEmployee() {
		empSer = new EmpManageImpl();
		//System.out.println("Main class");
		empSer.viewAllEmp();
		// TODO Auto-generated method stub	
	}

	public static void addEmployee(){
		String name = "null";
		String mobNum;
		double salary=0.0;
		LocalDate date;
		String pwd;
		boolean flag=false;
//--------------------------------------------------------------------------------------------------
		
		flag=false;
		do{
		try {
			System.out.println("Enter Employee name");
			name=scan.next();
			flag=empSer.validateName(name);
			if(flag)
				System.out.println("name added");
			//break;
		} catch (NameNotCorrectException e1) {
			System.out.println(e1.getMessage());
		}
		}while(!flag);
		
//------------------------------------------------------------------------------------------------		
		System.out.println("Enter Employee's Mobile Number");
		flag=false;
	do{
		flag=empSer.validateMobNum((mobNum=scan.next()));
		if(flag) {
			break;
		} else {
			System.out.println("Enter a proper mobile num");
				}
	}while(!flag);
//---------------------------------------------------------------------------------------------------------------
		System.out.println("Enter Employee Salary");
		flag=false;
		do{
		try {
			flag=empSer.validateSalary(salary=scan.nextDouble());
				if(flag){
					System.out.println("Salary added");
			break;
				}
		} catch (SalaryLessException e1) {
			System.out.println(e1.getMessage());
		}
		}while(!flag);
		
//---------------------------------------------------------------------------------------------------------------
		System.out.println("Enter Employee Date Of Joining in format of YYYY-MM-DD");
		flag=false;
		do{
			flag=empSer.validateDate(date = LocalDate.parse(scan.next()));
			if(flag) {
				break;
			} else {
				System.out.println("Enter a proper Date");
					}
		}while(!flag);
		
		
		
		System.out.println("Enter Employee Password");
		flag=false;
		do{
			flag=empSer.validatepwd(pwd =scan.next());
			if(flag) {
				break;
			} else {
				System.out.println("Enter a proper Password");
					}
		}while(!flag);
		
		
		if(opt2==1){
		 e = new Trainer(name, mobNum, salary, date, pwd);  
		 empSer=new EmpManageImpl();
		 empSer.addEmployee(e);
		}
		else{
			e = new Trainee(name, mobNum, salary, date, pwd); 
		empSer=new EmpManageImpl();
		empSer.addEmployee(e);}
	}

}
  