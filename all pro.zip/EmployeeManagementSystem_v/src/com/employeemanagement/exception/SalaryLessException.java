package com.employeemanagement.exception;

public class SalaryLessException extends Exception {
	String msg;

	public SalaryLessException(String msg) {
		this.msg = msg;
	}
	
	@Override
	public String getMessage() {
		return msg;
	}
	
}
