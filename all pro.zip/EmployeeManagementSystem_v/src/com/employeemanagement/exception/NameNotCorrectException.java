package com.employeemanagement.exception;

public class NameNotCorrectException extends Exception{

	String msg;
	
	
	public NameNotCorrectException(String msg) {
		super(msg);
	}
	
	public NameNotCorrectException() {
		super();
	}
	
}
