package com.employeemanagement.jtest;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.employeemanagement.dao.EmpManageDaoImpl;
import com.employeemanagement.dao.IEmpManageDao;
import com.emplyoeemanagement.bean.Employee;
import com.emplyoeemanagement.bean.Trainee;
import com.emplyoeemanagement.bean.Trainer;

public class JUnitTest {
	
	private static IEmpManageDao idao = null;
	
	@Before
	public void init(){
		idao = new EmpManageDaoImpl();
	}
	
	@After
	public void destroy(){
		idao=null;
	}
	
	@Test
	public void addEmployee(){
		Employee e = new Trainee("Name","9738717369",98784,LocalDate.parse("2018-12-12"),"Hello");
		e.setEmpId(10002);
		idao.addEmployee(e);
		Assert.assertEquals(10002, e.getEmpId());
	}
	
	/*public void viewAllEmp(){
		Employee e1 = new Trainer("Vikas","9738717369",98784,LocalDate.parse("2018-12-12"),"Hello");
		Employee e2 = new Trainee("Deek","9738717369",98784,LocalDate.parse("2018-12-12"),"World");
		e1.setEmpId(10004);
		e2.setEmpId(10005);
		Map<Integer, Employee> m = new HashMap<Integer, Employee>();
		m.put(e1.getEmpId(), e1);
		m.put(e2.getEmpId(), e2);
		Assert.assertEquals(m.values(), idao.viewAllEmp(););
		
	}*/
}
