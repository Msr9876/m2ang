package com.employeemanagement.dao;

import java.util.Set;

import com.emplyoeemanagement.bean.Employee;

public interface IEmpManageDao {

	public void addEmployee(Employee e);
	public void deleteEmpByID(int id);
	public void viewAllEmp();
	public Employee viewById(int idi);
	public boolean updateName(int id, String name);
	public boolean updatepwd(int id, String pwd);
}
