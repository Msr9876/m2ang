package com.employeemanagement.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.emplyoeemanagement.bean.Employee;

public class EmpManageDaoImpl implements IEmpManageDao {

	static Map<Integer, Employee> EmployeeMap = new HashMap<Integer, Employee>();
	
	@Override
	public void addEmployee(Employee e) {
		EmployeeMap.put(e.getEmpId(), e);
		/*System.out.println("Employee id : "+e.getEmpId());
		System.out.println("Employee name : "+e.getEmpName());
		System.out.println("Employee password : "+e.getPwd());
		System.out.println("Employee salary : "+e.getSalary());*/
		
	}

	@Override
	public void deleteEmpByID(int id) {
	Collection<Employee> obj = EmployeeMap.values();
	EmployeeMap.remove(id);
	/*for(Employee emp: obj){
		if(id==emp.getEmpId()){
			EmployeeMap.remove(emp);
		}
	}*/
	
	}

	@Override
	public void viewAllEmp() {
		// TODO Auto-generated method stub
		Collection<Employee> obj= EmployeeMap.values();
		for(Employee emp: obj){
			System.out.println("Employee id : "+emp.getEmpId());
			System.out.println("Employee name : "+emp.getEmpName());
			System.out.println("Employee password : "+emp.getPwd());
			System.out.println("Employee salary : "+emp.getSalary());
		
		}
		
		
	}

	@Override
	public boolean updateName(int id, String name) {
		Employee emp = EmployeeMap.get(id);
		if(emp!=null) {
			emp.setEmpName(name);
			return true;
		}
		return false;
	}

	@Override
	public boolean updatepwd(int id, String pwd) {
		Employee emp = EmployeeMap.get(id);
		if(emp!=null) {
			emp.setPwd(pwd);
			return true;
		}
		return false;
		
	}

	@Override
	public Employee viewById(int idi) {
		Employee e = EmployeeMap.get(idi);
		if(e!=null)
		return e;
		else
			return null;
	}

	
}
