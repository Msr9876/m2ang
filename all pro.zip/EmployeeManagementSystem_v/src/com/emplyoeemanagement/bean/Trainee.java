package com.emplyoeemanagement.bean;

import java.time.LocalDate;

public class Trainee extends Employee{

	public Trainee(String empName, String mobNum, double salary, LocalDate doj, String pwd) {
		super(empName, mobNum, salary, doj, pwd);
		// TODO Auto-generated constructor stub
	}

	

}
