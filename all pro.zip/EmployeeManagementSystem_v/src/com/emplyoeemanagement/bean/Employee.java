package com.emplyoeemanagement.bean;

import java.time.LocalDate;

public abstract class Employee {
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", mobNum=" + mobNum + ", salary=" + salary + ", doj=" + doj
				+ ", pwd=" + pwd + "]";
	}
	int empId;
	String empName;
	String mobNum;
	double salary;
	LocalDate doj;
	String pwd;
	

	public Employee(String empName, String mobNum, double salary, LocalDate doj, String pwd) {
		this.empName = empName;
		this.mobNum = mobNum;
		this.salary = salary;
		this.doj = doj;
		this.pwd = pwd;
	}
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public LocalDate getDoj() {
		return doj;
	}
	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	
	
}
