package com.emplyoeemanagement.bean;

import java.time.LocalDate;

public class Trainer extends Employee {

	public Trainer(String name,String mobNum, double salary, LocalDate doj, String pwd) {
		super(name,mobNum, salary, doj, pwd);
		// TODO Auto-generated constructor stub
	}

	
}
