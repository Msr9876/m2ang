package com.cg.treeset;

import java.util.*;

public class Adding2List {

	public static void main(String[] args) {
		List<Integer> l1 = new ArrayList<Integer>();
		l1.add(1);
		l1.add(2);
		l1.add(3);
		l1.add(4);
		
		List<Integer> l2 = new LinkedList<Integer>();
		l2.add(11);
		l2.add(22);
		l2.add(33);
		l2.add(44);
		
		//System.out.println(l1);
		//System.out.println(l2);
		
		l1.addAll(l2);
//-------------------------------------------------------------------------------------------------------------------
		//System.out.println(l1);
//-----------------------------------------------------------------------------------------------------------------------		
//		for (Integer i:l1)
//		{
//			System.out.println(i);
//		}
//------------------------------------------------------------------------------------------------------------------------		
		
		Iterator<Integer> i1 = l1.iterator();
		while(i1.hasNext()){
			System.out.println(i1.next());
		}
		

	}

}
