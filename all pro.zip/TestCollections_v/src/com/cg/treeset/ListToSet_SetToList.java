package com.cg.treeset;

import java.util.*;

public class ListToSet_SetToList {

	public static void main(String[] args) {
		
//		List l = new ArrayList();
//		l.add(1);
//		l.add(new Integer(2));
//		l.add(3);
//		l.add(null);
//		l.add(3);
//		
//		
//		Set s = new LinkedHashSet();
//		s.addAll(l);
//		
//		System.out.println(s);
		
//------------------------------------------------------------------------------------------------------------------------
		
		Set s = new LinkedHashSet();
		s.add(1);
		s.add(new Integer(2));
		s.add(3);
		s.add(null);
		s.add(3);
	
		List l = new ArrayList();
		l.addAll(s);
		System.out.println(l);
	
	
	
	
	}

}
