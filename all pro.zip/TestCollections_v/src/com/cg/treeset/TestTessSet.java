package com.cg.treeset;
import java.util.*;

public class TestTessSet {
	public static void main(String[] args) {
		
		
	Set<Object>s = new TreeSet<Object>();
	
	
	s.add(new Animal("cat", 8));
	s.add(new Animal("dog", 5));
	s.add(new Animal("snake", 12));
	//s.add(new Insect("Spider", 1));
	System.out.println(s);
	}
	

}

