package com.cg.treeset;

import java.util.Scanner;

public class Name_Pwd {

	public static void main(String[] args) {
		
		Scanner sc1 = new Scanner(System.in);
		char c = sc1.next().charAt(0);
		
		if(c=='y' || c=='Y'){
			
		}
		
	}
}














class employee{
	
String name;
String password;

public employee(String name, String password) {
	this.name = name;
	this.password = password;
}
	
}