package com.rechargeapplication.ui;

import java.time.LocalDate;
import java.util.Collection;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.rechargeapplication.bean.Recharge;
import com.rechargeapplication.exception.RechargeException;
import com.rechargeapplication.service.IRechargeService;
import com.rechargeapplication.service.RechargeServiceImpl;

public class RechargeUi {

	static Scanner scan = new Scanner(System.in);
	static IRechargeService iser = null;
	static int balance=3000;
	public static void main(String[] args) {
		String res="no";
		do{
			try{	
				System.out.println("enter any option b/w 1 to 5");
				System.out.println("1. Recharge \n2. View All transaction\n3. View Transaction by id");
				System.out.println("4. update Id \n5. Delete By id ");
				switch (Integer.parseInt(scan.next().trim())) {
				case 1:int rechID=recharge();
					System.out.println("Recharge is done and Recharge id is "+rechID);
					if(rechID>0){
						System.out.println("Balance is: "+balance);
					}
					break;
				case 2:Collection<Recharge> rech = viewAllTransaction();
					for(Recharge obj:rech){
						System.out.println(obj);
					}
					break;
				case 3:Recharge rec = viewTransactionByID();
				System.out.println(rec);
					break;
				case 4:Recharge rec1 = update();
				System.out.println(rec1);
					break;
				case 5:deleteById();
				System.out.println("Transaction is deleted");
					break;
				default:
					System.out.println("Enter the correct option");
					break;
				}
				System.out.println("Do you want to exit say yes/no");
				res=scan.next();
			}catch(RechargeException e){
				System.out.println(e.getMessage());
				}
			catch(InputMismatchException e){
				System.out.println("wrong salary");
				}
			catch(Exception e){
				res="no";
				System.out.println("Wrong input option");
			}
		}while(res.equalsIgnoreCase("no"));
	}
	
	
	public static void deleteById() throws RechargeException {
		System.out.println("Enter the Transaction id");
		int id = scan.nextInt();
		iser=new RechargeServiceImpl();
		iser.deleteById(id);
	}


	public static Recharge update() throws RechargeException {
		System.out.println("Enter the Transaction id");
		int id = scan.nextInt();
		System.out.println("Enter the description which you want to update");
		String desc = scan.next();
		iser=new RechargeServiceImpl();
		return iser.update(id,desc);
	}


	public static Recharge viewTransactionByID() throws RechargeException {
		System.out.println("Enter the Transaction id");
		int id = scan.nextInt();
		iser=new RechargeServiceImpl();
		return iser.viewTransactionByID(id);
	}


	public static Collection<Recharge> viewAllTransaction() throws RechargeException {
		iser=new RechargeServiceImpl();
		return iser.viewAllTransaction();
	}


	public static int recharge() throws RechargeException {
		iser=new RechargeServiceImpl();
		String name = null, mob=null, rechType=null, plan=null;
		long amt=0;
		boolean res=false;
		
		//getting input from client and validating name
		do{
			try{
				System.out.println("Enter the name");
				name = scan.next();
				res=iser.validateName(name);
			}
			catch(RechargeException e)
			{
				System.out.println(e.getMessage());
			}
		}while(!res);
		
		//getting input from client and validating mobile number
		res=false;
		do{
			try{
				System.out.println("Enter the mobile number which contains ten digits");
				mob = scan.next();
				res= iser.validateMob(mob);
				}
				catch(RechargeException e)
				{
					res=false;
					System.out.println(e.getMessage());
				}
		}while(!res);
		
		//getting input from client and validating recharge type
		res=false;
		do{
			try{
			System.out.println("Enter the recharge type prepaid/postpaid");
			rechType=scan.next();
			res = iser.validateType(rechType);
			}catch (RechargeException e) {
				System.out.println(e.getMessage());
			}
		}while(!res);
		
		//getting input from client and validating planName
		res=false;
		do{
				System.out.println("enter any plan which you want");
				System.out.println("1. RC99 \n2. RC199\n3. RC399");
				System.out.println("4. RC499");
				switch(scan.nextInt()){
				case 1:amt=99;
						if(balance>0 && balance>=amt){
								balance-=amt;}
						else{amt=0;}
						plan="RC99";
						res=true;
						break;
				case 2:amt=199;
						if(balance>0 && balance>=amt){
							balance-=amt;}
						else{amt=0;}
						plan="RC199";res=true;
						break;
				case 3:amt=399;
						if(balance>0 && balance>=amt){
							balance-=amt;}
						else{amt=0;}
						plan="RC399";res=true;
						break;
				case 4:amt=499;
						if(balance>0 && balance>=amt){
								balance-=amt;}
						else{amt=0;}
						plan="RC499";res=true;
						break;
				default:System.out.println("Wrong plan selection");res=false;
				break;
				}
		}while(!res);
		
		System.out.println("Enter the description");
		String desc = scan.next();
		//calling bean
		Recharge recharge = new Recharge(name, mob, rechType, plan, amt, desc);
		
		//calling service class
		int rechId=iser.recharge(recharge);
		return rechId;
	}

}
