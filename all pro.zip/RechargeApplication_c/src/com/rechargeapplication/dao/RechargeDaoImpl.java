package com.rechargeapplication.dao;

import java.util.Collection;

import com.rechargeapplication.bean.Recharge;
import com.rechargeapplication.exception.RechargeException;
import com.rechargeapplication.util.RechargeUtil;

public class RechargeDaoImpl implements IRechargeDao{

	//recharging
	@Override
	public int recharge(Recharge recharge) throws RechargeException {
		if(recharge.getAmount()>0){
			RechargeUtil.rechargeList().put(recharge.getRechargeId(), recharge);
			return recharge.getRechargeId();
		}
		throw new RechargeException("Recharge is not possible because amount is zero");
	}

	//view All Transactions
	@Override
	public Collection<Recharge> viewAllTransactions() throws RechargeException {
		if(RechargeUtil.rechargeList().isEmpty())
			throw new RechargeException("No transaction Exist");
		return RechargeUtil.rechargeList().values();
	}

	//view Transaction by id
	@Override
	public Recharge viewTransactionByID(int id) throws RechargeException {
		if(RechargeUtil.rechargeList().containsKey(id))
			return RechargeUtil.rechargeList().get(id);
		throw new RechargeException("This transaction does not exist");
	}

	//updating description
	@Override
	public Recharge update(int id, String desc) throws RechargeException {
		if(RechargeUtil.rechargeList().containsKey(id)){
			RechargeUtil.rechargeList().get(id).setDesc(desc);
			return RechargeUtil.rechargeList().get(id);}
		throw new RechargeException("This transaction does not exist");
	}

	@Override
	public void deleteById(int id) throws RechargeException {
		if(RechargeUtil.rechargeList().containsKey(id)){
			RechargeUtil.rechargeList().remove(id);
		}
		throw new RechargeException("This transaction does not exist");
	}

}
