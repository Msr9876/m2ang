package com.rechargeapplication.dao;

import java.util.Collection;

import com.rechargeapplication.bean.Recharge;
import com.rechargeapplication.exception.RechargeException;

public interface IRechargeDao {

	int recharge(Recharge recharge) throws RechargeException;

	Collection<Recharge> viewAllTransactions() throws RechargeException;

	Recharge viewTransactionByID(int id) throws RechargeException;

	Recharge update(int id, String desc) throws RechargeException;

	void deleteById(int id) throws RechargeException;

}
