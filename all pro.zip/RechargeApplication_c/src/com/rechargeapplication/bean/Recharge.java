package com.rechargeapplication.bean;

import java.time.LocalDate;

public class Recharge {

	String name;
	String mob;
	String rechargeType;
	String planName;
	String desc;
	LocalDate date;
	int rechargeId;
	long amount;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMob() {
		return mob;
	}

	public void setMob(String mob) {
		this.mob = mob;
	}

	public String getRechargeType() {
		return rechargeType;
	}

	public void setRechargeType(String rechargeType) {
		this.rechargeType = rechargeType;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public int getRechargeId() {
		return rechargeId;
	}

	public void setRechargeId(int rechargeId) {
		this.rechargeId = rechargeId;
	}

	public long getAmount() {
		return amount;
	}

	public void setAmount(long amount) {
		this.amount = amount;
	}

	public Recharge() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Recharge(String name, String mob, String rechargeType,
			String planName, long amount, String desc) {
		super();
		this.name = name;
		this.mob = mob;
		this.rechargeType = rechargeType;
		this.planName = planName;
		this.amount = amount;
		this.desc = desc;
	}
	
	public String toString(){
		return "Recharge id: "+rechargeId+"\nname: "+name+"\nmobile number: "+mob+"\nrecharge Type: "+rechargeType+"\nplanName: "+planName+"\namount: "+amount+"\ndescription: "+desc;
	}
}
