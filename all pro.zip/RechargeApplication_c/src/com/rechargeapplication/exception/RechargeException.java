package com.rechargeapplication.exception;

public class RechargeException extends Exception{
	
	public RechargeException() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public RechargeException(String msg){
		super(msg);
	}
}
