package com.rechargeapplication.util;

import java.util.HashMap;
import java.util.Map;

import com.rechargeapplication.bean.Recharge;

public class RechargeUtil {

	static Map<Integer,Recharge> rechMap = new HashMap<Integer, Recharge>();
	
	public static Map<Integer,Recharge> rechargeList(){
		return rechMap;
	}
}

