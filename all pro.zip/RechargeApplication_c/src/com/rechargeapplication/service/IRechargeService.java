package com.rechargeapplication.service;

import java.util.Collection;

import com.rechargeapplication.bean.Recharge;
import com.rechargeapplication.exception.RechargeException;

public interface IRechargeService {

	boolean validateName(String name) throws RechargeException;

	boolean validateMob(String mob) throws RechargeException;

	boolean validateType(String rechType) throws RechargeException;

	int recharge(Recharge recharge) throws RechargeException;

	Collection<Recharge> viewAllTransaction() throws RechargeException;

	Recharge viewTransactionByID(int id) throws RechargeException;

	Recharge update(int id, String desc) throws RechargeException;

	void deleteById(int id) throws RechargeException;

}
