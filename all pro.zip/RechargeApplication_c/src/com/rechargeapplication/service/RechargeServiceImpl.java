package com.rechargeapplication.service;

import java.time.LocalDate;
import java.util.Collection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.rechargeapplication.bean.Recharge;
import com.rechargeapplication.dao.IRechargeDao;
import com.rechargeapplication.dao.RechargeDaoImpl;
import com.rechargeapplication.exception.RechargeException;

public class RechargeServiceImpl implements IRechargeService{

	static Matcher m= null;
	static IRechargeDao idao = null;
	
	//validating name
	public boolean validateName(String name) throws RechargeException
	{
		m=Pattern.compile("^[A-Z]([a-z]){3,}$").matcher(name);
		if(!m.find())
			throw new RechargeException("Name is not matching");
		return true;
	}

	
	//validating mobile
	@Override
	public boolean validateMob(String mob) throws RechargeException {
		m=Pattern.compile("^[6789]([0-9]){9}$").matcher(mob);
		if(!m.find())
			throw new RechargeException("This number is not valid");
		return true;
	}

	//valicating recharge Type
	@Override
	public boolean validateType(String rechType) throws RechargeException {
		if(!(rechType.equalsIgnoreCase("prepaid") || rechType.equalsIgnoreCase("postpaid")))
			throw new RechargeException("Wrong recharge type");
		return true;
	}

	//Recharging
	@Override
	public int recharge(Recharge recharge) throws RechargeException {
		recharge.setDate(LocalDate.now());
		recharge.setRechargeId(generateID());
		idao=new RechargeDaoImpl();
		return idao.recharge(recharge);
	}

	//generating recharge id
	private int generateID() {
		return (int)(Math.random()*1000);
	}

	//view All Transactions
	@Override
	public Collection<Recharge> viewAllTransaction() throws RechargeException {
		idao=new RechargeDaoImpl();
		return idao.viewAllTransactions();
	}

	//view Transaction by id
	@Override
	public Recharge viewTransactionByID(int id) throws RechargeException {
		idao=new RechargeDaoImpl();
		return idao.viewTransactionByID(id);
	}


	@Override
	public Recharge update(int id, String desc) throws RechargeException {
		idao=new RechargeDaoImpl();
		return idao.update(id,desc);
	}


	@Override
	public void deleteById(int id) throws RechargeException {
		idao=new RechargeDaoImpl();
		idao.deleteById(id);
	}

}
