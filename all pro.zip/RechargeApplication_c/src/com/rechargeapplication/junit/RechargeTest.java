package com.rechargeapplication.junit;

import java.time.LocalDate;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.rechargeapplication.bean.Recharge;
import com.rechargeapplication.dao.IRechargeDao;
import com.rechargeapplication.dao.RechargeDaoImpl;
import com.rechargeapplication.exception.RechargeException;

public class RechargeTest {

	private static IRechargeDao idao = null;
	
	@Before
	public void init(){
		idao=new RechargeDaoImpl();
	}
	
	@After
	public void destroy(){
		idao=null;
	}
	
	@Test
	public void recharge() {
		Recharge rech = new Recharge("chaitra", "7890654321", "prepaid", "RC99", 99, "recharging-99");
		rech.setDate(LocalDate.now());
		rech.setRechargeId(1001);
		try {
			Assert.assertEquals(1001, idao.recharge(rech));
		} catch (RechargeException e) {
			System.out.println(e.getMessage());
		}
	}
	
	@Test
	public void viewAllTransaction() {
		Recharge rech = new Recharge("chaitra", "7890654321", "prepaid", "RC99", 99, "recharging-99");
		rech.setDate(LocalDate.now());
		rech.setRechargeId(1001);
		try {
			idao.recharge(rech);
			Assert.assertNotNull(idao.viewAllTransactions());
		} catch (RechargeException e) {
			System.out.println(e.getMessage());
		}
	}
	
	@Test
	public void viewAllTransactionById(){
		Recharge rech = new Recharge("chaitra", "7890654321", "prepaid", "RC99", 99, "recharging-99");
		rech.setDate(LocalDate.now());
		rech.setRechargeId(1001);
		try {
			idao.recharge(rech);
			Assert.assertNotNull(idao.viewTransactionByID(1001));
		} catch (RechargeException e) {
			System.out.println(e.getMessage());
		}	
	}
	
}
