package com.cg.bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegistrationPageFactory {
	WebDriver driver;
	
	@FindBy(name="userid")
	@CacheLookup
	WebElement userID;
	
	@FindBy(name="passid")
	@CacheLookup
	WebElement password;
	
	@FindBy(name="username")
	@CacheLookup
	WebElement name;
	
	@FindBy(name="address")
	@CacheLookup
	WebElement address;
	
	@FindBy(name="country")
	@CacheLookup
	WebElement country;
	
	@FindBy(name="zip")
	@CacheLookup
	WebElement zipCode;
	
	@FindBy(name="email")
	@CacheLookup
	WebElement emailID;
	
	@FindBy(name="sex")
	@CacheLookup
	WebElement sex;
	
	@FindBy(name="en")
	@CacheLookup
	WebElement language;
	
	@FindBy(id="desc")
	@CacheLookup
	WebElement about;
	
	@FindBy(name="submit")
	@CacheLookup
	WebElement submit;

	public RegistrationPageFactory(WebDriver driver) {		
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public String getUserID() {
		return userID.getAttribute("value");
	}

	public void setUserID(String userID) {
		this.userID.sendKeys(userID);
	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password .sendKeys(password);
	}

	public String getName() {
		return name.getAttribute("value");
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public String getAddress() {
		return address.getAttribute("value");
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public String getCountry() {
		return country.getAttribute("value");
	}

	public void setCountry(String country) {
		this.country.sendKeys(country);
	}

	public String getZipCode() {
		return zipCode.getAttribute("value");
	}

	public void setZipCode(String zipCode) {
		this.zipCode.sendKeys(zipCode);
	}

	public String getEmailID() {
		return emailID.getAttribute("value");
	}

	public void setEmailID(String emailID) {
		this.emailID.sendKeys(emailID);
	}

	public String getSex() {
		return sex.getAttribute("value");
	}

	public void setSex(String sex) {
		this.sex.sendKeys(sex);
	}

	public String getLanguage() {
		return language.getAttribute("value");
	}

	public void setLanguage(String language) {
		this.language.sendKeys(language);
	}

	public String getAbout() {
		return about.getAttribute("value");
	}

	public void setAbout(String about) {
		this.about.sendKeys(about);
	}

	public WebElement getSubmit() {
		return submit;
	}

	public void setSubmit() {
		this.submit.click();
	}
	
	
	
	
}
