package com.cg.jobs;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.bean.RegistrationPageFactory;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class JobsStepDefinition {

	private WebDriver driver;
	private RegistrationPageFactory registerpageFactory; 
	
	@Before
	public void Init() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\samajeti\\Desktop\\Module4_177389\\jobs\\libs\\chromedriver.exe");
		driver= new ChromeDriver();
	}
	
	@After
	public void tearDown() throws InterruptedException {
		Thread.sleep(3000);
		this.driver.close();
	}
	
	@Given("User is on {string} page")
	public void user_is_on_page(String page) {
		this.driver.get("C:\\Users\\samajeti\\Desktop\\Module4_177389\\jobs\\htmlpages\\"+page+".html");
		registerpageFactory =new RegistrationPageFactory(driver);
		
	}

	@When("User  enters valid details")
	public void user_enters_valid_details() throws InterruptedException {
		registerpageFactory.setUserID("CGI");
		registerpageFactory.setPassword("Capgemini123");
		registerpageFactory.setName("Sairam");
		registerpageFactory.setAddress("Sipcot,navallur");
		registerpageFactory.setCountry("India");
		registerpageFactory.setZipCode("600001");
		registerpageFactory.setEmailID("sairam@capgemini.com");
		registerpageFactory.setSex("Male");
		registerpageFactory.setLanguage("English");
		registerpageFactory.setAbout("Registration successful");
		Thread.sleep(2000);
	
	}

	@Then("prints {string}")
	public void prints(String about) throws InterruptedException {
	  
		if(registerpageFactory.getUserID().equals("CGI")&&registerpageFactory.getPassword().equals("Capgemini123")&&
				registerpageFactory.getName().equals("Sairam")&&registerpageFactory.getAddress().equals("Sipcot,navallur")&&
				registerpageFactory.getZipCode().equals("600001")&&registerpageFactory.getEmailID().equals("sairam@capgemini.com")&&registerpageFactory.getSex().equals("Male")
				&&registerpageFactory.getCountry().equals("India")&&registerpageFactory.getLanguage().equals("English")) 
		{
			Thread.sleep(3000);
			registerpageFactory.setAbout(about);
			
		}
		else {
	    	Thread.sleep(3000);
	    	registerpageFactory.setSubmit();
	    }
	}

}
