package com.cg.jobs;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Welcome to JobsWorld!" );
    }
}
