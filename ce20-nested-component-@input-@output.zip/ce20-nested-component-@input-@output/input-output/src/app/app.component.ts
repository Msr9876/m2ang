import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  outerrating : number = 100;
  innerrating : number;
  handleEvent(value:number):void{
   console.log("App Component " + value);
   this.innerrating = value;
  }
}
