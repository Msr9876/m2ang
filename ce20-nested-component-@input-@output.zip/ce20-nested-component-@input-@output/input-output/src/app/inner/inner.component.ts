import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-inner',
  templateUrl: './inner.component.html',
  styleUrls: ['./inner.component.css']
})
export class InnerComponent  {

  //@Input() innerrating : number;
  @Output() innerratingClicked = new EventEmitter<number>();

  testrating :number = 200;
  ratingClicked():void {
    console.log(this.testrating);
    this.innerratingClicked.emit(this.testrating);
  }
}
