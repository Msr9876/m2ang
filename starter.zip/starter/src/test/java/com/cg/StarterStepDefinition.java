package com.cg;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


import com.cg.beans.HotelLoginPageFactory;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StarterStepDefinition {

	private WebDriver driver;
	private HotelLoginPageFactory loginPageFactory;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\mohamf\\Desktop\\Chaitra\\starter\\lib\\chromedriver.exe");
		this.driver = new ChromeDriver();

	}
	
	@After
	public void teardown() throws InterruptedException {
		Thread.sleep(3000);
		this.driver.close();
	}
	
	@Given("user is on {string} Page")
	public void user_is_on_Page(String page) {
		driver.get(
				"file:///C:/Users/mohamf/Desktop/Chaitra/starter/src/test/java/com/cg/htmlpages/"+page+".html");
		loginPageFactory = new HotelLoginPageFactory(driver);
	}

	@When("user enters invalid UserName")
	public void user_enters_invalid_UserName() {
		loginPageFactory.setUserName("");
	}

	@Then("user click the login button and print {string}")
	public void user_click_the_login_button_and_print(String message) throws InterruptedException {
		if (loginPageFactory.getUserName().equals("") || loginPageFactory.getPassword().equals("")) {
			loginPageFactory.setError(message);
		} else {
			Thread.sleep(3000);
			loginPageFactory.setLoginButton();
		}
	}
}
