#install ang 6 data table
npm i --save angular-6-datatable

#Import the data table module “DataTableModule” in your app module
import { DataTableModule } from 'angular-6-datatable';

#create
[user-list]
ng g c user-list

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-user-list',
  templateUrl: './app-user-list.component.html',
  styleUrls: ['./app-user-list.component.css']
})
export class AppUserListComponent implements OnInit {
  constructor() {}

  public data: any;

  ngOnInit() {
    this.data = [
      { name: 'a', email: 'Tom@mail.com', age: '34', city: 'Noida, UP, India' },
      { name: 'Anil', email: 'mail@mail.com', age: '134', city: 'Noida' },
      { name: 'Sunil', email: '1mail@mail.com', age: '4', city: '1Noida' },
      { name: 'Alok', email: '2mail@mail.com', age: '34', city: '2Noida' },
      { name: 'Tinku', email: 'mail@mail.com', age: '34', city: 'Noida' },
      { name: 'XYZ', email: 'mail@mail.com', age: '34', city: 'Noida' },
      { name: 'asas', email: 'mail@mail.com', age: '34', city: 'Noida' },
      { name: 'erer', email: 'mail@mail.com', age: '34', city: 'Noida' },
      { name: 'jhjh', email: 'mail@mail.com', age: '34', city: 'Noida' }
    ];
  }
}

<div class="container" style="width:500px">
    <table class="table table-striped" [mfData]="data" #mf="mfDataTable" [mfRowsOnPage]="5">
        <thead>
        <tr>
            <th style="width: 20%">
                <mfDefaultSorter by="name">UserName</mfDefaultSorter>
            </th>
            <th style="width: 50%">
                <!-- <mfDefaultSorter by="email">UserEmail</mfDefaultSorter> -->
                <mfDefaultSorter by="email">UserEmail</mfDefaultSorter>
            </th>
            <th style="width: 10%">
                <mfDefaultSorter by="age">Age</mfDefaultSorter>
            </th>
            <th style="width: 20%">
                <mfDefaultSorter by="city">User City</mfDefaultSorter>
            </th>
        </tr>
        </thead>
        <tbody>
        <tr *ngFor="let user of mf.data">
            <td>{{user.name}}</td>
            <td>{{user.email}}</td>
            <td class="text-right">{{user.age}}</td>
            <td>{{user.city | uppercase}}</td>
        </tr>
        </tbody>
        <tfoot>
        <tr>
            <td colspan="4">
                <mfBootstrapPaginator [rowsOnPageSet]="[5,10,25]"></mfBootstrapPaginator>
            </td>
        </tr>
        </tfoot>
      </table>
</div>

#create global style 
[style.css]
@import "//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css";
@import "//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css";
[or]
[user-list]
@import "//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css";
@import "//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css";


