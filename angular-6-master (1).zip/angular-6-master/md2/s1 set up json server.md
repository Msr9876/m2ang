#SET UP JSON SERVER
[install]
npm install -g json-server

#create db.json
{
  "employees": [
    {
      "id": 1,
      "employee_name": "Sams",
      "employee_salary": 100,
      "employee_age": 50
    },
    {
      "id": 2,
      "employee_name": "Sams",
      "employee_salary": 1000,
      "employee_age": 500
    }
  ]
}

[run]
json-server --watch db.json

