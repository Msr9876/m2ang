[list-emp]
ng g c list-emp

[app.component]
<app-list-emp></app-list-emp>

[list-emp]
<div class="col-md-12">
  <h2> User Details</h2>
  <div class="table-responsive table-container">
    <table class="table">
      <thead>
        <tr>
          <th>Id</th>
          <th>Employee Name</th>
          <th>Salary</th>
          <th>Age</th>
        </tr>
      </thead>
      <tbody>
        <tr *ngFor="let emp of employees">
          <td class="hidden">{{emp.id}}</td>
          <td>{{emp.employee_name}}</td>
          <td>{{emp.employee_salary}}</td>
          <td>{{emp.employee_age}}</td>
          <td>
            <button (click)="deleteEmp(emp)" class="btn btn-info"> Delete</button>
            <button (click)="editEmp(emp)" style="margin-left: 20px;" class="btn btn-info"> Edit</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</div>  

#create model folder inside app
[employee.model.ts]
export class Employee {
    id?: number;
    employee_name?: string;
    employee_salary?: number;
    employee_age?: number;
}

[list-emp]
import { Component, OnInit } from '@angular/core';
import { Employee } from '../model/employee.model';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-list-emp',
  templateUrl: './list-emp.component.html',
  styleUrls: ['./list-emp.component.css']
})
export class ListEmpComponent implements OnInit {

  employees: Employee[];
baseUrl: string = 'http://localhost:3000/employees';

  constructor(private http: HttpClient) { }
  
  getEmployees() {
    return this.http.get<Employee[]>(this.baseUrl);
  }

  ngOnInit() {
    this.getEmployees()
      .subscribe((data: Employee[]) => {
        this.employees = data;
      });
    console.log(this.employees);
  }

}

[app.module]
@NgModule({
  declarations: [
    AppComponent,
    ListEmpComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
