import { Injectable } from '@angular/core';
import { Movie } from  '../model/movies.model';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MoviesService {

  constructor(private http: HttpClient) { }
  baseUrl:  string ='http://localhost:3000/movies';

  getMovies(){
    return this.http.get<Movie[]>(this.baseUrl);
  }

  deleteMovies(id : number){
    return this.http.delete<Movie[]>(this.baseUrl + '/' +id);
  }
  
  createUser(movie:Movie){
    return this.http.post<Movie[]>(this.baseUrl, movie);
  }

  getMovieById(id:number){
    return this.http.get<Movie[]>(this.baseUrl+ "/" +id);
    } 

  updateMovie(movie: Movie) {  
    return this.http.put(this.baseUrl + '/' + movie.id, movie);  
  }  
}
