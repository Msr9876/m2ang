package com.empmgmtwithexceptionalhandling.ui;

import java.util.Scanner;

import com.EmpMgmtwithExceptionHandling.bean.Employee;
import com.empmgmtwithexceptionalhandling.service.IEmployeeService;
import com.empmgmtwithexceptionalhandling.service.Trainee;



public class EmployeeUi {

	static Scanner scan = new Scanner(System.in);
	static IEmployeeService iserv=null;
	public static void main(String[] args) {
	
		System.out.println("Select any of the below mentioned option number:");
		System.out.println(" 1.Add employee\n 2.Delete employee\n 3.View all employee");
		System.out.println("4.View by id\n 5.Update employee details");
		switch(scan.nextInt()){
		
		case 1: 			
				int finalEmpId=addEmployee();
				System.out.println("Employee info is stored");
				System.out.println("ur account id is "+finalEmpId);
			
				break;

		case 2:
			int delid=deleteemployee();
			break;

		case 3: 
				
			break;

		case 4:
			break;

		case 5:
			break;
		}
				
		
	}

	

	private static int deleteemployee() {
		// TODO Auto-generated method stub
		return 0;
	}



	static String empname;
	static int salary;
	static String doj;
	static String pwd;
	

	private static  int  addEmployee() {	
		
		
		Employee emp=new Employee(empname, salary, doj, pwd);
		iserv=new Trainee();
		int eid=0;
		boolean res=false;
		
		do {
			try {
				System.out.println("enter the account name");
				 empname = scan.next();
				res = iserv.validateName(empname);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		} while (!res);		
		

		
		
//		do {
//			try {
//				System.out.println("enter the Salary");
//				 salary= scan.nextInt();
//				res = iserv.validateSalary(salary);
//			} catch (Exception e) {
//				System.out.println(e.getMessage());
//			}
//		} while (!res);
		
		
		
		do
		{
			System.out.println(" Enter Salary greater than zero");
			salary=scan.nextInt();
		}while(iserv.validateSalary(salary)==false);
		
		do
		{
			System.out.println(" Enter date of joining in DD/MM/YYYY format");
			doj=scan.next();
		}while(iserv.validateDateofJoin(doj)==false);
		
		do
		{
			System.out.println(" Enter the password greater than 8 digits");
			pwd=scan.next();
		}while(iserv.validatePassword(pwd)==false);
		

		eid=iserv.addEmployee(emp);		     
        return eid;
    
        
        
    	
		
		
	}
}
	
	

