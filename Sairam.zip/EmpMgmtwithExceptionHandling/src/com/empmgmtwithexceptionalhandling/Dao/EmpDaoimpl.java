package com.empmgmtwithexceptionalhandling.Dao;

import java.util.HashMap;

import com.EmpMgmtwithExceptionHandling.bean.Employee;

public class EmpDaoimpl implements IEmpDao {

	static HashMap<Integer,Employee> m1=new HashMap<Integer, Employee>();
	@Override
	public int addEmployee(Employee emp) {
		m1.put(emp.getEmpid(),emp);
		System.out.println(m1);
		return emp.getEmpid();
		
		
	}

	@Override
	public void deleteById() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void viewAllEmployee() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void viewById() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

	
}
