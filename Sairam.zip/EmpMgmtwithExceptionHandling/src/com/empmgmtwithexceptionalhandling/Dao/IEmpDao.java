package com.empmgmtwithexceptionalhandling.Dao;
import com.EmpMgmtwithExceptionHandling.bean.Employee;

public interface IEmpDao  {

	public int addEmployee(Employee emp);
	public void deleteById();
	public void viewAllEmployee();
	public void viewById();
	public void update();
}
