package com.empmgmtwithexceptionalhandling.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.EmpMgmtwithExceptionHandling.bean.Employee;
import com.empmgmtwithexceptionalhandling.Dao.EmpDaoimpl;
import com.empmgmtwithexceptionalhandling.Dao.IEmpDao;

public class Trainer {

	IEmpDao idao=null;
	Matcher m=null;
	private int generateEmployeeId(){
		int id;
		id= (int)(Math.random()*10000);
		return id;
	}
	public int addEmployee(Employee emp) {
		
		emp.setEmpid(generateEmployeeId());//modicf
		//pass to dao
		idao=new EmpDaoimpl();
		return idao.addEmployee(emp);
	}

	@Override
	public void deleteById() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void viewAllEmployees() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void viewById() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateEmployees() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean validateName(String name) {
		// TODO Auto-generated method stub
		
		Pattern p=Pattern.compile("^[A-Z]([a-z]){3,}");
		m=p.matcher(name);
		if(m.find()){
		return true;
		}
		return false;
	}
	@Override
	public boolean validateSalary(int salary) {
		if (salary>0)
			return true;

		return false;
	}
	
}


