package com.empmgmtwithexceptionalhandling.service;

import com.EmpMgmtwithExceptionHandling.bean.Employee;


public interface IEmployeeService {

	public int addEmployee(Employee emp);
	public void	deleteById();
	public void viewAllEmployees();
	public void viewById();
	public void updateEmployees();
	
	public boolean validateName(String name);
	public boolean validateSalary(int salary);
	public boolean validateDateofJoin(String doj);
	public boolean validatePassword(String pwd);
	
	
	
}
