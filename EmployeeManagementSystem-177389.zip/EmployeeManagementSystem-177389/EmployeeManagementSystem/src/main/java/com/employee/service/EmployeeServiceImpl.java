package com.employee.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.employee.dao.IEmployeeDao;
import com.employee.entity.Employee;


@Service
public class EmployeeServiceImpl 
{
	@Autowired
	IEmployeeDao employeeDao;
	
	

    public Employee createEmployee(Employee employee) {
        return this.employeeDao.save(employee);
    }

    
    public Employee updateEmployee(Employee employee) {
        return this.employeeDao.save(employee);
    }
    
    public void deleteUserById(int id) {
        this.employeeDao.deleteById(id);
    }

   
    public List<Employee> viewEmployeeList() {
        return this.employeeDao.findAll();
    }

    public Optional<Employee> findEmployeeById(int id) {
        return this.employeeDao.findById(id);
    }

    
    public void deleteAllUsers() {
        this.employeeDao.deleteAll();
    }



}
