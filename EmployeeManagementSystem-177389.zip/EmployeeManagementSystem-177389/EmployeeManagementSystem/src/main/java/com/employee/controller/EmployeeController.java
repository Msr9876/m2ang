package com.employee.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.employee.entity.Employee;
import com.employee.exception.EmployeeNotFoundException;
import com.employee.service.EmployeeServiceImpl;

@RestController
@RequestMapping("/employees")


public class EmployeeController
{
	@Autowired
	EmployeeServiceImpl employeeService;

	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public List<Employee> viewEmployeeList() {
		return this.employeeService.viewEmployeeList();
	}

	@RequestMapping(value = "/addemployee", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Employee addUser(@RequestBody Employee employee) {
		return this.employeeService.createEmployee(employee);
	}

	@RequestMapping(value = "/updateemployee", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Employee updateUser(@RequestBody Employee employee) {
		return this.employeeService.updateEmployee(employee);
	}



	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Optional<Employee> getEmployee(@PathVariable int id) throws EmployeeNotFoundException{
		Optional<Employee> employee = this.employeeService.findEmployeeById(id);
		System.out.println(employee.isPresent());
		if(!employee.isPresent())
			throw new EmployeeNotFoundException("USER with this id does not exist!");
		//return this.userService.getUserById(id);
		return employee;
	}
	
	

	@RequestMapping(value = "/delete/all", method = RequestMethod.DELETE)
	public void deleteAllUsers() {
		this.employeeService.deleteAllUsers();
	}

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
	public void deleteUser(@PathVariable int id) {
		this.employeeService.deleteUserById(id);
	}

}
