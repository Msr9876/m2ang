export class Game{

    id: number;
  
  gName: string;
  
  price:number;
  
  }
  
  