package com.cg.mobshop.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.cg.mobshop.dao.MobileDAO;
import com.cg.mobshop.dao.MobileDAOImpl;
import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MobileShopException;
import com.cg.mobshop.util.Util;

public class MobileServiceImpl implements MobileService{
	private MobileDAO mobileDAO = new MobileDAOImpl(); 

	@Override
	public List<Mobiles> getMobileList() throws MobileShopException {
		return mobileDAO.getMobileList();
	}

	@Override
	public List<Mobiles> deleteMobile(int mobcode) throws MobileShopException {
		return mobileDAO.deleteMobile(mobcode);
	}

	@Override
	public List<Mobiles> SortList(int criteria) throws MobileShopException {
		
		return mobileDAO.SortList(criteria);
	}

}
