package com.cg.mobshop.exception;

public class MobileShopException extends Exception{

	public MobileShopException(){
		super();
	}
	
	public MobileShopException(String msg){
		super(msg);
	}
}
