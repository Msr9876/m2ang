package com.cg.mobshop.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MobileShopException;
import com.cg.mobshop.util.Util;

public class MobileDAOImpl implements MobileDAO{

	@Override
	public List<Mobiles> getMobileList() throws MobileShopException {
		if(Util.getMobileEntries().isEmpty() || Util.getMobileEntries()==null){
			throw new MobileShopException("Mobile Entries is empty");
		}
		Set<String> keys=Util.getMobileEntries().keySet();
		List<Mobiles> mobilesList = new ArrayList<Mobiles>();
		for(String mob:keys)
		{
			mobilesList.add(Util.getMobileEntries().get(mob));
		}
		return mobilesList;
	}

	@Override
	public List<Mobiles> deleteMobile(int mobcode) throws MobileShopException {
		if(Util.getMobileEntries().containsKey((mobcode+""))==false){
			throw new MobileShopException("This record is not their in list");
		}
		else{
			Util.getMobileEntries().remove((mobcode+""));
		}
		if(Util.getMobileEntries().isEmpty() || Util.getMobileEntries()==null){
			throw new MobileShopException("Mobile Entries is empty");
		}
		Set<String> keys=Util.getMobileEntries().keySet();
		List<Mobiles> mobilesList = new ArrayList<Mobiles>();
		for(String mob:keys)
		{
			mobilesList.add(Util.getMobileEntries().get(mob));
		}
		return mobilesList;
	}

	@Override
	public List<Mobiles> SortList(int criteria) throws MobileShopException {
		if(Util.getMobileEntries().isEmpty() || Util.getMobileEntries()==null){
			throw new MobileShopException("Mobile Entries is empty");
		}
		Set<String> keys=Util.getMobileEntries().keySet();
		List<Mobiles> mobilesList = new ArrayList<Mobiles>();
		for(String mob:keys)
		{
			mobilesList.add(Util.getMobileEntries().get(mob));
		}
		if(criteria==1){
			NameCompare mobileName= new NameCompare();
			Collections.sort(mobilesList, mobileName);
		}
		else if(criteria==2){
			PriceCompare mobilePrice = new PriceCompare();
			Collections.sort(mobilesList, mobilePrice);
		}
		else if(criteria==3){
			IdCompare mobileId = new IdCompare();
			Collections.sort(mobilesList, mobileId);
		}
		
		return mobilesList;
	}

	class NameCompare implements Comparator<Mobiles> 
	{ 
	    public int compare(Mobiles m1, Mobiles m2) 
	    { 
	        return m1.getName().compareTo(m2.getName()); 
	    } 
	} 

	class PriceCompare implements Comparator<Mobiles> 
	{ 
		 public int compare(Mobiles m1, Mobiles m2) 
		    { 
		        if (Integer.parseInt(m1.getPrice()) < Integer.parseInt(m2.getPrice())) return -1; 
		        if (Integer.parseInt(m1.getPrice()) > Integer.parseInt(m2.getPrice())) return 1; 
		        else return 0; 
		    } 
	}
	
	class IdCompare implements Comparator<Mobiles> 
	{ 
	    public int compare(Mobiles m1, Mobiles m2) 
	    { 
	        return m1.getMobileId().compareTo(m2.getMobileId()); 
	    } 
	}

}
