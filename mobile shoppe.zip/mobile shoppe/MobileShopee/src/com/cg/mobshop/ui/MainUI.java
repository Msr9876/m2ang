package com.cg.mobshop.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MobileShopException;
import com.cg.mobshop.service.MobileService;
import com.cg.mobshop.service.MobileServiceImpl;

public class MainUI {
	public static MobileService mobService = new MobileServiceImpl();
	public static Scanner scan = new Scanner(System.in);
	static boolean res=false;
	public static void main(String[] args)  {
		try{
			do{
				System.out.println();
				System.out.println("Welcome to Mobile Shopee");
				List<Mobiles> mob = mobService.getMobileList();
				for(Mobiles mob1: mob){
					System.out.println(mob1);
				}
				System.out.println("1. Sorting\n 2. Delete\n 3. Exit\n");
				switch(scan.nextInt()){
				case 1:sorting();
					break;
				case 2:delete();
					break;
				case 3:System.exit(0);
				break;
				default:System.out.println("Enter the correct option");
				break;
				}
			}while(res==false);
		}catch(MobileShopException msg){
			msg.getMessage();
		}
		
	}
	
	public static void sorting() throws MobileShopException {
		System.out.println("1. Mobile Name\n 2. Mobile Price\n 3. Mobile Id");
		int criteria = scan.nextInt();
		List<Mobiles> mobiles = mobService.SortList(criteria);
		for(Mobiles mobile:mobiles){
			System.out.println(mobile);
		}
	}

	public static void delete() throws MobileShopException {
		System.out.println("Enter the mobile id to delete");
		int mobcode = scan.nextInt();
		List<Mobiles> mobiles = mobService.deleteMobile(mobcode);
		for(Mobiles mobile:mobiles){
			System.out.println(mobile);
		}
	}

}
