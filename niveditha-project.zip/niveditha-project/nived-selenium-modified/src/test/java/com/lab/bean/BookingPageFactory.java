package com.lab.bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class BookingPageFactory {

	WebDriver driver;
	
	
	
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement pffname;
	
	@FindBy(xpath="//*[@id='txtLastName']")
	@CacheLookup
	WebElement pflname;

	@FindBy(how=How.NAME, using="Email")
	@CacheLookup
	WebElement pfemail;

	@FindBy(how=How.NAME, using="mobile")
	@CacheLookup
	WebElement pfmobile;
	
	@FindBy(how=How.NAME, using="city")
	@CacheLookup
	WebElement pfcity;
	
	@FindBy(name="errmsg")
	@CacheLookup
	WebElement errorMessage;
	
	//using how class
	@FindBy(how=How.ID, using="btnPayment")
	@CacheLookup
	WebElement pfbutton;

	// constructor
	public BookingPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	//getter and setter method
	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public String getPffname() {
		return pffname.getAttribute("value");
	}

	public void setPffname(String pffname) {
		this.pffname.sendKeys(pffname);
	}

	public String getPflname() {
		return pflname.getAttribute("value");
	}

	public void setPflname(String pflname) {
		this.pflname.sendKeys(pflname);
	}

	public String getPfemail() {
		return pfemail.getAttribute("value");
	}

	public void setPfemail(String pfemail) {
		this.pfemail.sendKeys(pfemail);
	}

	public String getPfmobile() {
		return pfmobile.getAttribute("value");
	}

	public void setPfmobile(String pfmobile) {
		this.pfmobile.sendKeys(pfmobile);
	}

	public String getPfcity() {
		return pfcity.getAttribute("value");
	}

	public void setPfcity(String pfcity) {
		this.pfcity.sendKeys(pfcity);
	}

	public WebElement getPfbutton() {
		return pfbutton;
	}

	public void setPfbutton() {
		this.pfbutton.click();
	}
	
	public String getErrorMessage() {
		return errorMessage.getAttribute("value");
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage.sendKeys(errorMessage);;
	}
	
}
