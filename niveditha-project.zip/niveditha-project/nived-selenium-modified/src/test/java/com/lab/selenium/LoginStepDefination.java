package com.lab.selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.lab.bean.BookingPageFactory;
import com.lab.bean.LoginPageFactory;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class LoginStepDefination {
	
	private WebDriver driver;
	private LoginPageFactory loginPageFactory;
	private BookingPageFactory bookingPageFactory;
	
	@Before
	public void Init() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\samajeti\\Desktop\\mod4-ref\\starter_demo\\lib\\chromedriver.exe");
		driver= new ChromeDriver();
	}
	
	@After
	public void tearDown() throws InterruptedException {
		Thread.sleep(1000);
		this.driver.close();
	}
	
	@Given("user is on {string} page")
	public void user_is_on_page(String page) {
	    this.driver.get("C:\\Users\\samajeti\\Desktop\\mod4-ref\\nived-selenium-modified\\htmlPages\\"+page+".html");
	    loginPageFactory=new LoginPageFactory(driver);
	}

	@When("user enters invalid UserName and user click on login button")
	public void user_enters_invalid_UserName_and_user_click_on_login_button() throws InterruptedException {
		Thread.sleep(1000);
	    loginPageFactory.setUserName("");
	}
	
	@When("user enters invalid Password and user click on login button")
	public void user_enters_invalid_Password_and_user_click_on_login_button() throws InterruptedException {
		Thread.sleep(1000);
	    loginPageFactory.setPassword("");
	}
	
	@Then("prints {string}")
	public void prints(String errMessage) throws InterruptedException {
	    if(loginPageFactory.getUserName().equals("") || loginPageFactory.getPassword().equals("")) {
	    	Thread.sleep(1000);
	    	loginPageFactory.setErrorMessage(errMessage);
	    	
	    }
	    else {
	    	Thread.sleep(1000);
	    	loginPageFactory.setLoginButton();
	    }
	}

	
	
	@When("user enters invalid UserName and Password and user click on login button")
	public void user_enters_invalid_UserName_and_Password_and_user_click_on_login_button() throws InterruptedException {
		Thread.sleep(1000);
		loginPageFactory.setUserName("");
		loginPageFactory.setPassword("");
		Thread.sleep(1000);
	}

	@Then("Display {string}")
	public void display(String errMessage) throws InterruptedException {
		if(loginPageFactory.getUserName().equals("") && loginPageFactory.getPassword().equals("")) {
	    	Thread.sleep(1000);
	    	loginPageFactory.setErrorMessage(errMessage);
	    	
	    }
	    else {
	    	Thread.sleep(1000);
	    	loginPageFactory.setLoginButton();
	    }
	}

	@When("user enters valid UserName and Password and user click on login button")
	public void user_enters_valid_UserName_and_Password_and_user_click_on_login_button() throws InterruptedException {
		Thread.sleep(1000);
		loginPageFactory.setUserName("cgi");
		loginPageFactory.setPassword("cgi123");
		Thread.sleep(1000);
	}

	@Then("navigate to {string}")
	public void navigate_to(String page) {
		loginPageFactory.setLoginButton();
		
	}
	
	//booking Page
	
	@Given("user is in {string} page")
	public void user_is_in_page(String page) {
	    this.driver.get("C:\\Users\\samajeti\\Desktop\\mod4-ref\\nived-selenium-modified\\htmlPages\\"+page+".html");
	    bookingPageFactory=new BookingPageFactory(driver);
	}
	
	@When("user enters Invalid data and user click on payment button")
	public void user_enters_Invalid_data_and_user_click_on_payment_button() {
		bookingPageFactory.setPffname("");
		bookingPageFactory.setPflname("");
		bookingPageFactory.setPfmobile("");
		bookingPageFactory.setPfemail("");
		bookingPageFactory.setPfcity("");
	}

	@Then("Display as a {string}")
	public void display_as_a(String errMessage) throws InterruptedException {
		if(bookingPageFactory.getPffname().equals("") || bookingPageFactory.getPflname().equals("")) {
	    	Thread.sleep(1000);
	    	bookingPageFactory.setErrorMessage(errMessage);
	    }
	    else {
	    	Thread.sleep(1000);
	    	bookingPageFactory.setPfbutton();
	    }
	}

	@When("user enters Valid data and user click on payment button")
	public void user_enters_Valid_data_and_user_click_on_payment_button() {
		bookingPageFactory.setPffname("CGI");
		bookingPageFactory.setPflname("chennai");
		bookingPageFactory.setPfmobile("9999999999");
		bookingPageFactory.setPfemail("cap@gmail.com");
		bookingPageFactory.setPfcity("Mumbai");
	}

	@Then("Display as {string}")
	public void display_as(String errMessage) throws InterruptedException {
		if(bookingPageFactory.getPffname().equals("CGI") && bookingPageFactory.getPflname().equals("chennai")
				&& bookingPageFactory.getPfmobile().equals("9999999999") && bookingPageFactory.getPfemail().equals("cap@gmail.com")
				&& bookingPageFactory.getPfcity().equals("Mumbai"))  {
	    	Thread.sleep(1000);
	    	bookingPageFactory.setErrorMessage(errMessage);
	    }
	    else {
	    	Thread.sleep(1000);
	    	bookingPageFactory.setPfbutton();
	    }
	}
	
}
