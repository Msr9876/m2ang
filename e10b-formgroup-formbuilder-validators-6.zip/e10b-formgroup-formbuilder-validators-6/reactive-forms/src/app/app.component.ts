import { Component } from '@angular/core';
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators
} from '@angular/forms';
import { log } from 'util';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'reactive-forms';
  myForm: FormGroup;

  // ngOnInit(): void {
  //   this.myForm = new FormGroup({
  //     name: new FormControl('Rambo'),
  //     email: new FormControl(),
  //     message: new FormControl('')
  //   });
  // }

  constructor(private myFormBuilder: FormBuilder) {}
  //USING FormBuilder
  // ngOnInit(): void {
  //   this.myForm = this.myFormBuilder.group({
  //     name: 'Rambo',
  //     email: '',
  //     message: ''
  //   });
  // }

  //USING Validators
  ngOnInit(): void {
    this.myForm = this.myFormBuilder.group({
      name: ['Rambo', Validators.required],
      email: ['',[Validators.required,Validators.pattern('[@.a-z0-9]*')]],
      message:['',[Validators.required,Validators.minLength(5)]]
    });
  }

  onSubmit(form: FormGroup) {
    console.log('Is the form valid ? ', form.valid);
    console.log('name is ', form.value.name);
    console.log('email is ', form.value.email);
    console.log('message is ', form.value.message);
  }
}
