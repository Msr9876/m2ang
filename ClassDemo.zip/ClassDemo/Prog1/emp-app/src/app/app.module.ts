import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ListEmpComponent } from './list-emp/list-emp.component';
import { HttpClientModule } from '@angular/common/http';
import { AddEmpComponent } from './add-emp/add-emp.component';
import { ReactiveFormsModule } from '../../node_modules/@angular/forms';
import { EditEmpComponent } from './edit-emp/edit-emp.component';
import { RouterModule } from '../../node_modules/@angular/router';
import { routes } from './app-routing.module';
import { DataTableModule } from 'angular-6-datatable';
import { LoginComponent } from './login/login.component';

@NgModule({
  declarations: [
    AppComponent,
    ListEmpComponent,
    AddEmpComponent,
    EditEmpComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes),
    DataTableModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
