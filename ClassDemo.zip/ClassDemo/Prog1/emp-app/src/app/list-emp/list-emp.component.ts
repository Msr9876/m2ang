// import { Employee } from './../../../model/employee.model';
import { EmployeeService } from './../service/employee.service';
import { Component, OnInit } from '@angular/core';
import { Employee } from 'model/employee.model';
import {Router} from '@angular/router';

@Component({
  selector: 'app-list-emp',
  templateUrl: './list-emp.component.html',
  styleUrls: ['./list-emp.component.css']
})
export class ListEmpComponent implements OnInit {

  employees: Employee[];
  constructor(private empService: EmployeeService,private router:Router,) { }

  ngOnInit() {
    this.empService.getEmployees().subscribe((data: Employee[]) => {
      this.employees = data;
    }) 

      }

      deleteEmp(employee: Employee): void {
        console.log("deleteEmp");     
        this.empService.deleteEmployees(employee.id)      
         .subscribe(data => {      
          this.employees = this.employees.filter(emp => emp !== employee);       
      
         })

    }
    editEmp(employee:Employee):void{
      localStorage.removeItem('editEmpId');
      localStorage.setItem('editEmpId',employee.id.toString());
      this.router.navigate(['edit-emp']);

    }

    onSubmit()
    {
      this.router.navigate(['login']);
    }

  }







