import { EmployeeService } from '../service/employee.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators } from '../../../node_modules/@angular/forms';
import {Router} from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
LoginForm: FormGroup;
submitted:boolean=false;
invalidLogin:boolean=false;
    
  constructor(private formBuilder:FormBuilder,private empService: EmployeeService,private router:Router) { }
 

  ngOnInit() {
    this.LoginForm=this.formBuilder.group({
      email:['',Validators.required],
      password:['',Validators.required]
    });
  }

  onSubmit(){
    this.submitted=true;
    if(this.LoginForm.invalid){
      return;
    }
  if(this.LoginForm.controls.email.value=='sairam@gmail.com' && this.LoginForm.controls.password.value=='sairam')
  {
    this.router.navigate(['list-emp']);
  }
  else{
    this.invalidLogin=true;
    alert("invalid login details");
  }

  
 }
}