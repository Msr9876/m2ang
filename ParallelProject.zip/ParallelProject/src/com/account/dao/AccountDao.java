package com.account.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.account.bean.Account;
import com.account.bean.Transaction;

public class AccountDao implements IAccountDao
{
	//data stored in HashMap
static Map<Integer,Account> accList=new HashMap<Integer,Account>();
static Map<Integer,Transaction> transList=new HashMap<Integer,Transaction>();
static int newbal,newbalance,newbalance1;
 
	@Override
	public int CreateAccount(Account acc, Transaction transaction) 
	{
		accList.put(acc.getAccountId(), acc);
		System.out.println(accList);
		transList.put(transaction.getTransactionId(), transaction);
//		System.out.println(transList);
		return acc.getAccountId();
	}

	@Override
	public int ShowBalance(int result) 
	{
		Account acc = accList.get(result);
		System.out.println("your balance is :"+acc.getbalance(result));
		 return acc.getbalance(result);
	}

	@Override
	public int Deposit(int accId, int depositamount,Transaction trans)
	{
		Account account= accList.get(accId);
		newbal=(account.getbalance(accId)+depositamount);
		account.setbalance(newbal);
		//System.out.println(newbal);
		// trans.setBalance(newbal);
		transList.put(trans.getTransactionId(),trans);
		return account.getbalance(accId);
	}
	
 
    @Override
	public int Withdraw(int num,int withdraw,Transaction transaction) 
    {
	 Account a=accList.get(num);
	 newbalance=((a.getbalance(num))-withdraw);
	 a.setbalance(newbalance);
	 System.out.println(newbalance);
	 transList.put(transaction.getTransactionId(),transaction);
	 return a.getbalance(num);
		 
	}

 
	@Override
	public int FundTransfer(int acc1, int acc2, int amount, Transaction transaction) 
	{
		 Account a1=accList.get(acc1);
		 Account a2=accList.get(acc2);
		 newbalance1=(a1.getbalance(acc1)-amount);
		 a1.setbalance(newbalance1);
		 //System.out.println(newbalance1);
		 transaction.setTypeOfTrans("FundTransfered");
		 transList.put(transaction.getTransactionId(),transaction);
		 return a1.getbalance(acc1);
	}

	@Override
	public HashMap<Integer,Transaction > printTransaction() 
	{
		 HashMap<Integer,Transaction > transaction = (HashMap<Integer,Transaction >) transList;
		  return transaction;
	}

	 

}
