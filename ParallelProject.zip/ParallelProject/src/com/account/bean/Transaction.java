package com.account.bean;

public class Transaction 
{
private int accountId;
private int transactionId;
private int availBalance;
private String typeOfTrans;
private int transAmount;

//default constructor
public Transaction() {
	super();
	// TODO Auto-generated constructor stub
}

//parameterized constructor
public Transaction(int availbalance, String typeOfTrans, int transAmount) {
	super();
	this.availBalance = availbalance;
	this.typeOfTrans = typeOfTrans;
	this.transAmount = transAmount;
}

//getter setter method
public int getAccountId() {
	return accountId;
}

public void setAccountId(int accountId) {
	this.accountId = accountId;
}

public int getTransactionId() {
	return transactionId;
}

public void setTransactionId(int transactionId) {
	this.transactionId = transactionId;
}

public int getBalance() {
	return availBalance;
}

public void setBalance(int balance) {
	this.availBalance = balance;
}

public String getTypeOfTrans() {
	return typeOfTrans;
}

public void setTypeOfTrans(String typeOfTrans) {
	this.typeOfTrans = typeOfTrans;
}

public int getTransAmount() {
	return transAmount;
}

public void setTransAmount(int transAmount) {
	this.transAmount = transAmount;
}

//to string method
@Override
public String toString() {
	return "Transaction [accountId=" + accountId + ", transactionId="
			+ transactionId + ", availBalance=" + availBalance
			+ ", typeOfTrans=" + typeOfTrans + ", transAmount=" + transAmount
			+ "]";
}


}
