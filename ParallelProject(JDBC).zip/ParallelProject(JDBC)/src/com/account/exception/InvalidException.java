package com.account.exception;

public class InvalidException extends Exception 
{
//exception constructor
	public InvalidException(String i) 
	{
		 super(i);
	}

}
