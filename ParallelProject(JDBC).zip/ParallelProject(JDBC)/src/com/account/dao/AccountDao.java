package com.account.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.account.bean.Account;
import com.account.bean.Transaction;

public class AccountDao implements IAccountDao {
	Connection conn = null;
	PreparedStatement prestatement = null;
	Statement statement = null;

	// user method to establish connection
	private Connection makeConnection() throws SQLException {
		String url = "jdbc:oracle:thin:@10.219.34.3:1521:orcl";
		String user = "trg213";
		String password = "training213";
		conn = DriverManager.getConnection(url, user, password);
		System.out.println("connected");
		return conn;
	}

	//create method
	@Override
	public int CreateAccount(Account acc, Transaction transaction)
			throws SQLException {
		makeConnection();

		// to insert bank
		String qry = "INSERT INTO Bank VALUES('" + acc.getAccountId() + "','"
				+ acc.getHolderName() + "','" + acc.getPhone() + "','"
				+ acc.getAddress() + "','" + acc.getEmailId() + "','"
				+ acc.getPan() + "','" + acc.getbalance() + "')";
		System.out.println(qry);
		Statement st = conn.createStatement();
		int status = st.executeUpdate(qry);

		// DML - insert 
		if (status == 1) {
			System.out.println(status + " inserted ");
		} else {
			System.out.println("not inserted ");
		}

		// to add transaction
       String qry1 = "INSERT INTO Transaction VALUES('"
				+ transaction.getTransactionId() + "','"
				+ transaction.getAccountId() + "','"
				+ transaction.getTypeOfTrans() + "','"
				+ transaction.getTransAmount() + "','"
				+ transaction.getBalance() + "')";
		System.out.println(qry1);
		Statement st1 = conn.createStatement();
		int status1 = st1.executeUpdate(qry1);

		// DML -insert
		if (status1 == 1) {
			System.out.println(status + " inserted ");
		} else {
			System.out.println("not inserted ");
		}

		return acc.getAccountId();
	}

	//show balance method
	@Override
	public int ShowBalance(int accno) throws SQLException {
		makeConnection();
		Statement statement = conn.createStatement();
		String qry = "SELECT * FROM Bank  WHERE accountId =" + accno;
		ResultSet rs = statement.executeQuery(qry);// table

		while (rs.next()) {
			System.out.println("Available balance: " + rs.getInt(7));
		}
		return 0;
	}

	//deposit method
	@Override
	public int Deposit(int accId, int amt, Transaction trans)
			throws SQLException {
		makeConnection();
		Statement statement = conn.createStatement();
		String qry = "SELECT * FROM Bank  WHERE accountId =" + accId;
		ResultSet rs = statement.executeQuery(qry);// table
		
		while (rs.next()) {
            amount = rs.getInt(7) + amt;
		    System.out.println("Available balance: " + amount);

		// to update
		String qry2 = "UPDATE Bank set Balance=" + amount
					+ "WHERE accountId= " + accId;
			int status = statement.executeUpdate(qry2);
			System.out.println(status);
			System.out.println("Available balance: " + amount);
			
			trans.setBalance(amount);
			trans.setTransAmount(amt);
			trans.setTypeOfTrans("Deposit");
 
			// transaction
			String qry1 = "INSERT INTO Transaction VALUES('"
					+ trans.getTransactionId() + "','" + trans.getAccountId()
					+ "','" + trans.getTypeOfTrans() + "','"
					+ trans.getTransAmount() + "','" + trans.getBalance()
					+ "')";
			System.out.println(qry1);
			Statement st1 = conn.createStatement();
			int status1 = st1.executeUpdate(qry);

			// DML - insert
			if (status1 == 1) {
				System.out.println(status1 + " inserted ");
			} else {
				System.out.println("not inserted ");
			}
		}
		return amount;
   }

	//withdraw
	int amount;
    @Override
	public int Withdraw(int num, int wit, Transaction transaction)
			throws SQLException {

		makeConnection();
		Statement statement = conn.createStatement();
		String qry = "SELECT * FROM Bank  WHERE accountId =" + num;
		ResultSet rs = statement.executeQuery(qry);// table
		while (rs.next()) {
			amount = rs.getInt(7) - wit;
			System.out.println("Available balance: " + amount);

			transaction.setBalance(amount);
			transaction.setTransAmount(wit);
			transaction.setTypeOfTrans("withdraw");
			// transaction
			String qry1 = "INSERT INTO Transaction VALUES('"
					+ transaction.getTransactionId() + "','"
					+ transaction.getAccountId() + "','"
					+ transaction.getTypeOfTrans() + "','"
					+ transaction.getTransAmount() + "','"
					+ transaction.getBalance() + "')";
			System.out.println(qry1);
			Statement st1 = conn.createStatement();
			int status1 = st1.executeUpdate(qry);

			// DML -insert 
			if (status1 == 1) {
				System.out.println(status1 + " inserted ");
			} else {
				System.out.println("not inserted ");
			}

			// to update
			String qry2 = "UPDATE Bank set Balance=" + amount
					+ "WHERE accountId= " + num;
			int status = statement.executeUpdate(qry2);
			System.out.println(status);
			System.out.println("Available balance: " + amount);
		}
		return amount;
	}

    //Fund transfer
	int amount1, amount2;
    @Override
	public int FundTransfer(int acc1, int acc2, int amount,
			Transaction transaction) throws SQLException {
		makeConnection();

		 int amount1=0;
		 int amount2=0;
		
		 //withdraw
		 Statement statement = conn.createStatement();
		 String qry="SELECT balance FROM Bank  WHERE accountId =" + acc1;
		 ResultSet rs=statement.executeQuery(qry);//table
		 rs.next();
		
		 amount1=rs.getInt("balance")-amount;
		 System.out.println("Available balance: " +amount1);
		 String qry1="UPDATE Bank set Balance= " +amount1+ "WHERE accountId= "
		 + acc1;
		 int status=statement.executeUpdate(qry1);
		 System.out.println(status);
		
		 //deposit
		 Statement statement1 = conn.createStatement();
		 String qry3="SELECT balance FROM Bank  WHERE accountId =" +acc2;
		 ResultSet rs1=statement1.executeQuery(qry3);//table
		 rs1.next();
		 
		 amount2=(rs1.getInt("balance")+amount);
		 System.out.println("Available balance: " +amount2);
		 String qry2="UPDATE Bank set Balance= " +amount2+ "WHERE accountId= "
		 + acc2;
		 int status1=statement.executeUpdate(qry2);
		 System.out.println(status1);
		
		 return amount;
		 }

    
    //print transaction
	@Override
	public void printTransaction(int accid) throws SQLException {
		 int balance;int transId;int accId;String typeTrans;
		 conn = makeConnection();
		 statement = conn.createStatement();
		 String qry1="select * from Transaction where accountId = "+accid;
		 ResultSet rs = statement.executeQuery(qry1);
		// System.out.println(qry1);
		
		 while(rs.next())
		 {
		 System.out.println("s");
		 transId=rs.getInt(1);
		 accId=rs.getInt(2);
		 typeTrans=rs.getString(3);
		 balance = rs.getInt(4);
		 System.out.println("Transaction ID: "+transId+", Account ID: "+accId+", Type of Transaction: "+typeTrans+", Balance Amount: "+balance);
		 }
	}
}
 