package com.account.service;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Collection;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.account.bean.Account;
import com.account.bean.Transaction;
import com.account.dao.AccountDao;
import com.account.dao.IAccountDao;
import com.account.exception.InvalidException;

public class AccountService implements IAccountService 
{
	static Transaction transaction=new Transaction();
static IAccountDao dao=null;
Matcher m;

//to generate account number
private int generateaccountId() 
{
	int c= (int)(Math.random()*10000);
	return c;
}

//to generate transaction number
private static int generatetransactionId()
{
	int n=(int)(Math.random()*10000);
	return n;
}
 
//create method
	@Override
	public int CreateAccount(Account acc,Transaction trans) throws SQLException 
	{
		acc.setAccountId(generateaccountId());
		trans.setTransactionId(generatetransactionId());
		System.out.println();
		trans.setAccountId(acc.getAccountId());
		dao=new AccountDao();
		 return dao.CreateAccount(acc,trans);
	}
	
	//validation for name
	public boolean validName(String holderName) throws InvalidException
	{
		m=Pattern.compile("^[A-Z]([a-z]){3,16}").matcher(holderName);
		if(!m.find())
		{
			throw new InvalidException("Character not matching");
		}
		return true;
	}
	
	//validation for phone
	public boolean validPhone(String phone) throws InvalidException
	{
		m=Pattern.compile("^[6-9][0-9]{9}").matcher(phone);
		if(!m.find())
		{
			throw new InvalidException("Enter only 10 digit number");
		}
		return true;
	}

	//validation for address
	public boolean validaddress(String address) throws InvalidException
	{
		m=Pattern.compile("^[a-z]{5,}").matcher(address);
		if(!m.find())
		{
			throw new InvalidException("Enter only lowercase letter");
		}
		return true;
	}
	
	//validation for phonenumber
	public boolean validalternatenumber(String alternatenumber) throws InvalidException
	{
		m=Pattern.compile("^[6-9][0-9]{9}").matcher(alternatenumber);
		if(!m.find())
		{
			throw new InvalidException("Enter only 10 digit number");
		}
		return true;
	}
	
	//validation for emailid
	public boolean validemailId(String emailId) throws InvalidException
	{
		m=Pattern.compile("^[A-Z]{1}[a-z]{8}[0-9]{3}@gmail.com").matcher(emailId);
		if(!m.find())
		{
			throw new InvalidException("Enter 1 uppercase character,8 lowewrcase character and 3 numbers ");
		}
		return true;
	}
	
	//validation for pan
	public boolean validPan(String Pan) throws InvalidException
	{
		m=Pattern.compile("^[A-Z]{5}[0-9]{5}").matcher(Pan);
		if(!m.find())
		{
			throw new InvalidException("Enter 5 uppercase character and 5 numbers");
		}
		return true;
	}

	//validation for balance
	public boolean validbalance(int balance) throws InvalidException
	{
		if(balance<1000)
		{
			throw new InvalidException("Maintain minimum balance ");
		}
		return true;
	}
	
	//show balance method
	@Override
	public int ShowBalance(int accno) throws SQLException 
   {
		dao=new AccountDao();
		return dao.ShowBalance(accno);
	}

	//deposit method
	@Override
	public int Deposit(int accId, int amt,Transaction transaction) throws SQLException 
   {
		 dao=new AccountDao();
		 transaction.setTransactionId(generatetransactionId());
		 transaction.setAccountId(accId);
		 transaction.setTransAmount(amt);
		 return dao.Deposit(accId, amt, transaction);
	}

    //withdraw method
	@Override
	public int Withdraw(int num,int wit,Transaction transaction) throws SQLException 
	{
		 dao=new AccountDao();
		 transaction.setTransactionId(generatetransactionId());
	     transaction.setAccountId(num);
		 return dao.Withdraw(num,wit,transaction);
	}

	//fundtransfer method
	@Override
	public int FundTransfer(int acc1, int acc2, int amount,Transaction transaction) throws SQLException 
	{
		 dao=new AccountDao();
		 transaction.setTransactionId(generatetransactionId());
		 transaction.setAccountId(acc1);
		 return dao.FundTransfer(acc1, acc2, amount, transaction);
	}

	//printtransaction method
	@Override
	public void printTransaction(int accid) throws SQLException {
		 dao=new AccountDao();
		  dao.printTransaction(accid);
		  
	}

 

	 

	 
}
