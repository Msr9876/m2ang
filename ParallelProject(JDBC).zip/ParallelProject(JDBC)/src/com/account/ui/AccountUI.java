package com.account.ui;

 

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Collection;
import java.util.HashMap;
import java.util.Scanner;

import com.account.bean.Account;
import com.account.bean.Transaction;
import com.account.exception.InvalidException;
import com.account.service.AccountService;
import com.account.service.IAccountService;

public class AccountUI
{
	static Transaction transaction=new Transaction();
	static IAccountService iserv=null;
static Scanner scan=new Scanner(System.in);
static String var;
static int balance,result1,amt,wit,amount;
static boolean res=false;
public static void main(String[] arg) throws SQLException
{
	do
	{
	System.out.println("Enter details between 1 to 5");
	System.out.println("1. CreateAccount\n 2.ShowBalance\n 3.Deposit\n 4.Withdraw\n 5.FundTransfer\n 6.PrintTransactions");
    switch(scan.nextInt())
    {
    case 1:
    	   iserv=new AccountService();
    	   int finalaccountId=CreateAccount();
    	   System.out.println("your Account Id is :" +finalaccountId);
    	break;
    	
    case 2:
    	   System.out.println("Enter the Account Number to check balance : ");
           int accno=scan.nextInt();
    	   ShowBalance( accno);
    	   break;
    	
    case 3:
    	   System.out.println("Enter the Account number to deposit ");
    	   int accId=scan.nextInt();
    	  // if(accId==)
           System.out.println("Enter the amount to deposit");
   	       amt=scan.nextInt();
    	   Deposit(accId,amt);
           System.out.println("your deposited amount is :" +amt + "  on  " +LocalDate.now());
           //System.out.println("Total amount available in your account is :" +(balance+amt));
    	   break;
    	
    case 4:
    	System.out.println("Enter the account number to withdraw");
    	int num=scan.nextInt();
    	System.out.println("Enter the amount to withdraw");
        wit=scan.nextInt();
    	System.out.println("your withdraw amount is :" + wit+ "  on  " + LocalDate.now());
    	//System.out.println("  Available balance is :" );
    	Withdraw(num,wit);
    	break;
    	
   case 5:FundTransfer();
    	break;
    	
    case 6:
//    	System.out.println("Enter the account number");
//    	int acc3=scan.nextInt();
    	PrintTransaction();
    	break;
    }
    
    System.out.println("Do you want to continue : press y to continue and n to exit");
    var=scan.next();
	}while(var.equalsIgnoreCase("y"));
	
}

 

private static void FundTransfer() throws SQLException
{
	System.out.println("Enter your account number");
  int acc1=scan.nextInt();
  System.out.println("Enter the account number to whom you want to send");
  int acc2=scan.nextInt();
  System.out.println("Enter the amount to transfer ");
  amount=scan.nextInt();
  System.out.println("your account is debited for :" +amount);
  
  iserv=new AccountService();
  int remainingbalance=iserv.FundTransfer(acc1,acc2,amount,transaction);
  System.out.println("remaining balance is : "+remainingbalance+" after transfering amount: "+amount );
	 /*transaction.setTransAmount(amount);
	 transaction.setBalance(remainingbalance);
	 transaction.setTypeOfTrans("FundTransfer");*/
}



private static void PrintTransaction() throws SQLException 
{
	 
	 Transaction trans=new Transaction();
	
	int accountNumber;
	System.out.println("Enter account number to check details");
	accountNumber=scan.nextInt();
	iserv=new AccountService();
	 iserv.printTransaction(accountNumber);
}

 
private static int Withdraw(int num,int wit) throws SQLException 
{
	Transaction transaction=new Transaction();
	iserv=new AccountService();
    int balanceAmount=iserv.Withdraw(num, wit, transaction);
	transaction.setTransAmount(wit);
	transaction.setBalance(balanceAmount);
	transaction.setTypeOfTrans("Withdraw");
	return balanceAmount;
}



private static int Deposit(int accId, int amt) throws SQLException 
{ Transaction transaction=new Transaction();
   iserv=new AccountService();
   int finalAmount=iserv.Deposit(accId, amt, transaction);
  // transaction.setAccountId(accId);
   transaction.setTransAmount(amt);
   transaction.setBalance(finalAmount);
   transaction.setTypeOfTrans("Deposit");
   return finalAmount;
}

private static int ShowBalance(int accno) throws SQLException
{ 
	iserv=new AccountService();
	int value=iserv.ShowBalance(accno);
	return value;
}

private static int CreateAccount() throws SQLException 
{
	String holderName=null,phone=null,address=null,alternatePhone=null,emailId=null,pan=null, bank=null,Accounttype=null;
	int accountId=0;
	
	int availbalance=0,transAmount=0;
	String typeOfTransaction=null;
	transaction.setTransAmount(balance);
	transaction.setBalance(balance);
	transaction.setTypeOfTrans("create account");
	//validated for name
	do
	{
		try
		{
	       System.out.println("Enter the AccountHolder name : ");
	       holderName=scan.next();
	       res=iserv.validName(holderName);
		}catch(InvalidException i)
		{
			System.out.println(i.getMessage());
		}
	}while(!res);
	
	//validated for mobile number
res=false;	
	do
	{
	try
	{
		System.out.println("Enter the Mobile number : ");
		phone=scan.next();
		res=iserv.validPhone(phone); 
	}catch(InvalidException i)
	{
		System.out.println(i.getMessage());
	}
	}while(!res);
	
	//validated for address
	res=false;		
	do
	{
		try
		{
			System.out.println("Enter the adderss : ");
			address=scan.next();
			res=iserv.validaddress(address);
		}catch(InvalidException i) 
		{
			System.out.println(i.getMessage());
		}
	}while(!res);
	
	//validated for alternate number
	res=false;	
	do
	{
		try
		{
			System.out.println("Enter the alternate Mobile Number : ");
			alternatePhone=scan.next();
			res=iserv.validalternatenumber(alternatePhone);
		}catch(InvalidException i)
		{
			System.out.println(i.getMessage());
		}
	}while(!res);
	
	//validated for emailId
	res=false;	
	do
	{
		try
		{
		System.out.println("Enter emailId : ");
		emailId=scan.next();
		res=iserv.validemailId(emailId);
	}catch(InvalidException i)
		{
		System.out.println(i.getMessage());
		}
	}while(!res);
	
	//validated for pan number
	res=false;		
	do
	{
		try
		{
			System.out.println("Enter pan number : ");
			pan=scan.next();
			res=iserv.validPan(pan);
		}catch(InvalidException i)
		{
			System.out.println(i.getMessage());
		}
	}while(!res);
	
	
	//options to select bank and account type
	System.out.println("Select the Bank ");
	System.out.println("1. ICICI Bank\n 2. HDFC Bank\n 3. Axis Bank");
	switch(scan.nextInt())
	{
	case 1: 
		bank="ICICI Bank";
	     System.out.println("Select account type");
	     System.out.println("1.Saving Account\n 2.Current Account");
	     break;
	case 2:
		bank="HDFC Bank";
		 System.out.println("Select account type");
	     System.out.println("1.Saving Account\n 2.Current Account");
	     break;
	case 3:
		bank="Axis Bank";
		//options to select account type
		 System.out.println("Select account type");
	     System.out.println("1.Saving Account\n 2.Current Account");
	     break;
	}
	     switch(scan.nextInt())
	     {
	     case 1:Accounttype="Saving Account";
	     System.out.println("Saving Account is successfully created ");
	     break;
	     
	     case 2:Accounttype="Current Account";
	     System.out.println("Current Account is successfully created");
	     break;
	     }
	     
	     //validation for opening balance
	     res=false;	
	 	do
	 	{
	 		try
	 		{
	 			System.out.println("Enter the openingBalance amount : ");
	 			balance=scan.nextInt();
	 			res=iserv.validbalance(balance);
	 		}catch(InvalidException i)
	 		{
	 			System.out.println(i.getMessage());
	 		}
	 	}while(!res);
	     
	   //store it in Accountbean bean
			Account account=new Account(holderName,phone,address,alternatePhone,emailId,pan,balance);
      //store it in transactionb bean
			Transaction transaction=new Transaction(availbalance,"typeOfTrans",transAmount);
			transaction.setTransAmount(balance);
			transaction.setBalance(balance);
			transaction.setTypeOfTrans("create account");
	  //validation successfull
			int aid=iserv.CreateAccount(account,transaction); 
	     return aid;
	}
	
}
