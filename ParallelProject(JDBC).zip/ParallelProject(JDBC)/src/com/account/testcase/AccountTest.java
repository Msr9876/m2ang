package com.account.testcase;

import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.account.bean.Account;
import com.account.dao.AccountDao;
import com.account.dao.IAccountDao;

public class AccountTest 
{

	static IAccountDao dao=null;
	
	//perform function before each method
	@Before
	public  void init()
	{
		dao=new AccountDao();
	}
	
	//perform function after completion of method
	@After
	public void remove()
	{
		dao=null;
	}
	
	@Test
	public void CreateAccount() 
	{
		Account account=new Account("pavithra","7894561230","banglore","9874561230","pavithra@gmail.com","ADSFD12365",10000);
		account.setAddress("banglore");
	Assert.assertEquals("banglore",account.getAddress());
	}
}
