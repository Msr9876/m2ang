package com.employee.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.demo.exception.UserNotFoundException;
import com.employee.entity.Employee;
import com.employee.service.EmployeeService;
 
//controller class
@RestController
//mapping
@RequestMapping("/employees")
public class EmployeeController 
{
	@Autowired
	EmployeeService employeeService;
	
	//to display all employee list
	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public List< Employee> getAllEmployees() 
	{
		return this.employeeService.getAllEmployees();
	}
	
	//to add Employees into the table
	@RequestMapping(value = "/createEmployee", method = RequestMethod.POST, 
			consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Employee addUser(@RequestBody Employee employee) 
	{
		return this.employeeService.createEmployee(employee);
	}
	
	// to update employee details
	@RequestMapping(value = "/updateEmployee", method = RequestMethod.PUT, 
			consumes = MediaType.APPLICATION_JSON_VALUE, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	public Employee updateUser(@RequestBody Employee employee) 
	{
		return this.employeeService.updateEmployee(employee);
	}
	
	//to delete employee details by id
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public void deleteUser(@PathVariable int id) 
	{
		this.employeeService.deleteEmployeeById(id);
	}
	
 
	
	//to fetch employee details by id
	@RequestMapping(value="/{id}", method=RequestMethod.GET)
	public Optional<Employee> getEmployeeById(@PathVariable int id) throws UserNotFoundException//handling exception
	{
		Optional<Employee> employee=this.getEmployeeById(id);
		System.out.println(employee.isPresent());
		if(!employee.isPresent())
			throw new UserNotFoundException("USER with this id does not exist!");	
		//return employeeService.getEmployeeById(id);//it will be used when exceptions are not handled
		return employee;
	}
}
