package com.employee.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/*created on- 24/05/2019
 *Author-pavithra H R
 *Project- EmployeeManagementSystem
 */





//creating entity class
@Entity
//to create table in mysql
@Table(name="Employee")
public class Employee 
{
	
//to automatically generate id
	@Id
	@Column(name="EMP_ID")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int employeeId;
	
	//to create employeeName column
	@Column(name="NAME",nullable=true,length=150)
	private String employeeName;
	
	//to create employeeDesignation column
	@Column(name="Designation",nullable=true,length=50)
	private  String  designation;
	
	//to create departmentName column
	@Column(name="DEPT_NAME",nullable=true,length=25)
	private String  departmentName;
	
	//to create salary column
	@Column(name="SALARY",nullable=true,length=25)
	private Integer salary;

	//default constructor
	public Employee() {
		super();
		 
	}
	//parameterized constructor
	public Employee(String employeeName, String designation, String departmentName, Integer salary) {
		super();
		this.employeeName = employeeName;
		this.designation = designation;
		this.departmentName = departmentName;
		this.salary = salary;
	}

	//getter setter method
	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public Integer getSalary() {
		return salary;
	}

	public void setSalary(Integer salary) {
		this.salary = salary;
	}

	//to string method
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", designation=" + designation
				+ ", departmentName=" + departmentName + ", salary=" + salary + "]";
	}
	
}
