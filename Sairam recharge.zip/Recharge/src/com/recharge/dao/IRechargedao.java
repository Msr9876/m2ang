package com.recharge.dao;

import com.recharge.bean.Recharge;

public interface IRechargedao {


	public void viewAll();
	public void viewbyId(int vid);
	public void update(int rid,String rname);
	public void delete(int id);
	public int doRecharge(Recharge rec);
}
