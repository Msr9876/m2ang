package com.recharge.dao;

import java.util.Collection;
import java.util.HashMap;

import com.recharge.bean.Recharge;

public class Rechargedaoimpl implements  IRechargedao {
	static HashMap<Integer,Recharge> m1=new HashMap<Integer, Recharge>();
	@Override
	public int doRecharge(Recharge rec) {
		m1.put(rec.getRechargeId(),rec);
		return rec.getRechargeId();	
		// TODO Auto-generated method stub
		
	}

	@Override
	public void viewAll() {
		Collection<Recharge> rec=m1.values();
		for(Recharge r:rec) {
			System.out.println("Recharge id is:"+r.getRechargeId());
			System.out.println("Name of the person is:"+r.getName());
			System.out.println("Mobile number is:"+r.getMobNum());
			System.out.println("Recharged date is:"+r.getDate());
			System.out.println("Balance amount is:"+r.getAmount());
			System.out.println("Description is:"+r.getDescription());
		}
		
	}

	@Override
	public void viewbyId(int vid) {
		Recharge r=m1.get(vid);
		System.out.println("Recharge id is:"+r.getRechargeId());
		System.out.println("Recharged person  name is:"+r.getName());
		System.out.println("Mobile number  is:"+r.getMobNum());
		System.out.println("Balance amount is:"+r.getAmount());
		System.out.println("Recharged date is:"+r.getDate());
		System.out.println("Description is:"+r.getDescription());
	}

	@Override
	public void update(int rid,String rname) {
	Recharge r=m1.get(rid);
	r.setName(rname);
	System.out.println("Update successful and the new name is:"+r.getName());
	
		
	}

	@Override
	public void delete(int id) {
		
		m1.remove(id);
		System.out.println("Transaction is deleted!!");
	}


		
	


	
	

}
