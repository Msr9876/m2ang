package com.recharge.bean;

import java.time.LocalDate;


public class Recharge {

	int rechargeId;
	String mobNum;
	String name;
	LocalDate date;
	String rechargeType;
	String planname;
	String desc;
	int amount;
	 public String getDescription() {
		return desc;
	}


	public void setDescription(String desc) {
		this.desc = desc;
	}




	
	public int getRechargeId() {
		return rechargeId;
	}


	public void setRechargeId(int rechargeId) {
		this.rechargeId = rechargeId;
	}


	public String getMobNum() {
		return mobNum;
	}


	public void setMobNum(String mobNum) {
		this.mobNum = mobNum;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}





	public String getRechargeType() {
		return rechargeType;
	}


	public void setRechargeType(String rechargeType) {
		this.rechargeType = rechargeType;
	}


	public String getPlanname() {
		return planname;
	}


	public void setPlanname(String planname) {
		this.planname = planname;
	}



	public LocalDate getDate() {
		return date;
	}


	public void setDate(LocalDate date) {
		this.date = date;
	}



	public int getAmount() {
		return amount;
	}


	public void setAmount(int amount) {
		this.amount = amount;
	}


	public Recharge(String mobNum, int amount, String name,String desc, LocalDate date, String rechargeType, String planname) {
		super();
		this.mobNum = mobNum;
		this.name = name;
		this.rechargeType = rechargeType;
		this.planname = planname;
		this.date=date;
		this.amount=amount;
		this.desc=desc;
	}



	}
	

