package com.recharge.exception;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;

import com.recharge.bean.Recharge;
import com.recharge.dao.Rechargedaoimpl;

import junit.framework.Assert;

public class TestClass {
	Rechargedaoimpl ido=null;
	
	@Before
	public void setup()
	{
		ido=new Rechargedaoimpl();
	}
	
	@Before
	public void teardown()
	{
		ido=null;
	}
	
	@Test
	public void test()
	{
	Recharge r = new Recharge("9676056597", 5000, "mahesh", "recharge", 2019-04-17, "prepaid", "mahesh");
	r.setRechargeId(1001);
	Assert.assertEquals(1001, r.getRechargeId());
	}
}
