package com.recharge.exception;

public class RechargeException extends Exception {

	public RechargeException(String r) {
		// TODO Auto-generated constructor stub
	}

	public RechargeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}
