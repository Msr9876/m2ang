//Task name: Recharge of  mobile number
package com.recharge.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.recharge.bean.Recharge;
import com.recharge.service.IRechargeService;
import com.recharge.service.RechargeServiceimpl;

public class RechargeUi {

	static Scanner sc= new Scanner(System.in);
	static IRechargeService iserv=null;
	static String var;
	static int balance=3000;
	
	public static void main(String[] args) throws Exception {
		do{
			
		System.out.println("Select any of the below option");
		System.out.println(" 1.Do Recharge \n 2. View all trasactions\n 3.View by id");
		System.out.println("4. Update \n 5. Delete  ");
		switch (sc.nextInt()) {
		//Method Declarations in Switch cases
		case 1: 
			int finalRechargeId=doRecharge();
		System.out.println("Recharge done Sucessfully!");
		System.out.println("Your recharge id  is "+finalRechargeId);
	
		break;

		case 2:
			
			viewAll();
			break;

		case 3:
			System.out.println("Enter the Recharge id to view");
			int vid=sc.nextInt();
			viewbyId(vid);
			break;

		case 4:
			System.out.println("Enter recharge id to update");
			int rid=sc.nextInt();
			System.out.println("Enter the name to update");
			String rname=sc.next();
			update(rid, rname);
			break;

		case 5:
			System.out.println("Enter the recharge id to delete");
			int id=sc.nextInt();
			delete(id);
			break;
			
		default:
			System.out.println("Choose options between 1-5");
			break;
	}
		System.out.println("Do you wish to continue [Yes/No]?");
		 var=sc.next();
			}
			while(var.equals("Yes")||var.equals("yes"));
			
			}

	//Method Implementation
	private static void delete(int id) {
		iserv= new RechargeServiceimpl();
		iserv.delete(id);//Calling the method in service layer
	}
	private static void update(int rid, String rname) {
	
		iserv= new RechargeServiceimpl();
		iserv.update(rid,rname);//Calling the method in service layer
		
	}
	private static void viewbyId(int vid) {
		iserv= new RechargeServiceimpl();
		iserv.viewbyId(vid);//Calling the method in service layer
		
	}
	private static void viewAll() {
		iserv= new RechargeServiceimpl();
		iserv.viewAll();//Calling the method in service layer
		
	}
	
	
	static String  mobNum;
	static int  amount;
	static String name;
	static LocalDate date=null;
	static String rechargeType;
	static String planName;

	private static int doRecharge() throws Exception {
		iserv=new RechargeServiceimpl();
		int rid=0;
		boolean res=false;
		String desc;
	
		do {
			
			System.out.println(" Enter person name");
			name =sc.next();
			res = iserv.validatename(name);		
			
		}while(iserv.validatename(name)==false);
		
		
		do {
			try {
			
				System.out.println("Enter the Correct mobile number");
				 mobNum = sc.next();
				res = iserv.validatemobilenumber(mobNum);		
			}catch(Exception e) {
				System.out.println(e.getMessage());
			}
			
		} while (!res);	
		
		int i=0;
		do {
		System.out.println("Select recharge type, 1. Prepaid\n 2.Postpaid");
		i=sc.nextInt();
		
		if(i==1) {
			System.out.println("Plans available are:");
			System.out.println(" 1.99\n 2.199\n 3.299");
			switch(sc.nextInt()) {
			case 1: System.out.println("Recharhge of Rs:99 done sucessfully!!");
			System.out.println("Available balance is:"+(balance-99));
			balance=balance-99;
				break;

			case 2: System.out.println("Recharhge of Rs:199 done sucessfully!!");
			System.out.println("Available balance is:"+(balance-199));
			balance=balance-199;	
			break;

			case 3: System.out.println("Recharhge of Rs:299 done sucessfully!!");
			System.out.println("Available balance is:"+(balance-299));
			balance=balance-299;
				break;
				default:System.out.println("Select  proper option");
				break;
			}
			}
		
			else if(i==2) {
				System.out.println("Plans available are:");
				System.out.println(" 1.449\n 2.549\n 3.849");
				switch(sc.nextInt()) {
				case 1: System.out.println("Recharhge of Rs:449 done sucessfully!!");
					System.out.println("Available balance is:"+(balance-449));
					balance=balance-449;
					break;

				case 2: System.out.println("Recharhge of Rs:549 done sucessfully!!");
				System.out.println("Available balance is:"+(balance-549));
				balance=balance-549;	
				break;

				case 3: System.out.println("Recharhge of Rs:849 done sucessfully!!");
				System.out.println("Available balance is:"+(balance-849));
				balance=balance-849;	
				break;
					default:System.out.println("Select proper option");
					break;
				}
			}
			else {
				System.out.println("Select the correct option number");				
			}
		}while(i>2);
	
		
		System.out.println("Enter the description of the recharge:");
		desc=sc.next();
		date=LocalDate.now();
		amount=balance;	
		Recharge rec= new Recharge(mobNum, amount,name,desc,date, rechargeType, planName);
		rid=iserv.doRecharge(rec);
		return rid;
	
	}			

}
