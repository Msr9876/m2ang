package com.recharge.service;

public class NumberException extends Exception {

}
