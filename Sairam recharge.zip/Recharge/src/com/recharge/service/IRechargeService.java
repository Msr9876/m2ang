package com.recharge.service;

import com.recharge.bean.Recharge;
import com.recharge.exception.RechargeException;

public interface IRechargeService {

	public int doRecharge(Recharge rec);
	public void viewAll();
	public void viewbyId(int vid);
	public void update(int rid,String rname);
	public void delete(int id);



public boolean validatemobilenumber(String mobNum);
public boolean validateamount(int amount);
//public boolean validatePlanName(String planName);
public boolean validatename(String name);


}
