package com.recharge.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.recharge.bean.Recharge;
import com.recharge.dao.IRechargedao;
import com.recharge.dao.Rechargedaoimpl;


public class RechargeServiceimpl implements IRechargeService {

	IRechargedao idao=null;
	Matcher m=null;
	private int generateRechargeId(){
		int id;
		id= (int)(Math.random()*10000000);
		return id;
	}
	@Override
	public int doRecharge(Recharge rec) {
		rec.setRechargeId(generateRechargeId());
		idao=new Rechargedaoimpl();
		return idao.doRecharge(rec);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void viewAll() {
	
		idao=new Rechargedaoimpl();
		idao.viewAll();
	}

	@Override
	public void viewbyId(int vid) {
	
		idao=new Rechargedaoimpl();
		 idao.viewbyId(vid);
	}

	@Override
	public void update(int rid,String rname) {
		idao=new Rechargedaoimpl();
		 idao.update(rid,rname);
		
	}

	@Override
	public void delete(int id) {
		idao=new Rechargedaoimpl();
		idao.delete(id);
		
	}
	@Override
	public boolean validatemobilenumber(String mobNum) {
		
		Pattern p1=Pattern.compile("^[6-9]\\d{9}$");
		m=p1.matcher(mobNum);
		if(m.find()){
		return true;
		}
		return false;

	}
	@Override
	public boolean validateamount(int amount) {
	
		if(amount>0){
			return true;
			
			}
		return false;	 
	}	

	@Override
	public boolean validatename(String name)  {
		
		Pattern p1=Pattern.compile("^[A-Z][a-z]{3,16}");
		m=p1.matcher(name);
		if(m.find()){
		return true;
		}
		else {
			System.out.println("Pattern mis-match");
			return false;
		}
		
	
		
	}

}
	
		
	

	


