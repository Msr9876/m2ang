package com.empmgmtwithexceptionalhandling.Dao;
import java.util.Collection;

import com.EmpMgmtwithExceptionHandling.bean.Employee;

public interface IEmpDao  {

	public int addEmployee(Employee emp);
	public void deleteById(int id);
	public void  viewById(int vid);	
	public Employee  updateEmployees(int empid2, String pwds);
	public void viewAllEmployee();
}
