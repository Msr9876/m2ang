package com.empmgmtwithexceptionalhandling.Dao;

import java.util.Collection;
import java.util.HashMap;

import com.EmpMgmtwithExceptionHandling.bean.Employee;

public class EmpDaoimpl implements IEmpDao {

	static HashMap<Integer,Employee> m1=new HashMap<Integer, Employee>();
	@Override
	public int addEmployee(Employee emp) {
		m1.put(emp.getEmpid(),emp);
		return emp.getEmpid();		
		
	}

	@Override
	public void deleteById(int id) {
		m1.remove(id);
		System.out.println("Employee is successfully deleted");
		
	}

	@Override
	
		public void viewAllEmployee() {
		Collection<Employee> emp=m1.values();
		
		for(Employee m:emp){
			System.out.println("Employee id is:"+m.getEmpid());
			System.out.println("Employee name is:"+m.getEmpname());
			System.out.println("Employee salary is:"+m.getSalary());
		}
			
		}
	

	@Override
	public void viewById(int vid) {
		Employee e=m1.get(vid);
	
			System.out.println("Employee id is:"+e.getEmpid());
			System.out.println("Employee name is:"+e.getEmpname());
			System.out.println("Employee salary  is:"+e.getSalary());
		
		
	}

	@Override
	public Employee  updateEmployees(int empid2,String pwds) {
	
		Collection<Employee> c3=m1.values();
		Employee s=m1.get(empid2);
		System.out.println();
		s.setPwd(pwds);
		System.out.println(m1.values());
		return null;
	}




		
	}

	

