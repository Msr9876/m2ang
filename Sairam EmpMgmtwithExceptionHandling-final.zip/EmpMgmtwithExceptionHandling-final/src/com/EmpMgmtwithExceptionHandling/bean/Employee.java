package com.EmpMgmtwithExceptionHandling.bean;

public    class Employee {
	
	
	int empid;
	String empname;
	int salary;
	String doj;
	String pwd;
	
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getDoj() {
		return doj;
	}
	public void setDoj(String doj) {
		this.doj = doj;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	} 
		
	public Employee() {
			
		}
	
	public Employee(String empname, int salary, String doj, String pwd) {
		super();
		this.empname = empname;
		this.salary = salary;
		this.doj = doj;
		this.pwd = pwd;
	}
	
	
	
	
	
	
	
	
	

}
