"use strict";
exports.__esModule = true;
var Person = /** @class */ (function () {
    function Person(fName, lName) {
        this.firstName = fName;
        this.lastName = lName;
    }
    Person.prototype.getFullName = function () {
        return "First Name : " + this.firstName + " Last Name : " + this.lastName;
    };
    return Person;
}());
exports.Person = Person;
// let person = new Person("Green", "Grass");
// console.log(person);
// console.log(person.firstName);
// console.log(person.lastName);
