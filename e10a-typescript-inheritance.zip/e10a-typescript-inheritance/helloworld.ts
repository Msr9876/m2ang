let message: string = "welcome";
console.log(message)