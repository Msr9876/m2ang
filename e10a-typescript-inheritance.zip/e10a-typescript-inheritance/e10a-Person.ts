export class Person {
  //variables declared in the class
  firstName: string;
  lastName: string;

  constructor(fName: string, lName: string) {
    this.firstName = fName;
    this.lastName = lName;
  }

  getFullName() {
    return `First Name : ${this.firstName} Last Name : ${this.lastName}`;
  }
}

// let person = new Person("Green", "Grass");
// console.log(person);
// console.log(person.firstName);
// console.log(person.lastName);

