import {Person} from './e10a-Person'
export class Employee extends Person{
 // properties
 empID: string;
    designation: string;
    
    constructor(fName: string, lName: string, eID: string, desig: string) {
        super(fName, lName);
        // fill the other properties
      this.empID = eID;
      this.designation = desig;
    }

    toString()
    {
        return `${this.empID} - ${this.firstName} ${this.lastName} => ${
            this.designation
          }`;
    }
}