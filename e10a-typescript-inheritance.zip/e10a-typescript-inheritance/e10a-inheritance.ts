import { Person } from './e10a-Person'
import { Employee } from './e10a-Employee';
//Getting person Details
let person = new Person('Success', 'Failure');
console.log(person.getFullName());

let employee  = new Employee(
    'Stone',
    'Clone',
    '1234',
    'Software Engineer'
  );
console.log(employee.toString());
let employees: Employee[] = [
    new Employee('Smiling',
        'Snake',
        '5678',
        'Fashion Designer'),
    new Employee(
        'Stone',
        'Clone',
        '1234',
        'Software Engineer'
    )
];

console.log(employees);

for (const employee of employees) {
    console.log(employee.toString());
}
//fat arrow functions
employees.forEach(employee => {
    console.log(employee.toString());  
});

console.log("for loop");
for (let i = 0; i < employees.length; i++) {
    console.log(employees[i].toString());
}
