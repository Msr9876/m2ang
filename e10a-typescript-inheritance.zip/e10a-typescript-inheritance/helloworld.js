var message = "welcome";
console.log(message);
